@REM  @echo off
@REM  set "PATH=C:\node32;%PATH%"
@REM  "C:\node32\node.exe" %*


@REM  Greenscapes
@echo off
set "PATH=C:\Program Files (x86)\nodejs;%PATH%"
"C:\Program Files (x86)\nodejs\node.exe" %*
