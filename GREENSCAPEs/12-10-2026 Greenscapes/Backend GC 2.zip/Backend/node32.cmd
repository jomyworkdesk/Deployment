@echo off
set "PATH=C:\node32;%PATH%"
"C:\node32\node.exe" %*


@REM  @REM  Greenscapes
@REM  @echo off
@REM  set "PATH=C:\Program Files (x86)\nodejs;%PATH%"
@REM  "C:\Program Files (x86)\nodejs\node.exe" %*
