// cd Backend
// .\node32.cmd scripts\checkDbConnections.js

const path = require("path");
const dotenv = require("dotenv");
const odbc = require("odbc");

const envFileArg = process.argv[2];
const envPath = envFileArg
    ? path.resolve(process.cwd(), envFileArg)
    : path.join(__dirname, "..", ".env");

const requiredEnvVars = [
    "PRIMARY_DB_DSN",
    "PRIMARY_DB_NAME",
    "PORT",
    "SECONDARY_DB_DSN",
    "SECONDARY_DB_NAME",
    "PERVASIVE_ODBC_ARCH"
];

const logStep = (message) => console.log(`[CHECK] ${message}`);
const logOk = (message) => console.log(`[OK] ${message}`);
const logError = (message, error) => {
    console.error(`[ERROR] ${message}`);
    if (error) {
        console.error(error.message || error);
        if (Array.isArray(error.odbcErrors) && error.odbcErrors.length > 0) {
            console.error("Native ODBC details:");
            error.odbcErrors.forEach((odbcError) => {
                console.error(
                    [odbcError.state, odbcError.code, odbcError.message]
                        .filter(Boolean)
                        .join(" ")
                );
            });
        }
    }
};

const loadEnvironment = () => {
    logStep(`Loading environment from ${envPath}`);
    const result = dotenv.config({ path: envPath });

    if (result.error) {
        throw new Error(`Unable to load env file: ${result.error.message}`);
    }

    logOk("Environment file loaded");
};

const validateEnvironment = () => {
    logStep("Checking required environment values");

    const missingVars = requiredEnvVars.filter((name) => !process.env[name]);
    if (missingVars.length > 0) {
        throw new Error(`Missing required environment variable(s): ${missingVars.join(", ")}`);
    }

    const port = Number(process.env.PORT);
    if (!Number.isInteger(port) || port < 1 || port > 65535) {
        throw new Error(`PORT must be a number between 1 and 65535. Got: ${process.env.PORT}`);
    }

    if (process.env.PERVASIVE_ODBC_ARCH === "32" && process.arch !== "ia32") {
        throw new Error(
            "PERVASIVE_ODBC_ARCH=32 requires 32-bit Node. Run this with node32.cmd."
        );
    }

    logOk(`PRIMARY_DB_DSN=${process.env.PRIMARY_DB_DSN}`);
    logOk(`PRIMARY_DB_NAME=${process.env.PRIMARY_DB_NAME}`);
    logOk(`PORT=${process.env.PORT}`);
    logOk(`SECONDARY_DB_DSN=${process.env.SECONDARY_DB_DSN}`);
    logOk(`SECONDARY_DB_NAME=${process.env.SECONDARY_DB_NAME}`);
    logOk(`PERVASIVE_ODBC_ARCH=${process.env.PERVASIVE_ODBC_ARCH}`);
    logOk(`Node architecture=${process.arch}`);
};

const checkDatabase = async ({ label, dsn, databaseName }) => {
    let connection;

    try {
        logStep(`Connecting to ${label} database (${databaseName}) using DSN=${dsn}`);
        connection = await odbc.connect(`DSN=${dsn};`);
        logOk(`${label} database connected`);

        logStep(`Running SELECT 1 on ${label} database`);
        const rows = await connection.query("SELECT 1 AS ok");
        console.log(`[RESULT] ${label}:`, rows);
        logOk(`${label} database query succeeded`);
    } catch (error) {
        logError(`${label} database check failed`, error);
        throw error;
    } finally {
        if (connection) {
            await connection.close();
            logOk(`${label} database connection closed`);
        }
    }
};

const main = async () => {
    loadEnvironment();
    validateEnvironment();

    await checkDatabase({
        label: "Primary",
        dsn: process.env.PRIMARY_DB_DSN,
        databaseName: process.env.PRIMARY_DB_NAME
    });

    await checkDatabase({
        label: "Secondary",
        dsn: process.env.SECONDARY_DB_DSN,
        databaseName: process.env.SECONDARY_DB_NAME
    });

    logOk("All database checks passed");
};

main().catch(() => {
    console.error("[FAILED] Database check finished with errors");
    process.exit(1);
});
