@echo off
set "PATH=C:\node32;%PATH%"
"C:\node32\node.exe" "C:\node32\node_modules\npm\bin\npm-cli.js" %*

@REM  @REM  Greenscapes
@REM  @echo off
@REM  set "PATH=C:\Program Files (x86)\nodejs;%PATH%"
@REM  "C:\Program Files (x86)\nodejs\node.exe" "C:\Program Files (x86)\nodejs\node_modules\npm\bin\npm-cli.js" %*

