const db = require("../dbSecondary");
const { normalizeInvoiceRows } = require("./invoiceColumnAliases");
const INVOICE_DOC_TYPE = [3];
const PURCHASE_DOC_TYPE = 5;
const INVOICE_TABLE = "E_Invoicing";
const PURCHASE_TABLE = "E_Purchase";
const OUT_DOCUMENT_TABLE = "E_InvoiceoutDocument";
const OUT_DOCUMENT_DETAIL_FIELDS = `
            e.OutDocument AS "outDocument",
            odoc.ID AS "outdoc_id",
            odoc.invoiced_obj_id AS "outdoc_invoiced_obj_id",
            odoc.inv_obj_scheme_id AS "outdoc_invoiced_obj_scheme_id",
            odoc.document_type_code AS "outdoc_document_type_code",
            odoc.support_doc_ref AS "outdoc_support_doc_ref",
            odoc.support_doc_desc AS "outdoc_support_doc_desc",
            odoc.attached_document AS "outdoc_attached_document",
            odoc.attach_doc_mime_code AS "outdoc_attached_doc_mime_code",
            odoc.attach_doc_filename AS "outdoc_attached_doc_filename",
            odoc.external_doc_loc AS "outdoc_external_doc_location"`;
const OUT_DOCUMENT_JOIN = `
        LEFT JOIN ${OUT_DOCUMENT_TABLE} odoc
          ON odoc.ID = (
              SELECT MAX(supporting_doc.ID)
              FROM ${OUT_DOCUMENT_TABLE} supporting_doc
              WHERE supporting_doc.invoice_no = e.invoice_no
                 OR supporting_doc.ID IN (
                     SELECT linked_invoice.OutDocument
                     FROM ${INVOICE_TABLE} linked_invoice
                     WHERE linked_invoice.invoice_no = e.invoice_no
                       AND linked_invoice.DocType = e.DocType
                       AND linked_invoice.OutDocument IS NOT NULL
                 )
                 OR supporting_doc.EinvoiceID IN (
                     SELECT linked_invoice.ID
                     FROM ${INVOICE_TABLE} linked_invoice
                     WHERE linked_invoice.invoice_no = e.invoice_no
                       AND linked_invoice.DocType = e.DocType
                 )
          )`;
const OUT_DOCUMENT_COLUMNS = [
    "invoiced_obj_id",
    "inv_obj_scheme_id",
    "document_type_code",
    "support_doc_ref",
    "support_doc_desc",
    "attached_document",
    "attach_doc_mime_code",
    "attach_doc_filename",
    "external_doc_loc"
];
const OUT_DOCUMENT_MIME_CODE_OPTIONS = [
    { Value: "application/pdf", DisplayName: "PDF" },
    { Value: "image/png", DisplayName: "PNG image" },
    { Value: "image/jpeg", DisplayName: "JPEG image" },
    { Value: "text/csv", DisplayName: "CSV" },
    { Value: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", DisplayName: "Excel workbook" },
    { Value: "application/vnd.oasis.opendocument.spreadsheet", DisplayName: "OpenDocument spreadsheet" },
    { Value: "application/xml", DisplayName: "XML" }
];
const OUTBOUND_RESPONSE_FIELDS = `
                COALESCE(MAX(CASE
                    WHEN LOWER(LTRIM(RTRIM(t.TransmissionType))) = 'mls_inbound'
                    THEN t.Status
                END), 'Pending') AS C3ResponseStatus,
                COALESCE(MAX(CASE
                    WHEN LOWER(LTRIM(RTRIM(t.TransmissionType))) = 'c2_tdd_mls_inbound'
                    THEN t.Status
                END), 'Pending') AS C5ResponseStatus`;
const INVOICE_DETAIL_FIELDS = `
            e.*,
            e.invoice_no AS InvoiceNumber,
            e.invoice_issue_date AS InvoiceIssueDate,
            e.payment_due_date AS InvoicePaymentDueDate,
            e.inv_currency_code AS InvoiceCurrencyCode,
            e.inv_txn_typ_cod AS TransactionCode,
            e.buyer_name AS BuyerName,
            e.buyer_addr_line1 AS BuyerAddressline1,
            e.buyer_city AS BuyerCity,
            e.buyer_country_sub AS BuyerCountrySubdivision,
            e.buyer_country_code AS BuyerCountry,
            e.payment_type_code AS PaymentType,
            e.vat_cat_code AS VatCategory,
            e.invoice_line_id AS InvoiceLineIdentifier,
            e.invoiced_qty AS InvoicedQuantity,
            e.invoice_line_net_amt AS LineExtensionAmount,
            e.item_name AS ItemName,
            e.item_description AS ItemDescription,
            e.item_vat_cat_code AS ItemVatCategory,
            e.item_vat_rate AS ItemVatPrice,
            e.inv_qty_uom_code AS UOMCode,
            e.item_net_price AS PriceExcl,
            e.seller_name AS SellerName,
            e.seller_addr_line1 AS SellerAddressline1,
            e.seller_city AS SellerCity,
            e.seller_country_sub AS SellerCountrySubdivision,
            e.seller_country_code AS SellerCountryCode,
            e.inv_tot_without_tax AS InvTotExcl,
            e.inv_tot_tax_amt AS InvTotTax,
            e.inv_total_with_tax AS InvTotIncl,
            e.invoice_line_net_amt AS LineNet,
            e.vat_line_amt_aed AS LineTax,
            e.invoice_line_amt_aed AS LineTotal,
            e.vat_cat_taxable_amt AS TotalInvoiceAmt`;

const quoteIdentifier = (identifier) => `"${String(identifier).replace(/"/g, '""')}"`;

const getAllInvoices = async (docType = INVOICE_DOC_TYPE) => {
    const documentTable = getDocumentTable(docType);
    const rows = await db.queryUnsafe(`
        SELECT ${INVOICE_DETAIL_FIELDS}
            ${documentTable === INVOICE_TABLE ? `, ${OUT_DOCUMENT_DETAIL_FIELDS}` : ""}
        FROM ${documentTable} e
        ${documentTable === INVOICE_TABLE ? OUT_DOCUMENT_JOIN : ""}
        WHERE ${buildDocTypeFilter("e", docType)}
    `);
    return normalizeInvoiceRows(rows);
};

const getInvoiceDetailsByNumbers = async (invoiceNumbers, docType = INVOICE_DOC_TYPE, invoiceTypeCode = null) => {
    if (!Array.isArray(invoiceNumbers) || invoiceNumbers.length === 0) {
        return [];
    }

    const sanitizedInvoiceNumbers = invoiceNumbers
        .filter((value) => value !== null && value !== undefined && value !== "")
        .map((value) => String(value).replace(/'/g, "''"));

    if (sanitizedInvoiceNumbers.length === 0) {
        return [];
    }

    const inClause = sanitizedInvoiceNumbers
        .map((invoiceNumber) => `'${invoiceNumber}'`)
        .join(", ");
    const documentTable = getDocumentTable(docType);
    const invoiceTypeFilter = buildInvoiceTypeCodeFilter("e", invoiceTypeCode);

    const rows = await db.queryUnsafe(`
        SELECT
            ${INVOICE_DETAIL_FIELDS}
            ${documentTable === INVOICE_TABLE ? `, ${OUT_DOCUMENT_DETAIL_FIELDS}` : ""},
            q.Status,
            q.IsSent,
            q.IsReceived,
            q.IsInvoiced,
            q.IsError,
            q.ErrorMessage,
            q.InvoicedAt,
            q.SentAt,
            q.ReceivedAt,
            q.ErrorAt
        FROM ${documentTable} e
        ${documentTable === INVOICE_TABLE ? OUT_DOCUMENT_JOIN : ""}
        LEFT JOIN E_InvoiceQueue q ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        WHERE e.invoice_no IN (${inClause})
        AND ${buildDocTypeFilter("e", docType)}
        ${invoiceTypeFilter}
        ORDER BY e.invoice_no ASC, e.ID ASC
    `);
    return normalizeInvoiceRows(rows);
};

const normalizeSqlDate = (value) => {
    if (typeof value !== "string") return null;
    return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
};

const addDaysToSqlDate = (value, days) => {
    const safeDate = normalizeSqlDate(value);
    if (!safeDate) return null;

    const date = new Date(`${safeDate}T00:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
};

const toSqlDateTimeStart = (value) => {
    const safeDate = normalizeSqlDate(value);
    return safeDate ? `${safeDate} 00:00:00.000` : null;
};

const toSqlNextDateTimeStart = (value) => {
    const safeDate = addDaysToSqlDate(value, 1);
    return safeDate ? `${safeDate} 00:00:00.000` : null;
};

const sqlTimestampLiteral = (value) => `{ts '${value}'}`;

const statusEquals = (alias, statusCode) => `${alias}.Status = '${statusCode}'`;

const normalizeDocTypes = (docType) => {
    const docTypes = Array.isArray(docType) ? docType : [docType];
    return docTypes
        .map((value) => Number(value))
        .filter((value) => Number.isFinite(value));
};

const getDocumentTable = (docType) => {
    const docTypes = normalizeDocTypes(docType);
    return docTypes.length === 1 && docTypes[0] === PURCHASE_DOC_TYPE
        ? PURCHASE_TABLE
        : INVOICE_TABLE;
};

const normalizeInvoiceTypeCode = (value) => {
    const code = String(value || "").trim();
    return /^(380|381)$/.test(code) ? code : null;
};

const buildDocTypeFilter = (alias, docType) => {
    const docTypes = normalizeDocTypes(docType);
    const qualifier = alias ? `${alias}.` : "";

    if (docTypes.length === 0) {
        return "1 = 0";
    }

    return docTypes.length === 1
        ? `${qualifier}DocType = ${docTypes[0]}`
        : `${qualifier}DocType IN (${docTypes.join(", ")})`;
};

const buildInvoiceTypeCodeFilter = (alias, invoiceTypeCode) => {
    const safeInvoiceTypeCode = normalizeInvoiceTypeCode(invoiceTypeCode);
    return safeInvoiceTypeCode ? ` AND ${alias}.invoice_type_code = '${safeInvoiceTypeCode}'` : "";
};

const buildQueueInvoiceTypeCodeFilter = (alias, invoiceTypeCode, documentTable = INVOICE_TABLE) => {
    const safeInvoiceTypeCode = normalizeInvoiceTypeCode(invoiceTypeCode);
    if (!safeInvoiceTypeCode) return "";

    return ` AND EXISTS (
        SELECT 1
        FROM ${documentTable} e
        WHERE e.invoice_no = ${alias}.InvNumber
          AND e.DocType = ${alias}.DocType
          AND e.invoice_type_code = '${safeInvoiceTypeCode}'
    )`;
};

const buildInvoiceDateFilter = (fromDate, toDate, alias = "e") => {
    const safeFromDate = toSqlDateTimeStart(fromDate);
    const safeToDate = toSqlNextDateTimeStart(toDate);
    const conditions = [];

    if (safeFromDate) {
        conditions.push(`${alias}.invoice_issue_date >= ${sqlTimestampLiteral(safeFromDate)}`);
    }

    if (safeToDate) {
        conditions.push(`${alias}.invoice_issue_date < ${sqlTimestampLiteral(safeToDate)}`);
    }

    return conditions.length ? ` AND ${conditions.join(" AND ")}` : "";
};

const buildQueueDateFilter = (fromDate, toDate, alias = "q") => {
    const safeFromDate = toSqlDateTimeStart(fromDate);
    const safeToDate = toSqlNextDateTimeStart(toDate);
    const conditions = [];

    if (safeFromDate) {
        conditions.push(`${alias}.InvDate >= ${sqlTimestampLiteral(safeFromDate)}`);
    }

    if (safeToDate) {
        conditions.push(`${alias}.InvDate < ${sqlTimestampLiteral(safeToDate)}`);
    }

    return conditions.length ? ` WHERE ${conditions.join(" AND ")}` : "";
};

const getDashboardCounts = async (fromDate, toDate, docType = INVOICE_DOC_TYPE, invoiceTypeCode = null) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q");
    const documentTable = getDocumentTable(docType);
    const invoiceTypeFilter = buildQueueInvoiceTypeCodeFilter("q", invoiceTypeCode, documentTable);
    const result = await db.queryUnsafe(`
        SELECT
            COUNT(DISTINCT q.QueueID) AS total,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 1)} AND COALESCE(q.IsInvoiced, 0) = 1 THEN q.QueueID END) AS pending,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 2)} THEN q.QueueID END) AS sent,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 3)} THEN q.QueueID END) AS success,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 3)} THEN q.QueueID END) AS received,
            COUNT(DISTINCT CASE WHEN COALESCE(q.IsInvoiced, 0) = 1 THEN q.QueueID END) AS invoiced,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 4)} THEN q.QueueID END) AS failed,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 6)} THEN q.QueueID END) AS error
        FROM E_InvoiceQueue q
        WHERE ${buildDocTypeFilter("q", docType)}
        ${invoiceTypeFilter}
        ${dateFilter.replace('WHERE', 'AND')}
    `);
    return result[0] || {};
};

const getPendingAndFailedEntries = async (fromDate, toDate, docType = INVOICE_DOC_TYPE) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");
    const documentTable = getDocumentTable(docType);
    const rows = await db.queryUnsafe(`
        SELECT
            q.QueueID,
            MAX(q.AutoIndex) AS AutoIndex,
            MAX(q.DocType) AS DocType,
            MAX(q.InvNumber) AS InvNumber,
            MAX(q.InvDate) AS InvDate,
            MAX(q.CreatedAt) AS CreatedAt,
            MAX(q.Status) AS Status,
            MAX(q.ErrorMessage) AS ErrorMessage,
            MAX(q.RetryCount) AS RetryCount,
            MAX(COALESCE(e.buyer_name, '')) AS Customer,
            MAX(e.inv_total_with_tax) AS Amount
        FROM E_InvoiceQueue q
        LEFT JOIN ${documentTable} e
            ON q.InvNumber = e.invoice_no AND q.DocType = e.DocType
        WHERE ${buildDocTypeFilter("q", docType)}
        AND q.Status IN ('1', '4')
        ${dateFilter}
        GROUP BY q.QueueID
        ORDER BY MAX(q.InvDate) DESC, q.QueueID DESC
    `);

    const pending = rows.filter((row) => String(row.Status) === "1").length;
    const failed = rows.filter((row) => String(row.Status) === "4").length;

    return {
        counts: {
            total: rows.length,
            pending,
            failed,
            success: 0,
            received: 0,
            error: failed
        },
        entries: rows
    };
};

const getInvoicesByType = async (type, fromDate, toDate, docType = INVOICE_DOC_TYPE, invoiceTypeCode = null) => {
    const dateFilter = buildInvoiceDateFilter(fromDate, toDate, "e");
    const invoiceTypeFilter = buildInvoiceTypeCodeFilter("e", invoiceTypeCode);
    const documentTable = getDocumentTable(docType);

    if (type === "pending" || type === "sent" || type === "success" || type === "received" || type === "error" || type === "failed") {
        const statusCodeMap = {
            pending: 1,
            sent: 2,
            success: 3,
            received: 3,
            error: 6,
            failed: 4
        };
        const statusCode = statusCodeMap[type];

        return db.queryUnsafe(`
            SELECT
                e.invoice_no AS InvoiceNumber,
                MAX(e.unique_identifier_no) AS AutoIndex,
                MAX(COALESCE(q.QueueID, 0)) AS QueueID,
                MAX(q.instanceIdentifier) AS InstanceIdentifier,
                MAX(q.CreatedAt) AS QueueCreatedAt,
                MAX(q.CreatedAt) AS CreatedAt,
                MAX(e.invoice_issue_date) AS InvoiceIssueDate,
                MAX(COALESCE(e.buyer_name, '')) AS Customer,
                MAX(e.inv_tot_without_tax) AS InvTotExcl,
                MAX(e.inv_tot_tax_amt) AS InvTotTax,
                MAX(e.inv_total_with_tax) AS InvTotIncl,
                MAX(e.vat_cat_taxable_amt) AS TotalInvoiceAmt,
                MAX(e.DocType) AS DocType,
                MAX(COALESCE(q.Status, '')) AS Status,
                ${OUTBOUND_RESPONSE_FIELDS}
            FROM ${documentTable} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE ${statusEquals("q", statusCode)}
            ${statusCode === 1 ? "AND COALESCE(q.IsInvoiced, 0) = 1" : ""}
            AND ${buildDocTypeFilter("e", docType)} AND ${buildDocTypeFilter("q", docType)}
            ${invoiceTypeFilter}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(COALESCE(q.QueueID, 0)) DESC
        `);
    }
    if (type === "invoiced") {
        return db.queryUnsafe(`
            SELECT
                e.invoice_no AS InvoiceNumber,
                MAX(e.unique_identifier_no) AS AutoIndex,
                MAX(COALESCE(q.QueueID, 0)) AS QueueID,
                MAX(q.instanceIdentifier) AS InstanceIdentifier,
                MAX(q.CreatedAt) AS QueueCreatedAt,
                MAX(q.CreatedAt) AS CreatedAt,
                MAX(e.invoice_issue_date) AS InvoiceIssueDate,
                MAX(COALESCE(e.buyer_name, '')) AS Customer,
                MAX(e.inv_tot_without_tax) AS InvTotExcl,
                MAX(e.inv_tot_tax_amt) AS InvTotTax,
                MAX(e.inv_total_with_tax) AS InvTotIncl,
                MAX(e.vat_cat_taxable_amt) AS TotalInvoiceAmt,
                MAX(e.DocType) AS DocType,
                MAX(COALESCE(q.Status, '')) AS Status,
                ${OUTBOUND_RESPONSE_FIELDS}
            FROM ${documentTable} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE COALESCE(q.IsInvoiced, 0) = 1
            AND ${buildDocTypeFilter("e", docType)} AND ${buildDocTypeFilter("q", docType)}
            ${invoiceTypeFilter}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(COALESCE(q.QueueID, 0)) DESC
        `);
    }
    if (type === "error" || type === "failed") {
        // Only return queue status = 4 (Failed)
        // Also project fields required by the Errors screen.
        return db.queryUnsafe(`
            SELECT
                MAX(e.inv_txn_typ_cod) AS EINVOICETYPE,
                e.invoice_no AS InvNumber,
                MAX(e.unique_identifier_no) AS AutoIndex,
                MAX(e.invoice_issue_date) AS InvDate,
                MAX(COALESCE(e.buyer_name, '')) AS BUYER_NAME,
                MAX(e.inv_total_with_tax) AS inv_total_with_tax,
                MAX(e.DocType) AS DocType,
                MAX(COALESCE(q.Status, '')) AS Status,
                MAX(COALESCE(q.QueueID, 0)) AS QueueID,
                MAX(q.CreatedAt) AS QueueCreatedAt,
                MAX(q.CreatedAt) AS CreatedAt,
                MAX(q.ErrorMessage) AS ErrorMessage
            FROM ${documentTable} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            WHERE ${statusEquals("q", 4)}
            AND ${buildDocTypeFilter("e", docType)} AND ${buildDocTypeFilter("q", docType)}
            ${invoiceTypeFilter}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(COALESCE(q.QueueID, 0)) DESC
        `);
    }
    return db.queryUnsafe(`
        SELECT
            e.invoice_no AS InvoiceNumber,
            MAX(e.unique_identifier_no) AS AutoIndex,
            MAX(COALESCE(q.QueueID, 0)) AS QueueID,
            MAX(q.instanceIdentifier) AS InstanceIdentifier,
            MAX(q.CreatedAt) AS QueueCreatedAt,
            MAX(q.CreatedAt) AS CreatedAt,
            MAX(e.invoice_issue_date) AS InvoiceIssueDate,
            MAX(COALESCE(e.buyer_name, '')) AS Customer,
            MAX(e.inv_tot_without_tax) AS InvTotExcl,
            MAX(e.inv_tot_tax_amt) AS InvTotTax,
            MAX(e.inv_total_with_tax) AS InvTotIncl,
            MAX(e.vat_cat_taxable_amt) AS TotalInvoiceAmt,
            MAX(e.DocType) AS DocType,
            MAX(COALESCE(q.Status, '')) AS Status,
            ${OUTBOUND_RESPONSE_FIELDS}
        FROM ${documentTable} e
        LEFT JOIN E_InvoiceQueue q
            ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        LEFT JOIN E_Get_Out_Trans t
            ON q.instanceIdentifier = t.RootInstance
        WHERE 1 = 1
        AND ${buildDocTypeFilter("e", docType)}
        ${invoiceTypeFilter}
        AND (q.QueueID IS NULL OR ${buildDocTypeFilter("q", docType)})
        AND (q.QueueID IS NULL OR q.Status IS NULL OR q.Status <> '0')
        ${dateFilter}
        GROUP BY e.invoice_no
        ORDER BY MAX(COALESCE(q.QueueID, 0)) DESC
    `);
};

const getPurchaseExportRows = async (fromDate, toDate, invoiceTypeCode = null, search = "") => {
    const dateFilter = buildInvoiceDateFilter(fromDate, toDate, "e");
    const invoiceTypeFilter = buildInvoiceTypeCodeFilter("e", invoiceTypeCode);
    const safeSearch = String(search || "").trim().replace(/'/g, "''");
    const searchFilter = safeSearch
        ? ` AND (
            e.invoice_no LIKE '%${safeSearch}%'
            OR e.seller_name LIKE '%${safeSearch}%'
            OR e.buyer_name LIKE '%${safeSearch}%'
        )`
        : "";

    return db.queryUnsafe(`
        SELECT e.*
        FROM ${PURCHASE_TABLE} e
        WHERE ${buildDocTypeFilter("e", PURCHASE_DOC_TYPE)}
        ${invoiceTypeFilter}
        ${dateFilter}
        ${searchFilter}
        ORDER BY e.invoice_issue_date DESC, e.ID DESC
    `);
};

const getPurchaseExportColumns = async () => {
    const connection = await db.getConnection();
    const result = await connection.query(`SELECT * FROM ${quoteIdentifier(PURCHASE_TABLE)} WHERE 1=0`);
    return Array.isArray(result?.columns)
        ? result.columns.map((column) => column.name).filter(Boolean)
        : [];
};

const getPurchaseTypeCounts = async (fromDate, toDate) => {
    const dateFilter = buildInvoiceDateFilter(fromDate, toDate, "e");
    const rows = await db.queryUnsafe(`
        SELECT
            COUNT(CASE WHEN e.invoice_type_code = '380' THEN 1 END) AS purchaseCount,
            COUNT(CASE WHEN e.invoice_type_code = '380' THEN NULL ELSE 1 END) AS purchaseReturnCount
        FROM ${PURCHASE_TABLE} e
        WHERE ${buildDocTypeFilter("e", PURCHASE_DOC_TYPE)}
        ${dateFilter}
    `);

    return rows[0] || {};
};

const getFailedInvoiceErrors = async (fromDate, toDate) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");

    return db.queryUnsafe(`
        SELECT
            q.InvNumber,
            MAX(q.InvDate) AS InvDate,
            MAX(ld.DocumentName) AS EInvoiceType,
            MAX(COALESCE(IE.Customer, E.buyer_name, '')) AS buyer_name,
            MAX(COALESCE(IE.InvoiceAmt, E.inv_total_with_tax)) AS AMOUNT
        FROM E_InvoiceQueue q
        INNER JOIN E_InvoiceError IE
            ON q.InvNumber = IE.InvNumber
        LEFT JOIN E_Invoicing E
            ON q.InvNumber = E.invoice_no
        LEFT JOIN E_lastDocument ld
            ON E.DocType = ld.DocumentType
        WHERE q.Status = 4
        ${dateFilter}
        GROUP BY q.InvNumber
        ORDER BY MAX(q.InvDate) DESC, q.InvNumber DESC
    `);
};

const getArtaxInvoiceErrors = async (fromDate, toDate) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");

    return db.queryUnsafe(`
        SELECT
            q.InvNumber,
            MAX(q.InvDate) AS InvDate,
            MAX(E.unique_identifier_no) AS AutoIndex,
            MAX(E.DocType) AS DocType,
            MAX(q.Status) AS Status,
            1 AS IsArtaxError,
            MAX(IE.ErrorAt) AS IsArtaxErrorAt,
            MAX(ld.DocumentName) AS EInvoiceType,
            MAX(COALESCE(IE.Customer, E.buyer_name, '')) AS buyer_name,
            MAX(COALESCE(IE.InvoiceAmt, E.inv_total_with_tax)) AS AMOUNT
        FROM E_InvoiceQueue q
        INNER JOIN E_InvoiceError IE
            ON q.InvNumber = IE.InvNumber
        LEFT JOIN E_Invoicing E
            ON q.InvNumber = E.invoice_no
        LEFT JOIN E_lastDocument ld
            ON E.DocType = ld.DocumentType
        WHERE q.Status = 6
        ${dateFilter}
        GROUP BY q.InvNumber
        ORDER BY MAX(q.InvDate) DESC, q.InvNumber DESC
    `);
};

const getFilterDebugStats = async (fromDate, toDate, docType = INVOICE_DOC_TYPE) => {
    const invoiceDateFilter = buildInvoiceDateFilter(fromDate, toDate, "e");
    const queueDateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");
    const documentTable = getDocumentTable(docType);

    const invoiceByDocType = await db.queryUnsafe(`
        SELECT
            DocType,
            COUNT(*) AS RowCount,
            MIN(invoice_issue_date) AS MinInvoiceIssueDate,
            MAX(invoice_issue_date) AS MaxInvoiceIssueDate
        FROM ${documentTable}
        GROUP BY DocType
        ORDER BY DocType
    `);
    const queueByDocType = await db.queryUnsafe(`
        SELECT
            DocType,
            COUNT(*) AS RowCount,
            MIN(InvDate) AS MinInvDate,
            MAX(InvDate) AS MaxInvDate
        FROM E_InvoiceQueue
        GROUP BY DocType
        ORDER BY DocType
    `);
    const queueByDocTypeAndStatus = await db.queryUnsafe(`
        SELECT
            DocType,
            Status,
            COUNT(*) AS RowCount,
            MIN(InvDate) AS MinInvDate,
            MAX(InvDate) AS MaxInvDate
        FROM E_InvoiceQueue
        GROUP BY DocType, Status
        ORDER BY DocType, Status
    `);
    const invoiceExpectedDocType = await db.queryUnsafe(`
        SELECT COUNT(*) AS RowCount
        FROM ${documentTable} e
        WHERE ${buildDocTypeFilter("e", docType)}
    `);
    const invoiceExpectedDocTypeInRange = await db.queryUnsafe(`
        SELECT COUNT(*) AS RowCount
        FROM ${documentTable} e
        WHERE ${buildDocTypeFilter("e", docType)}
        ${invoiceDateFilter}
    `);
    const queueExpectedDocType = await db.queryUnsafe(`
        SELECT COUNT(*) AS RowCount
        FROM E_InvoiceQueue q
        WHERE ${buildDocTypeFilter("q", docType)}
    `);
    const queueExpectedDocTypeInRange = await db.queryUnsafe(`
        SELECT COUNT(*) AS RowCount
        FROM E_InvoiceQueue q
        WHERE ${buildDocTypeFilter("q", docType)}
        ${queueDateFilter}
    `);

    return {
        expectedDocType: docType,
        fromDate,
        toDate,
        filters: {
            invoiceDateFilter: invoiceDateFilter.trim(),
            queueDateFilter: queueDateFilter.trim()
        },
        invoiceTable: {
            byDocType: invoiceByDocType,
            expectedDocTypeRows: invoiceExpectedDocType[0]?.RowCount || 0,
            expectedDocTypeRowsInRange: invoiceExpectedDocTypeInRange[0]?.RowCount || 0
        },
        queueTable: {
            byDocType: queueByDocType,
            byDocTypeAndStatus: queueByDocTypeAndStatus,
            expectedDocTypeRows: queueExpectedDocType[0]?.RowCount || 0,
            expectedDocTypeRowsInRange: queueExpectedDocTypeInRange[0]?.RowCount || 0
        }
    };
};

const getInvoiceResponseLogs = async (invNumber) => {
    const sanitizedInvNumber = String(invNumber || "").replace(/'/g, "''");

    if (!sanitizedInvNumber) {
        return [];
    }

    return db.queryUnsafe(`
        SELECT
            "Id",
            "InvNumber",
            "Status" AS status,
            "ErrorAt",
            "Error" AS responseMessage
        FROM "E_InvoiceError"
        WHERE "InvNumber" = '${sanitizedInvNumber}'
        AND "Status" = 'VALIDATION_ERROR'
        ORDER BY "Id" DESC
    `);
};

const getArtaxErrorsResponse = async (invNumber) => {
    const sanitizedInvNumber = String(invNumber || "").replace(/'/g, "''");

    if (!sanitizedInvNumber) {
        return [];
    }

    return db.queryUnsafe(`
        SELECT
            "Id",
            "InvNumber",
            "Status" AS status,
            "ErrorAt",
            "Error" AS responseMessage
        FROM "E_InvoiceError"
        WHERE "InvNumber" = '${sanitizedInvNumber}'
        AND "Status" = 'ARTAX_ERROR'
        ORDER BY "Id" DESC
    `);
};

const getInvoiceDetails = async (invNumber, docType = INVOICE_DOC_TYPE, invoiceTypeCode = null) => {
    const sanitizedInvNumber = String(invNumber).replace(/'/g, "''");
    const invoiceTypeFilter = buildInvoiceTypeCodeFilter("e", invoiceTypeCode);
    const documentTable = getDocumentTable(docType);
    const result = await db.queryUnsafe(`
        SELECT
            ${INVOICE_DETAIL_FIELDS}
            ${documentTable === INVOICE_TABLE ? `, ${OUT_DOCUMENT_DETAIL_FIELDS}` : ""},
            q.Status,
            q.IsSent,
            q.IsReceived,
            q.IsInvoiced,
            q.IsError,
            q.ErrorMessage,
            q.InvoicedAt,
            q.SentAt,
            q.ReceivedAt,
            q.ErrorAt
        FROM ${documentTable} e
        ${documentTable === INVOICE_TABLE ? OUT_DOCUMENT_JOIN : ""}
        LEFT JOIN E_InvoiceQueue q ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        WHERE e.invoice_no = '${sanitizedInvNumber}'
        ${invoiceTypeFilter}
        ORDER BY e.ID ASC
    `);
    return normalizeInvoiceRows(result);
};

const normalizeText = (value) =>
    value === null || value === undefined ? "" : String(value).trim();

const toFiniteNumber = (value, fallback = null) => {
    const number = Number(value);
    return Number.isFinite(number) ? number : fallback;
};

const decimalText = (value) => {
    const number = toFiniteNumber(value, 0);
    return Math.round((number + Number.EPSILON) * 100) / 100;
};

const getRowValue = (row = {}, keys = []) => {
    for (const key of keys) {
        const value = row[key];
        if (value !== null && value !== undefined && String(value).trim() !== "") {
            return value;
        }
    }
    return "";
};

const getChargeReasonOptions = async () => {
    const rows = await db.queryUnsafe(`
        SELECT Value, DisplayName
        FROM EM_ChargeReason
        ORDER BY DisplayName
    `);

    return rows
        .map((row) => ({
            Value: normalizeText(getRowValue(row, ["Value", "value", "VALUE"])),
            DisplayName: normalizeText(getRowValue(row, ["DisplayName", "Displayname", "displayName", "DISPLAYNAME"]))
        }))
        .filter((row) => row.Value || row.DisplayName);
};

const saveLineAsDocumentCharge = async ({
    invoiceNumber,
    rowId,
    lineId,
    reasonCode,
    reasonName,
    docType = null
}) => {
    const safeInvoiceNumber = normalizeText(invoiceNumber);
    const safeReasonCode = normalizeText(reasonCode);
    const safeReasonName = normalizeText(reasonName);
    const safeRowId = toFiniteNumber(rowId, null);
    const safeLineId = normalizeText(lineId);
    const numericDocType = toFiniteNumber(docType, null);

    if (!safeInvoiceNumber) {
        const error = new Error("Invoice number is required");
        error.statusCode = 400;
        throw error;
    }

    if (!safeReasonCode || !safeReasonName) {
        const error = new Error("Charge reason is required");
        error.statusCode = 400;
        throw error;
    }

    if (safeRowId === null && !safeLineId) {
        const error = new Error("Invoice line is required");
        error.statusCode = 400;
        throw error;
    }

    const whereValues = [safeInvoiceNumber];
    const docTypeFilter = numericDocType === null ? "" : ` AND DocType = @p${whereValues.length}`;
    if (numericDocType !== null) whereValues.push(numericDocType);

    const rows = await db.queryStatement(
        `SELECT
            ID,
            DocType,
            invoice_no,
            invoice_line_id,
            invoice_line_net_amt,
            inv_line_net_total,
            item_vat_cat_code,
            item_vat_rate,
            vat_cat_code,
            vat_cat_rate
         FROM ${INVOICE_TABLE}
         WHERE invoice_no = @p0
         ${docTypeFilter}
         ORDER BY ID ASC`,
        whereValues
    );

    const targetRow = rows.find((row) => safeRowId !== null && Number(row.ID) === safeRowId)
        || rows.find((row) => safeLineId && normalizeText(row.invoice_line_id) === safeLineId);

    if (!targetRow) {
        const error = new Error("Selected invoice line was not found");
        error.statusCode = 404;
        throw error;
    }

    const chargeAmount = toFiniteNumber(targetRow.invoice_line_net_amt, null);
    if (chargeAmount === null) {
        const error = new Error("Selected line net amount is missing");
        error.statusCode = 400;
        throw error;
    }

    const totalLineNet = toFiniteNumber(targetRow.inv_line_net_total, null)
        ?? rows.reduce((sum, row) => sum + toFiniteNumber(row.invoice_line_net_amt, 0), 0);
    const calculatedBaseAmount = totalLineNet - chargeAmount;
    const baseAmount = calculatedBaseAmount > 0 ? calculatedBaseAmount : totalLineNet;
    const percent = baseAmount > 0 ? (chargeAmount / baseAmount) * 100 : 0;
    const vatCategory = normalizeText(targetRow.item_vat_cat_code || targetRow.vat_cat_code);
    const vatRate = toFiniteNumber(targetRow.item_vat_rate, toFiniteNumber(targetRow.vat_cat_rate, 0));
    await db.withTransaction(async (tx) => {
        await tx.executeStatement(
            `UPDATE ${INVOICE_TABLE}
             SET syntax_bind_qualifi = @p2,
                 doc_char_reason_code = @p3,
                 doc_charge_reason = @p4,
                 doc_charge_percent = @p5,
                 doc_charge_amount = @p6,
                 total_doc_charges = @p6,
                 doc_charge_base_amt = @p7,
                 doc_charge_vat_cat = @p8,
                 doc_charge_vat_rate = @p9
             WHERE invoice_no = @p0
             ${numericDocType === null ? "" : "AND DocType = @p1"}`,
            [
                safeInvoiceNumber,
                numericDocType,
                true,
                safeReasonCode,
                safeReasonName,
                percent,
                decimalText(chargeAmount),
                decimalText(baseAmount),
                vatCategory,
                decimalText(vatRate)
            ]
        );

        await tx.executeStatement(
            `UPDATE ${INVOICE_TABLE}
             SET Isdeleted = 1
             WHERE ID = @p0
             AND invoice_no = @p1
             ${numericDocType === null ? "" : "AND DocType = @p2"}`,
            [targetRow.ID, safeInvoiceNumber, numericDocType]
        );
    });

    return {
        invoiceNumber: safeInvoiceNumber,
        lineId: normalizeText(targetRow.invoice_line_id),
        rowId: targetRow.ID,
        reasonCode: safeReasonCode,
        reasonName: safeReasonName,
        amount: decimalText(chargeAmount),
        baseAmount: decimalText(baseAmount),
        percent,
        vatCategory,
        vatRate: decimalText(vatRate)
    };
};

const getNextOutDocumentId = async (client = db) => {
    const rows = await client.queryUnsafe(`
        SELECT MAX(ID) AS MaxID
        FROM ${OUT_DOCUMENT_TABLE}
    `);
    const maxId = Number(getRowValue(rows[0], ["MaxID", "MaxId", "MAXID", "maxId", "maxid"]));

    return Number.isFinite(maxId) ? maxId + 1 : 1;
};

const normalizeAttachmentContent = (value) => {
    if (!value) return null;
    if (Buffer.isBuffer(value)) return value;
    if (value instanceof ArrayBuffer) return Buffer.from(value);
    if (ArrayBuffer.isView(value)) {
        return Buffer.from(value.buffer, value.byteOffset, value.byteLength);
    }
    if (value.type === "Buffer" && Array.isArray(value.data)) {
        return Buffer.from(value.data);
    }

    const rawValue = String(value).trim();
    if (!rawValue) return null;

    if (/^0x[0-9a-f]+$/i.test(rawValue)) {
        return Buffer.from(rawValue.slice(2), "hex");
    }

    const base64Value = rawValue.startsWith("data:") && rawValue.includes(",")
        ? rawValue.slice(rawValue.indexOf(",") + 1)
        : rawValue;
    const buffer = Buffer.from(base64Value.replace(/\s/g, ""), "base64");

    return buffer.length ? buffer : null;
};

const normalizeOutDocumentRecord = (row = {}) => {
    const hasAttachment = Number(getRowValue(row, ["has_attached_document", "HAS_ATTACHED_DOCUMENT"])) === 1;

    return {
        ID: getRowValue(row, ["ID", "Id", "id"]),
        EinvoiceID: getRowValue(row, ["EinvoiceID", "einvoiceId", "einvoiceid"]),
        invoice_no: normalizeText(getRowValue(row, ["invoice_no", "InvoiceNo", "INVOICE_NO"])),
        invoiced_obj_id: normalizeText(getRowValue(row, ["invoiced_obj_id"])),
        inv_obj_scheme_id: normalizeText(getRowValue(row, ["inv_obj_scheme_id"])),
        document_type_code: normalizeText(getRowValue(row, ["document_type_code"])),
        support_doc_ref: normalizeText(getRowValue(row, ["support_doc_ref"])),
        support_doc_desc: normalizeText(getRowValue(row, ["support_doc_desc"])),
        attach_doc_mime_code: normalizeText(getRowValue(row, ["attach_doc_mime_code"])),
        attach_doc_filename: normalizeText(getRowValue(row, ["attach_doc_filename"])),
        external_doc_loc: normalizeText(getRowValue(row, ["external_doc_loc"])),
        has_attached_document: hasAttachment ? 1 : 0
    };
};

const outDocumentLookupWhere = (docType = INVOICE_DOC_TYPE) => `(
            odoc.invoice_no = @p0
            OR odoc.ID IN (
                SELECT e.outDocument
                FROM ${INVOICE_TABLE} e
                WHERE e.invoice_no = @p0
                  AND e.outDocument IS NOT NULL
                  AND ${buildDocTypeFilter("e", docType)}
            )
            OR odoc.EinvoiceID IN (
                SELECT e.ID
                FROM ${INVOICE_TABLE} e
                WHERE e.invoice_no = @p0
                  AND ${buildDocTypeFilter("e", docType)}
            )
        )`;

const OUT_DOCUMENT_SELECT_FIELDS = `
            odoc.ID,
            odoc.EinvoiceID,
            odoc.invoice_no,
            odoc.invoiced_obj_id,
            odoc.inv_obj_scheme_id,
            odoc.document_type_code,
            odoc.support_doc_ref,
            odoc.support_doc_desc,
            odoc.attach_doc_mime_code,
            odoc.attach_doc_filename,
            odoc.external_doc_loc,
            CASE WHEN odoc.attached_document IS NULL THEN 0 ELSE 1 END AS has_attached_document`;

const getInvoiceRowsForOutDocument = async (invoiceNumber, docType = INVOICE_DOC_TYPE, client = db) =>
    client.queryStatement(
        `SELECT
            e.ID,
            e.outDocument
         FROM ${INVOICE_TABLE} e
         WHERE e.invoice_no = @p0
           AND ${buildDocTypeFilter("e", docType)}
         ORDER BY e.ID ASC`,
        [invoiceNumber]
    );

const getInvoiceOutDocument = async (invNumber, docType = INVOICE_DOC_TYPE, client = db) => {
    const safeInvoiceNumber = normalizeText(invNumber);

    if (!safeInvoiceNumber) return null;

    const rows = await client.queryStatement(
        `SELECT TOP 1
            ${OUT_DOCUMENT_SELECT_FIELDS}
         FROM ${OUT_DOCUMENT_TABLE} odoc
         WHERE ${outDocumentLookupWhere(docType)}
         ORDER BY odoc.ID DESC`,
        [safeInvoiceNumber]
    );

    return rows[0] ? normalizeOutDocumentRecord(rows[0]) : null;
};

const getObjectIdentifierOptions = async () => {
    const statements = [
        `
            SELECT Value, DisplayName
            FROM EM_ObjectIdentifier
            WHERE Value IS NOT NULL
            ORDER BY DisplayName
        `,
        `
            SELECT [Value] AS Value, [DisplayName] AS DisplayName
            FROM [EM_ObjectIdentifier]
            WHERE [Value] IS NOT NULL
            ORDER BY [DisplayName]
        `
    ];

    for (const statement of statements) {
        try {
            const rows = await db.queryUnsafe(statement);
            return rows
                .map((row) => ({
                    Value: normalizeText(getRowValue(row, ["Value", "value", "VALUE"])),
                    DisplayName: normalizeText(getRowValue(row, ["DisplayName", "Displayname", "displayName", "DISPLAYNAME"]))
                }))
                .filter((row) => row.Value || row.DisplayName);
        } catch {
            // Try the next identifier style, then fall back to an empty list.
        }
    }

    return [];
};

const getInvoiceOutDocumentOptions = async () => ({
    objectIdentifiers: await getObjectIdentifierOptions(),
    mimeCodes: OUT_DOCUMENT_MIME_CODE_OPTIONS
});

const getInvoiceOutDocumentAttachment = async (invNumber, docType = INVOICE_DOC_TYPE) => {
    const safeInvoiceNumber = normalizeText(invNumber);

    if (!safeInvoiceNumber) return null;

    const rows = await db.queryStatement(
        `SELECT TOP 1
            ${OUT_DOCUMENT_SELECT_FIELDS},
            odoc.attached_document
         FROM ${OUT_DOCUMENT_TABLE} odoc
         WHERE ${outDocumentLookupWhere(docType)}
           AND odoc.attached_document IS NOT NULL
         ORDER BY odoc.ID DESC`,
        [safeInvoiceNumber]
    );
    const row = rows[0];
    const content = normalizeAttachmentContent(row?.attached_document);

    if (!content) return null;

    return {
        content,
        mimeCode: row.attach_doc_mime_code || "application/octet-stream",
        filename: row.attach_doc_filename,
        outDocument: normalizeOutDocumentRecord(row)
    };
};

const buildOutDocumentValues = ({
    invoiceId,
    invoiceNumber,
    outDocument,
    includeAttachedDocument
}) => {
    const valuesByColumn = {
        EinvoiceID: invoiceId,
        invoice_no: invoiceNumber,
        invoiced_obj_id: outDocument.invoiced_obj_id,
        inv_obj_scheme_id: outDocument.inv_obj_scheme_id,
        document_type_code: outDocument.document_type_code,
        support_doc_ref: outDocument.support_doc_ref,
        support_doc_desc: outDocument.support_doc_desc,
        attached_document: normalizeAttachmentContent(outDocument.attached_document),
        attach_doc_mime_code: outDocument.attach_doc_mime_code,
        attach_doc_filename: outDocument.attach_doc_filename,
        external_doc_loc: outDocument.external_doc_loc
    };

    if (!includeAttachedDocument) {
        delete valuesByColumn.attached_document;
    }

    return valuesByColumn;
};

const insertInvoiceOutDocument = async ({ invoiceId, invoiceNumber, outDocument, client = db }) => {
    const outDocumentId = await getNextOutDocumentId(client);
    const valuesByColumn = buildOutDocumentValues({
        invoiceId,
        invoiceNumber,
        outDocument,
        includeAttachedDocument: true
    });
    valuesByColumn.ID = outDocumentId;
    const columns = ["ID", "EinvoiceID", "invoice_no", ...OUT_DOCUMENT_COLUMNS];
    const columnSql = columns.map(quoteIdentifier).join(", ");
    const valueSql = columns.map((_, index) => `@p${index}`).join(", ");
    const values = columns.map((column) =>
        valuesByColumn[column] === undefined ? null : valuesByColumn[column]
    );

    await client.executeStatement(
        `INSERT INTO ${OUT_DOCUMENT_TABLE} (${columnSql})
         VALUES (${valueSql})`,
        values
    );

    return outDocumentId;
};

const updateInvoiceOutDocument = async ({
    outDocumentId,
    invoiceId,
    invoiceNumber,
    outDocument,
    attachedDocumentProvided,
    client = db
}) => {
    const valuesByColumn = buildOutDocumentValues({
        invoiceId,
        invoiceNumber,
        outDocument,
        includeAttachedDocument: attachedDocumentProvided
    });
    const columns = Object.keys(valuesByColumn);
    const setSql = columns
        .map((column, index) => `${quoteIdentifier(column)} = @p${index}`)
        .join(", ");
    const values = columns.map((column) =>
        valuesByColumn[column] === undefined ? null : valuesByColumn[column]
    );

    values.push(outDocumentId);

    await client.executeStatement(
        `UPDATE ${OUT_DOCUMENT_TABLE}
         SET ${setSql}
         WHERE ID = @p${values.length - 1}`,
        values
    );

    return outDocumentId;
};

const saveInvoiceOutDocument = async ({
    invoiceNumber,
    docType = INVOICE_DOC_TYPE,
    outDocument,
    attachedDocumentProvided = false
}) => {
    const safeInvoiceNumber = normalizeText(invoiceNumber);

    if (!safeInvoiceNumber) {
        const error = new Error("Invoice number is required");
        error.statusCode = 400;
        throw error;
    }

    const savedOutDocumentId = await db.withTransaction(async (tx) => {
        const invoiceRows = await getInvoiceRowsForOutDocument(safeInvoiceNumber, docType, tx);
        const invoiceId = getRowValue(invoiceRows[0], ["ID", "Id", "id"]);

        if (!invoiceId) {
            const error = new Error("Invoice was not found");
            error.statusCode = 404;
            throw error;
        }

        const existingOutDocument = await getInvoiceOutDocument(safeInvoiceNumber, docType, tx);
        const linkedOutDocumentId = getRowValue(invoiceRows[0], ["outDocument", "OutDocument", "OUTDOCUMENT"]);
        const outDocumentId = existingOutDocument?.ID || linkedOutDocumentId;
        const savedId = outDocumentId
            ? await updateInvoiceOutDocument({
                outDocumentId,
                invoiceId,
                invoiceNumber: safeInvoiceNumber,
                outDocument,
                attachedDocumentProvided,
                client: tx
            })
            : await insertInvoiceOutDocument({
                invoiceId,
                invoiceNumber: safeInvoiceNumber,
                outDocument,
                client: tx
            });

        await tx.executeStatement(
            `UPDATE ${INVOICE_TABLE}
             SET outDocument = @p0
             WHERE invoice_no = @p1
               AND ${buildDocTypeFilter("", docType)}`,
            [savedId, safeInvoiceNumber]
        );

        return savedId;
    });

    if (!savedOutDocumentId) return null;
    return getInvoiceOutDocument(safeInvoiceNumber, docType);
};

const getOutboundTransactions = async (instanceIdentifier) => {
    const safeInstanceIdentifier = String(instanceIdentifier || "").trim();

    if (!safeInstanceIdentifier) return [];

    return db.queryStatement(
        `SELECT
            RootInstance,
            RootTransType,
            TransactionId,
            TransmissionType,
            Status,
            SenderParticipantId,
            ReceiverPartiId,
            InstanceIdentifier,
            RefInstance,
            ErrorDetails,
            C5DispatchStatus,
            CreatedDate,
            LastModifiedDate,
            HasFile,
            InsertedOn
         FROM E_Get_Out_Trans
         WHERE RootInstance = @p0
         ORDER BY
            CASE LOWER(LTRIM(RTRIM(TransmissionType)))
                WHEN 'outbound' THEN 1
                WHEN 'c2_tdd_outbound' THEN 2
                WHEN 'mls_inbound' THEN 3
                WHEN 'c2_tdd_mls_inbound' THEN 4
                ELSE 5
            END,
            CreatedDate DESC,
            InsertedOn DESC`,
        [safeInstanceIdentifier]
    );
};


module.exports = {
    INVOICE_DOC_TYPE,
    PURCHASE_DOC_TYPE,
    getAllInvoices,
    getInvoiceDetailsByNumbers,
    getDashboardCounts,
    getPendingAndFailedEntries,
    getInvoicesByType,
    getPurchaseExportRows,
    getPurchaseExportColumns,
    getPurchaseTypeCounts,
    getFailedInvoiceErrors,
    getArtaxInvoiceErrors,
    getFilterDebugStats,
    getInvoiceResponseLogs,
    getArtaxErrorsResponse,
    getInvoiceDetails,
    getChargeReasonOptions,
    saveLineAsDocumentCharge,
    getInvoiceOutDocument,
    getInvoiceOutDocumentAttachment,
    getInvoiceOutDocumentOptions,
    saveInvoiceOutDocument,
    getOutboundTransactions
};
