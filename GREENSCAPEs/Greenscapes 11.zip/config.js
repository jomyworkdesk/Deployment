window.ARTAX_CONFIG = {
  API_URL: 'http://192.168.1.58:1051'
};
