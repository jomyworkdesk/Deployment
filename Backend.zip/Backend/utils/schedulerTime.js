const SCHEDULER_UTC_OFFSET_MS = 4 * 60 * 60 * 1000;

const getSqlLocalDateTime = (date = new Date()) => {
    const localDate = new Date(date.getTime() + SCHEDULER_UTC_OFFSET_MS);
    const year = localDate.getUTCFullYear();
    const month = String(localDate.getUTCMonth() + 1).padStart(2, "0");
    const day = String(localDate.getUTCDate()).padStart(2, "0");
    const hours = String(localDate.getUTCHours()).padStart(2, "0");
    const minutes = String(localDate.getUTCMinutes()).padStart(2, "0");
    const seconds = String(localDate.getUTCSeconds()).padStart(2, "0");

    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

module.exports = {
    SCHEDULER_UTC_OFFSET_MS,
    getSqlLocalDateTime
};
