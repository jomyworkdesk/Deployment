@echo off
if exist "C:\node32\node.exe" (
  set "PATH=C:\node32;%PATH%"
  "C:\node32\node.exe" %*
  exit /b %ERRORLEVEL%
)

node %*
