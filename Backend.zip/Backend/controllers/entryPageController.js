const entryPageRepository = require("../repositories/entryPageRepository");

const getMetadata = async (req, res) => {
    try {
        const metadata = await entryPageRepository.getEntryMetadata();
        return res.json(metadata);
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || "Failed to load entry page metadata"
        });
    }
};

const getColumns = async (req, res) => {
    try {
        const columns = await entryPageRepository.getInvoiceColumns();
        return res.json({ columns });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || "Failed to load E_Invoicing columns"
        });
    }
};

const getTransactionTypes = async (req, res) => {
    try {
        const transactionTypes = await entryPageRepository.getInvoiceTransactionTypes();
        return res.json({ transactionTypes });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || "Failed to load invoice transaction types"
        });
    }
};

const getInvoiceTypes = async (req, res) => {
    try {
        const invoiceTypes = await entryPageRepository.getInvoiceTypes();
        return res.json({ invoiceTypes });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || "Failed to load invoice types"
        });
    }
};

const getPaymentTypes = async (req, res) => {
    try {
        const paymentTypes = await entryPageRepository.getPaymentTypeCodes();
        return res.json({ paymentTypes });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || "Failed to load payment types"
        });
    }
};

const getCreditNoteReasons = async (req, res) => {
    try {
        const creditNoteReasons = await entryPageRepository.getCreditNoteReasonCodes();
        return res.json({ creditNoteReasons });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || "Failed to load credit note reasons"
        });
    }
};

const getEntries = async (req, res) => {
    try {
        const result = await entryPageRepository.getEntries({
            fromDate: req.query.fromDate,
            toDate: req.query.toDate,
            docType: req.query.docType,
            columns: [req.query.column1, req.query.column2].filter(Boolean)
        });

        return res.json(result);
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: error.message || "Failed to load entry page invoices"
        });
    }
};

const updateAdditionalFields = async (req, res) => {
    try {
        const updated = await entryPageRepository.updateAdditionalFields({
            invoiceNumbers: req.body?.invoiceNumbers,
            docType: req.body?.docType,
            transactionTypeCode: req.body?.transactionTypeCode,
            invoiceTypeCode: req.body?.invoiceTypeCode,
            paymentTypeCode: req.body?.paymentTypeCode,
            creditNoteReasonCode: req.body?.creditNoteReasonCode
        });

        return res.json({
            success: true,
            updated,
            message: `${updated} invoice row(s) updated successfully`
        });
    } catch (error) {
        return res.status(400).json({
            success: false,
            message: error.message || "Failed to update additional fields"
        });
    }
};

module.exports = {
    getMetadata,
    getColumns,
    getTransactionTypes,
    getInvoiceTypes,
    getPaymentTypes,
    getCreditNoteReasons,
    getEntries,
    updateAdditionalFields
};
