const createOdbcClient = require("./dbClientFactory");

const requireEnv = (name) => {
    const value = process.env[name];
    if (!value) {
        throw new Error(`Missing required environment variable: ${name}`);
    }
    return value;
};

const getConnectionString = () => {
    return `DSN=${requireEnv("SECONDARY_DB_DSN")};`;
};

module.exports = createOdbcClient({
    name: requireEnv("SECONDARY_DB_NAME"),
    getConnectionString
});
