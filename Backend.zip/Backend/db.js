const createOdbcClient = require("./dbClientFactory");

const requireEnv = (name) => {
    const value = process.env[name];
    if (!value) {
        throw new Error(`Missing required environment variable: ${name}`);
    }
    return value;
};

const hasPrimaryConfig = Boolean(process.env.PRIMARY_DB_DSN || process.env.PRIMARY_DB_NAME);
const primaryDsnEnv = hasPrimaryConfig ? "PRIMARY_DB_DSN" : "SECONDARY_DB_DSN";
const primaryNameEnv = hasPrimaryConfig ? "PRIMARY_DB_NAME" : "SECONDARY_DB_NAME";

const getConnectionString = () => {
    return `DSN=${requireEnv(primaryDsnEnv)};`;
};

module.exports = createOdbcClient({
    name: requireEnv(primaryNameEnv),
    getConnectionString
});
