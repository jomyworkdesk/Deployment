const { syncInvoices } = require("../services/invoiceSyncService");
const { saveCronLog } = require("../repositories/cronLogRepository");

const writeCronLog = async (logDetails) => {
    try {
        await saveCronLog({
            type: "sync",
            logDetails
        });
    } catch (logError) {
        console.error(
            `[SageSync ${new Date().toISOString()}] cron log error: ${logError.message || logError}`
        );
    }
};

async function syncInvoicesJob() {
    try {
        const result = await syncInvoices();
        const status = result?.skipped
            ? "skipped"
            : result?.noNewTransactions
                ? "completed-no-op"
                : "completed";

        await writeCronLog({
            status,
            ...result
        });

        return result;
    } catch (error) {
        console.error(
            `[SageSync ${new Date().toISOString()}] sync failed: ${error.message || error}`
        );

        await writeCronLog({
            status: "error",
            message: error.message || "Sage Transaction Sync cron failed"
        });

        throw error;
    }
}

module.exports = syncInvoicesJob;
