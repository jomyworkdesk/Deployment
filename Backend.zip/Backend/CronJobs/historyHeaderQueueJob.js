const {
    getLastDocuments,
    getNewHistoryDocuments,
    queueHistoryDocuments
} = require("../repositories/historyHeaderQueueRepository");
const { saveCronLog } = require("../repositories/cronLogRepository");

let isRunning = false;

const writeCronLog = async (logDetails) => {
    const details = {
        cron: "history-header-queue",
        ...logDetails
    };

    try {
        await saveCronLog({
            type: "history-header-queue",
            logDetails: details
        });
    } catch (logError) {
        console.error(
            `[HistoryHeaderQueue ${new Date().toISOString()}] cron log insert failed: ${logError.message || logError}`
        );
    }

    console.log(
        `[HistoryHeaderQueue ${new Date().toISOString()}] ${JSON.stringify(details)}`
    );
};

const flattenDocuments = (documentsByType) =>
    documentsByType.reduce((documents, typeDocuments) => documents.concat(typeDocuments), []);

async function historyHeaderQueueJob() {
    if (isRunning) {
        const skippedResult = {
            skipped: true,
            message: "HistoryHeader queue cron is already running"
        };
        await writeCronLog(skippedResult);
        return skippedResult;
    }

    isRunning = true;

    try {
        const lastDocuments = await getLastDocuments();
        const documentsByType = [];

        for (const lastDocument of lastDocuments) {
            documentsByType.push(await getNewHistoryDocuments(lastDocument));
        }

        const newDocuments = flattenDocuments(documentsByType);

        if (newDocuments.length === 0) {
            const result = {
                checkedDocumentTypes: lastDocuments.length,
                found: 0,
                inserted: 0,
                updatedLastDocuments: 0,
                message: "No new HistoryHeader document exists"
            };
            await writeCronLog(result);
            return result;
        }

        const queueResult = await queueHistoryDocuments(newDocuments);
        const result = {
            checkedDocumentTypes: lastDocuments.length,
            found: newDocuments.length,
            ...queueResult
        };

        await writeCronLog(result);
        return result;
    } catch (error) {
        await writeCronLog({
            status: "error",
            message: error.message || "HistoryHeader queue cron failed"
        });
        throw error;
    } finally {
        isRunning = false;
    }
}

module.exports = historyHeaderQueueJob;
