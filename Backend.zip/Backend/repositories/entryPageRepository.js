const db = require("../dbSecondary");

const INVOICE_TABLE = "E_Invoicing";
const QUEUE_TABLE = "E_InvoiceQueue";
const INVOICE_DOC_TYPE = 3;
const CREDIT_NOTE_DOC_TYPE = 4;

const normalizeSqlDate = (value) => {
    if (typeof value !== "string") return null;
    return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
};

const addDaysToSqlDate = (value, days) => {
    const safeDate = normalizeSqlDate(value);
    if (!safeDate) return null;

    const date = new Date(`${safeDate}T00:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
};

const toSqlDateTimeStart = (value) => {
    const safeDate = normalizeSqlDate(value);
    return safeDate ? `${safeDate} 00:00:00.000` : null;
};

const toSqlNextDateTimeStart = (value) => {
    const safeDate = addDaysToSqlDate(value, 1);
    return safeDate ? `${safeDate} 00:00:00.000` : null;
};

const sqlTimestampLiteral = (value) => `{ts '${value}'}`;

const toOptionRows = (values) =>
    values
        .filter(Boolean)
        .map((value) => ({
            value,
            label: value
        }));

const getRowValue = (row, candidates) => {
    const rowKeys = Object.keys(row || {});
    const matchedKey = rowKeys.find((key) =>
        candidates.some((candidate) => candidate.toLowerCase() === key.toLowerCase())
    );
    return matchedKey ? row[matchedKey] : "";
};

const runFirstSuccessfulQuery = async (statements) => {
    let lastError = null;

    for (const statement of statements) {
        try {
            return await db.queryUnsafe(statement);
        } catch (error) {
            lastError = error;
        }
    }

    throw lastError || new Error("No metadata query was executed");
};

const normalizeDocType = (value) => {
    const docType = Number(value);
    return Number.isFinite(docType) ? docType : INVOICE_DOC_TYPE;
};

const buildQueueDateFilter = (fromDate, toDate) => {
    const safeFromDate = toSqlDateTimeStart(fromDate);
    const safeToDate = toSqlNextDateTimeStart(toDate);
    const conditions = [];

    if (safeFromDate) {
        conditions.push(`q.InvDate >= ${sqlTimestampLiteral(safeFromDate)}`);
    }

    if (safeToDate) {
        conditions.push(`q.InvDate < ${sqlTimestampLiteral(safeToDate)}`);
    }

    return conditions.length ? ` AND ${conditions.join(" AND ")}` : "";
};

const getInvoiceColumns = async () => {
    try {
        const rows = await db.query`
            SELECT [COLUMN_NAME]
            FROM [INFORMATION_SCHEMA].[COLUMNS]
            WHERE [TABLE_NAME] = ${INVOICE_TABLE}
            ORDER BY [ORDINAL_POSITION]
        `;

        const columns = rows
            .map((row) => row.COLUMN_NAME)
            .filter(Boolean);

        if (columns.length) {
            return toOptionRows(columns);
        }
    } catch {
        // Some ODBC drivers do not expose INFORMATION_SCHEMA reliably.
    }

    const sampleRows = await runFirstSuccessfulQuery([
        `SELECT TOP 1 * FROM ${INVOICE_TABLE}`,
        `SELECT TOP 1 * FROM [${INVOICE_TABLE}]`,
        `SELECT TOP 1 * FROM "${INVOICE_TABLE}"`
    ]);

    return toOptionRows(Object.keys(sampleRows[0] || {}));
};

const resolveInvoiceColumns = async (columns = []) => {
    const requestedColumns = Array.isArray(columns)
        ? columns.map((column) => String(column || "").trim()).filter(Boolean)
        : [];

    if (requestedColumns.length === 0) {
        return [];
    }

    const availableColumns = (await getInvoiceColumns()).map((column) => column.value);
    return requestedColumns
        .map((requestedColumn) =>
            availableColumns.find((column) => column.toLowerCase() === requestedColumn.toLowerCase())
        )
        .filter((column) => /^[A-Za-z_][A-Za-z0-9_]*$/.test(column));
};

const getInvoiceTransactionTypes = async () => {
    const rows = await runFirstSuccessfulQuery([
        `
            SELECT [value] AS [Value], [Displayname] AS [DisplayName]
            FROM [EM_InvoiceTransaType]
            WHERE [value] IS NOT NULL
            ORDER BY [Displayname]
        `,
        `
            SELECT [Value], [Displayname] AS [DisplayName]
            FROM [EM_InvoiceTransaType]
            WHERE [Value] IS NOT NULL
            ORDER BY [Displayname]
        `,
        `
            SELECT "value" AS "Value", "Displayname" AS "DisplayName"
            FROM "EM_InvoiceTransaType"
            WHERE "value" IS NOT NULL
            ORDER BY "Displayname"
        `,
        `
            SELECT [Mapped] AS [Value], [DisplayName]
            FROM [EM_InvoiceTransactionType]
            WHERE [Mapped] IS NOT NULL
            ORDER BY [DisplayName]
        `
    ]);

    return rows
        .map((row) => ({
            Value: getRowValue(row, ["Value", "value", "Mapped"]),
            DisplayName: getRowValue(row, ["DisplayName", "Displayname"])
        }))
        .filter((row) => row.Value);
};

const getEntryMetadata = async () => {
    const [columnsResult, transactionTypesResult] = await Promise.allSettled([
        getInvoiceColumns(),
        getInvoiceTransactionTypes()
    ]);

    return {
        columns: columnsResult.status === "fulfilled" ? columnsResult.value : [],
        transactionTypes: transactionTypesResult.status === "fulfilled" ? transactionTypesResult.value : [],
        invoiceTypes: [
            { Value: "380", DisplayName: "Commercial invoice" },
            { Value: "389", DisplayName: "Self Billed Invoice" }
        ],
        errors: {
            columns: columnsResult.status === "rejected" ? columnsResult.reason.message : null,
            transactionTypes: transactionTypesResult.status === "rejected" ? transactionTypesResult.reason.message : null
        }
    };
};

const getInvoiceTypes = async () => [
    { Value: "380", DisplayName: "Commercial invoice" },
    { Value: "389", DisplayName: "Self Billed Invoice" }
];

const getPaymentTypeCodes = async () => {
    const rows = await runFirstSuccessfulQuery([
        `
            SELECT "Value" AS "Value", "DisplayName" AS "DisplayName"
            FROM "EM_PaymentTypeCode"
            WHERE "Value" IS NOT NULL
            ORDER BY "DisplayName"
        `,
        `
            SELECT [Value] AS [Value], [DisplayName] AS [DisplayName]
            FROM [EM_PaymentTypeCode]
            WHERE [Value] IS NOT NULL
            ORDER BY [DisplayName]
        `,
        `
            SELECT Value, DisplayName
            FROM EM_PaymentTypeCode
            WHERE Value IS NOT NULL
            ORDER BY DisplayName
        `
    ]);

    return rows
        .map((row) => ({
            Value: getRowValue(row, ["Value", "value"]),
            DisplayName: getRowValue(row, ["DisplayName", "Displayname"])
        }))
        .filter((row) => row.Value);
};

const getCreditNoteReasonCodes = async () => {
    const rows = await runFirstSuccessfulQuery([
        `
            SELECT "Value" AS "Value", "DisplayName" AS "DisplayName"
            FROM "EM_CreditNoteReason"
            WHERE "Value" IS NOT NULL
            ORDER BY "DisplayName"
        `,
        `
            SELECT [Value] AS [Value], [DisplayName] AS [DisplayName]
            FROM [EM_CreditNoteReason]
            WHERE [Value] IS NOT NULL
            ORDER BY [DisplayName]
        `,
        `
            SELECT Value, DisplayName
            FROM EM_CreditNoteReason
            WHERE Value IS NOT NULL
            ORDER BY DisplayName
        `
    ]);

    return rows
        .map((row) => ({
            Value: getRowValue(row, ["Value", "value"]),
            DisplayName: getRowValue(row, ["DisplayName", "Displayname"])
        }))
        .filter((row) => row.Value);
};

const getEntries = async ({ fromDate, toDate, docType, columns = [] }) => {
    const safeDocType = normalizeDocType(docType);
    const safeColumns = await resolveInvoiceColumns(columns);
    const dynamicSelect = safeColumns
        .slice(0, 2)
        .map((column, index) => `,\n            e.${column} AS DynamicColumn${index + 1}Value`)
        .join("");

    const rows = await db.queryUnsafe(`
        SELECT
            q.QueueID,
            q.AutoIndex,
            q.DocType,
            q.InvNumber,
            q.InvDate,
            q.CreatedAt,
            q.Status,
            q.IsArtaxError,
            q.ErrorMessage,
            q.RetryCount,
            COALESCE(e.buyer_name, '') AS Customer,
            e.inv_total_with_tax AS Amount
            ${dynamicSelect}
        FROM ${QUEUE_TABLE} q
        LEFT JOIN (
            SELECT invoice_no, DocType, MIN(ID) AS FirstID
            FROM ${INVOICE_TABLE}
            GROUP BY invoice_no, DocType
        ) firstInvoice
            ON q.InvNumber = firstInvoice.invoice_no AND q.DocType = firstInvoice.DocType
        LEFT JOIN ${INVOICE_TABLE} e
            ON e.invoice_no = firstInvoice.invoice_no
            AND e.DocType = firstInvoice.DocType
            AND e.ID = firstInvoice.FirstID
        WHERE q.DocType = ${safeDocType}
        AND q.Status IN ('1', '4', '6')
        ${buildQueueDateFilter(fromDate, toDate)}
        ORDER BY q.InvDate DESC, q.QueueID DESC
    `);

    const pending = rows.filter((row) => String(row.Status) === "1").length;
    const failed = rows.filter((row) => String(row.Status) === "4").length;
    const issues = rows.filter((row) => ["4", "6"].includes(String(row.Status))).length;

    return {
        counts: {
            total: rows.length,
            pending,
            failed,
            issues,
            error: failed
        },
        entries: rows,
        selectedColumns: safeColumns
    };
};

const updateAdditionalFields = async ({
    invoiceNumbers,
    docType,
    transactionTypeCode,
    invoiceTypeCode,
    paymentTypeCode,
    creditNoteReasonCode
}) => {
    const safeDocType = normalizeDocType(docType);
    const safeInvoiceNumbers = Array.isArray(invoiceNumbers)
        ? invoiceNumbers.map((value) => String(value || "").trim()).filter(Boolean)
        : [];

    if (safeInvoiceNumbers.length === 0) {
        throw new Error("At least one invoice number is required");
    }

    if (!transactionTypeCode && !invoiceTypeCode && !paymentTypeCode && !(safeDocType === CREDIT_NOTE_DOC_TYPE && creditNoteReasonCode)) {
        throw new Error("Select at least one additional field value");
    }

    const updateFields = [];
    const values = [];

    if (transactionTypeCode) {
        updateFields.push(`inv_txn_typ_cod = @p${values.length}`);
        values.push(transactionTypeCode);
    }

    if (invoiceTypeCode) {
        updateFields.push(`invoice_type_code = @p${values.length}`);
        values.push(invoiceTypeCode);
    }

    if (paymentTypeCode) {
        updateFields.push(`payment_type_code = @p${values.length}`);
        values.push(paymentTypeCode);
    }

    if (safeDocType === CREDIT_NOTE_DOC_TYPE && creditNoteReasonCode) {
        updateFields.push(`credit_reason_code = @p${values.length}`);
        values.push(creditNoteReasonCode);
    }

    const invoicePlaceholders = safeInvoiceNumbers
        .map((_, index) => `@p${values.length + index}`)
        .join(", ");
    values.push(...safeInvoiceNumbers);
    values.push(safeDocType);

    return db.executeStatement(
        `UPDATE ${INVOICE_TABLE}
         SET ${updateFields.join(", ")}
         WHERE invoice_no IN (${invoicePlaceholders})
         AND DocType = @p${values.length - 1}`,
        values
    );
};

module.exports = {
    getEntryMetadata,
    getInvoiceColumns,
    getInvoiceTransactionTypes,
    getInvoiceTypes,
    getPaymentTypeCodes,
    getCreditNoteReasonCodes,
    getEntries,
    updateAdditionalFields
};
