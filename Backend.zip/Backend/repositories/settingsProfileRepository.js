const db = require("../dbSecondary");

const getDbClient = () => db;

const normalizeWebLoginRow = (row) => {
    if (!row) return null;

    return {
        ...row,
        ...row,
        Password:
            row.Password ||
            row.password ||
            row.PASSWORD ||
            row.UserPassword ||
            row.userPassword ||
            row.USERPASSWORD ||
            null
    };
};

const getWebLoginByAgentAndUser = async ({ AgentId, UserName, DatabaseName }) => {
    const client = getDbClient(DatabaseName);
    const rows = await client.query`
        SELECT TOP 1
            AutoIndex,
            AgentId,
            UserName,
            UserPassword,
            ModifiedDate
        FROM E_WebLogin
        WHERE AgentId = ${AgentId}
          AND UserName = ${UserName}
        ORDER BY AutoIndex
    `;

    return normalizeWebLoginRow(rows[0]);
};

const updateWebLoginPassword = async ({ AutoIndex, hashedPassword, DatabaseName }) => {
    const client = getDbClient(DatabaseName);
    await client.execute`
        UPDATE E_WebLogin
        SET UserPassword = ${hashedPassword},
            ModifiedDate = NOW()
        WHERE AutoIndex = ${AutoIndex}
    `;

    return true;
};

const getMailConfig = async (DatabaseName) => {
    const client = getDbClient(DatabaseName);
    const rows = await client.query`
        SELECT TOP 1
            id,
            tomail,
            ccmail
        FROM E_config
        ORDER BY id
    `;

    return rows[0] || null;
};

const updateMailConfig = async ({ id, tomail, ccmail, DatabaseName }) => {
    const client = getDbClient(DatabaseName);
    await client.execute`
        UPDATE E_config
        SET tomail = ${tomail},
            ccmail = ${ccmail}
        WHERE id = ${id}
    `;

    return getMailConfig(DatabaseName);
};

module.exports = {
    getWebLoginByAgentAndUser,
    updateWebLoginPassword,
    getMailConfig,
    updateMailConfig
};
