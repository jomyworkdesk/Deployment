const db = require("../db");
const dbSecondary = require("../dbSecondary");

const HISTORY_BATCH_SIZE = Number(process.env.HISTORY_HEADER_QUEUE_BATCH_SIZE) || 500;

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") return null;
    return String(value);
};

const normalizeNumber = (value) => {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
};

const normalizeDateText = (value) => {
    if (!value) return null;
    if (value instanceof Date) return value.toISOString().slice(0, 10);

    const text = String(value).trim();
    const isoMatch = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (isoMatch) {
        const [, year, month, day] = isoMatch;
        return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    }

    const slashMatch = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (slashMatch) {
        const [, month, day, year] = slashMatch;
        return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    }

    return text;
};

const escapeSql = (value) => String(value).replace(/'/g, "''");

const buildDocumentTypeFilter = (documentType) => {
    const numericDocumentType = normalizeNumber(documentType);
    return numericDocumentType === null
        ? `DocumentType = '${escapeSql(documentType)}'`
        : `DocumentType = ${numericDocumentType}`;
};

const buildDocumentNumberFilter = (lastDocumentNumber) => {
    const documentNumber = normalizeText(lastDocumentNumber);
    if (!documentNumber) {
        return "";
    }

    return `AND DocumentNumber > '${escapeSql(documentNumber)}'`;
};

const getLastDocuments = async () => {
    return dbSecondary.query`
        SELECT DocumentType, DocumentNumber, DocumentDate, Status
        FROM E_lastDocument
        WHERE Status = 2
    `;
};

const getNewHistoryDocuments = async (lastDocument) => {
    const documentType = lastDocument?.DocumentType;
    if (documentType === null || documentType === undefined || documentType === "") {
        return [];
    }

    return db.queryUnsafe(`
        SELECT TOP ${HISTORY_BATCH_SIZE}
            DocumentType,
            DocumentNumber,
            DocumentDate
        FROM HistoryHeader
        WHERE ${buildDocumentTypeFilter(documentType)}
        ${buildDocumentNumberFilter(lastDocument.DocumentNumber)}
        ORDER BY DocumentNumber ASC
    `);
};

const insertQueueDocument = async (client, document) => {
    const docType = normalizeNumber(document.DocumentType);
    const documentNumber = normalizeText(document.DocumentNumber);
    const invDate = normalizeDateText(document.DocumentDate);

    if (docType === null || !documentNumber) return 0;

    try {
        const existingRows = await client.query`
            SELECT TOP 1 QueueID
            FROM E_InvoiceQueue
            WHERE AutoIndex = ${documentNumber}
        `;

        if (existingRows.length > 0) return 0;

        const nextQueueRows = await client.query`
            SELECT MAX(QueueID) AS MaxQueueID
            FROM E_InvoiceQueue
        `;
        const nextQueueId = normalizeNumber(nextQueueRows[0]?.MaxQueueID) + 1 || 1;

        return await client.execute`
            INSERT INTO E_InvoiceQueue (
                QueueID,
                AutoIndex,
                DocType,
                InvNumber,
                instanceIdentifier,
                InvDate,
                autosend,
                IsInvoiced,
                IsSent,
                IsReceived,
                IsError,
                InvoicedAt,
                SentAt,
                ReceivedAt,
                ErrorAt,
                RetryCount,
                ErrorMessage,
                CreatedAt,
                IsProcessing,
                Status
            )
            VALUES (
                ${nextQueueId},
                ${documentNumber},
                ${docType},
                ${documentNumber},
                NULL,
                ${invDate},
                1,
                0,
                0,
                0,
                0,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                NULL,
                now(),
                0,
                1
            )
        `;
    } catch (error) {
        error.message = `insert E_InvoiceQueue failed for DocType=${docType}, DocumentNumber=${documentNumber}, DocumentDate=${invDate}: ${error.message}`;
        throw error;
    }
};

const updateLastDocument = async (client, document) => {
    const docType = normalizeNumber(document.DocumentType);
    if (docType === null) return 0;

    try {
        return await client.execute`
            UPDATE E_lastDocument
            SET DocumentNumber = ${normalizeText(document.DocumentNumber)},
                DocumentDate = ${normalizeDateText(document.DocumentDate)},
                UpdatedAt = now()
            WHERE DocumentType = ${docType}
              AND Status = 2
        `;
    } catch (error) {
        error.message = `update E_lastDocument failed for DocType=${docType}, DocumentNumber=${normalizeText(document.DocumentNumber)}, DocumentDate=${normalizeDateText(document.DocumentDate)}: ${error.message}`;
        throw error;
    }
};

const queueHistoryDocuments = async (documents = []) => {
    if (!documents.length) {
        return {
            inserted: 0,
            updatedLastDocuments: 0
        };
    }

    let inserted = 0;
    let updatedLastDocuments = 0;
    const latestByType = new Map();

    for (const document of documents) {
        inserted += await insertQueueDocument(dbSecondary, document);
        latestByType.set(String(document.DocumentType), document);
    }

    for (const document of latestByType.values()) {
        updatedLastDocuments += await updateLastDocument(dbSecondary, document);
    }

    return {
        inserted,
        updatedLastDocuments
    };
};

module.exports = {
    getLastDocuments,
    getNewHistoryDocuments,
    queueHistoryDocuments
};
