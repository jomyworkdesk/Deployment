
const db = require("../dbSecondary");

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    return String(value);
};

const getDetailValue = (detail, keys) => {
    if (!detail) return null;

    for (const key of keys) {
        const value = detail[key];

        if (value !== null && value !== undefined && value !== "") {
            return value;
        }
    }

    return null;
};

const detailText = (detail, keys) => normalizeText(getDetailValue(detail, keys));

const detailTimestamp = (detail, keys) =>
    normalizeTimestamp(getDetailValue(detail, keys));

const detailBit = (detail, keys) => toBit(getDetailValue(detail, keys));

const toBit = (value) => {
    if (value === true || value === 1) {
        return 1;
    }

    if (typeof value === "string" && value.toLowerCase() === "true") {
        return 1;
    }

    return 0;
};

const getSafeLimit = (limit, fallback) => {
    const numericLimit = Number(limit);

    return Number.isFinite(numericLimit) && numericLimit > 0
        ? Math.floor(numericLimit)
        : fallback;
};

const normalizeTimestamp = (value) => {
    if (!value) {
        return null;
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        throw new Error(`Invalid timestamp: ${value}`);
    }

    return date
        .toISOString()
        .slice(0, 19)
        .replace("T", " ");
};

/**
 * Extract NextId safely from different possible result shapes
 * returned by the ODBC/database wrapper.
 */
const extractNextId = (result) => {
    if (!result) {
        return 1;
    }

    // Most query implementations return an array of rows.
    if (Array.isArray(result)) {
        const row = result[0];

        if (!row) {
            return 1;
        }

        const value =
            row.NextId ??
            row.nextId ??
            row.nextid ??
            row.NextID ??
            row.NEXTID;

        const numericValue = Number(value);

        return Number.isFinite(numericValue) && numericValue > 0 ? numericValue : 1;
    }

    // Some drivers return an object containing rows.
    if (Array.isArray(result.rows)) {
        return extractNextId(result.rows);
    }

    const value =
        result.NextId ??
        result.nextId ??
        result.nextid ??
        result.NextID ??
        result.NEXTID;

    const numericValue = Number(value);

    return Number.isFinite(numericValue) && numericValue > 0 ? numericValue : 1;
};


/**
 * Gets the next available Id.
 *
 * IMPORTANT:
 * E_Get_Out_Trans.Id is the PRIMARY KEY and there is no identity/sequence.
 * Therefore MAX(Id) + 1 must be treated as a candidate only.
 *
 * The INSERT function below still handles a duplicate-key race.
 */
const getNextTransactionId = async (client) => {
    const result = await client.query`
        SELECT COALESCE(MAX(Id), 0) + 1 AS NextId
        FROM E_Get_Out_Trans
    `;

    return extractNextId(result);
};


const getEligibleInvoiceQueueRows = async ({
    limit = Number(process.env.OUTBOUND_MLS_BATCH_SIZE) || 50,
    client = db
} = {}) =>
    client.query`
        SELECT TOP ${getSafeLimit(limit, 50)}
            QueueID,
            InvNumber,
            DocType,
            instanceIdentifier,
            OutMls,
            OutMlsAt
        FROM E_InvoiceQueue
        WHERE NULLIF(LTRIM(RTRIM(instanceIdentifier)), '') IS NOT NULL
          AND COALESCE(OutMls, 0) < 4
          AND IsReceived = 1
        ORDER BY QueueID
    `;


/**
 * Insert one transaction.
 *
 * Because Id is manually generated, a duplicate key can occur if
 * another process inserts a row between MAX(Id) and INSERT.
 *
 * In that case, get a new MAX(Id) and retry.
 */
const insertOutboundTransaction = async ({
    id,
    RootInstance,
    RootTransType,
    transactionId,
    detail,
    client
}) =>
    client.execute`
        INSERT INTO E_Get_Out_Trans (
            Id,
            RootInstance,
            RootTransType,
            TransactionId,
            TransmissionType,
            Status,
            SenderParticipantId,
            ReceiverPartiId,
            InstanceIdentifier,
            RefInstance,
            ErrorDetails,
            C5DispatchStatus,
            CreatedDate,
            LastModifiedDate,
            HasFile,
            InsertedOn
        )
        VALUES (
            ${id},
            ${normalizeText(RootInstance)},
            ${normalizeText(RootTransType)},
            ${transactionId},
            ${detailText(detail, ["transmissionType", "TransmissionType"])},
            ${detailText(detail, ["status", "Status"])},
            ${detailText(detail, ["senderParticipantId", "senderParticipantID", "SenderParticipantId", "SenderParticipantID"])},
            ${detailText(detail, ["ReceiverPartiId", "receiverPartiId", "receiverParticipantId", "receiverParticipantID"])},
            ${detailText(detail, ["instanceIdentifier", "InstanceIdentifier"])},
            ${detailText(detail, ["RefInstanceIdentifier", "refInstanceIdentifier", "RefInstance", "refInstance", "referenceInstance", "ReferenceInstance"])},
            ${detailText(detail, ["errorDetails", "ErrorDetails"])},
            ${detailText(detail, ["c5DispatchStatus", "C5DispatchStatus"])},
            ${detailTimestamp(detail, ["createdDate", "CreatedDate"])},
            ${detailTimestamp(detail, ["lastModifiedDate", "LastModifiedDate"])},
            ${detailBit(detail, ["hasFile", "HasFile"])},
            NOW()
        )
    `;


const upsertOutboundTransactionDetails = async ({
    RootInstance,
    RootTransType,
    details,
    client = db
}) => {
    let insertedTransactions = 0;
    let updatedTransactions = 0;
    let skippedTransactions = 0;

    /*
     * Get the current MAX once for the batch.
     *
     * We increment this locally for each insert rather than executing
     * SELECT MAX(Id) for every single transaction.
     */
    let nextId = await getNextTransactionId(client);

    for (const detail of details) {
        const transactionId = detailText(detail, ["transactionId", "TransactionId", "transactionID", "TransactionID"]);

        if (!transactionId) {
            skippedTransactions += 1;
            continue;
        }

        /*
         * First try to update the existing transaction.
         */
        const updated = await client.execute`
            UPDATE E_Get_Out_Trans
            SET RootTransType = ${normalizeText(RootTransType)},
                TransmissionType = ${detailText(detail, ["transmissionType", "TransmissionType"])},
                Status = ${detailText(detail, ["status", "Status"])},
                SenderParticipantId = ${detailText(detail, ["senderParticipantId", "senderParticipantID", "SenderParticipantId", "SenderParticipantID"])},
                ReceiverPartiId = ${detailText(detail, ["ReceiverPartiId", "receiverPartiId", "receiverParticipantId", "receiverParticipantID"])},
                InstanceIdentifier = ${detailText(detail, ["instanceIdentifier", "InstanceIdentifier"])},
                RefInstance = ${detailText(detail, ["RefInstanceIdentifier", "refInstanceIdentifier", "RefInstance", "refInstance", "referenceInstance", "ReferenceInstance"])},
                ErrorDetails = ${detailText(detail, ["errorDetails", "ErrorDetails"])},
                C5DispatchStatus = ${detailText(detail, ["c5DispatchStatus", "C5DispatchStatus"])},
                CreatedDate = ${detailTimestamp(detail, ["createdDate", "CreatedDate"])},
                LastModifiedDate = ${detailTimestamp(detail, ["lastModifiedDate", "LastModifiedDate"])},
                HasFile = ${detailBit(detail, ["hasFile", "HasFile"])}
            WHERE RootInstance = ${normalizeText(RootInstance)}
              AND TransactionId = ${transactionId}
        `;

        if (updated > 0) {
            updatedTransactions += 1;
            continue;
        }

        /*
         * We need to insert a new transaction.
         *
         * Id is not an identity column, so use nextId.
         *
         * Retry a few times in case another process inserted the same
         * Id between our MAX(Id) call and this INSERT.
         */
        let inserted = false;
        const maxInsertAttempts = 5;

        for (let attempt = 1; attempt <= maxInsertAttempts; attempt++) {
            try {
                await insertOutboundTransaction({
                    id: nextId,
                    RootInstance,
                    RootTransType,
                    transactionId,
                    detail,
                    client
                });

                insertedTransactions += 1;
                inserted = true;

                /*
                 * Make sure the next row in this batch gets another Id.
                 */
                nextId += 1;

                break;
            } catch (error) {
                const errorMessage = String(error?.message || error);

                /*
                 * Pervasive duplicate-key error:
                 *
                 * "The record has a key field containing a duplicate value"
                 * "Btrieve Error 5"
                 */
                const isDuplicateKey =
                    errorMessage.includes("duplicate value") ||
                    errorMessage.includes("Btrieve Error 5") ||
                    errorMessage.includes("duplicate key");

                if (!isDuplicateKey || attempt === maxInsertAttempts) {
                    throw error;
                }

                /*
                 * Another process has taken this Id.
                 *
                 * Re-read MAX(Id) using query(), then try again.
                 */
                nextId = await getNextTransactionId(client);
            }
        }

        if (!inserted) {
            skippedTransactions += 1;
        }
    }

    return {
        insertedTransactions,
        updatedTransactions,
        skippedTransactions
    };
};


const updateQueueOutboundMls = async ({
    queueId,
    outMls,
    client = db
}) =>
    client.execute`
        UPDATE E_InvoiceQueue
        SET OutMls = ${Number.isFinite(Number(outMls)) ? Number(outMls) : 0},
            OutMlsAt = NOW()
        WHERE QueueID = ${queueId}
    `;


module.exports = {
    getEligibleInvoiceQueueRows,
    upsertOutboundTransactionDetails,
    updateQueueOutboundMls
};
