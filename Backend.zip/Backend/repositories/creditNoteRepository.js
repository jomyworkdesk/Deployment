const db = require("../dbSecondary");
const { normalizeInvoiceRows } = require("./invoiceColumnAliases");
const CREDIT_NOTE_DOC_TYPE = 4;
const INVOICE_TABLE = "E_Invoicing";
const OUTBOUND_RESPONSE_FIELDS = `
                COALESCE(MAX(CASE
                    WHEN LOWER(LTRIM(RTRIM(t.TransmissionType))) = 'mls_inbound'
                    THEN t.Status
                END), 'Pending') AS C3ResponseStatus,
                COALESCE(MAX(CASE
                    WHEN LOWER(LTRIM(RTRIM(t.TransmissionType))) = 'c2_tdd_mls_inbound'
                    THEN t.Status
                END), 'Pending') AS C5ResponseStatus`;
const INVOICE_DETAIL_FIELDS = `
            e.*,
            e.invoice_no AS InvoiceNumber,
            e.invoice_issue_date AS InvoiceIssueDate,
            e.payment_due_date AS InvoicePaymentDueDate,
            e.inv_currency_code AS InvoiceCurrencyCode,
            e.inv_txn_typ_cod AS TransactionCode,
            e.buyer_name AS BuyerName,
            e.buyer_addr_line1 AS BuyerAddressline1,
            e.buyer_city AS BuyerCity,
            e.buyer_country_sub AS BuyerCountrySubdivision,
            e.buyer_country_code AS BuyerCountry,
            e.payment_type_code AS PaymentType,
            e.vat_cat_code AS VatCategory,
            e.invoice_line_id AS InvoiceLineIdentifier,
            e.invoiced_qty AS InvoicedQuantity,
            e.invoice_line_net_amt AS LineExtensionAmount,
            e.item_name AS ItemName,
            e.item_description AS ItemDescription,
            e.item_vat_cat_code AS ItemVatCategory,
            e.item_vat_rate AS ItemVatPrice,
            e.inv_qty_uom_code AS UOMCode,
            e.item_net_price AS PriceExcl,
            e.seller_name AS SellerName,
            e.seller_addr_line1 AS SellerAddressline1,
            e.seller_city AS SellerCity,
            e.seller_country_sub AS SellerCountrySubdivision,
            e.seller_country_code AS SellerCountryCode,
            e.inv_tot_without_tax AS InvTotExcl,
            e.inv_tot_tax_amt AS InvTotTax,
            e.inv_total_with_tax AS InvTotIncl,
            e.invoice_line_net_amt AS LineNet,
            e.vat_line_amt_aed AS LineTax,
            e.invoice_line_amt_aed AS LineTotal,
            e.vat_cat_taxable_amt AS TotalInvoiceAmt`;

const normalizeCreditNoteRows = (rows) =>
    normalizeInvoiceRows(rows).map((row) => {
        const precedingInvoiceRef = row.sales_order_ref;

        return {
            ...row,
            preceding_inv_ref: precedingInvoiceRef,
            preceding_invoice_ref: precedingInvoiceRef,
            PrecedingInvoiceRef: precedingInvoiceRef
        };
    });

const getAllCreditNotes = async () => {
    const rows = await db.queryUnsafe(`
        SELECT ${INVOICE_DETAIL_FIELDS}
        FROM ${INVOICE_TABLE} e
        WHERE e.DocType = ${CREDIT_NOTE_DOC_TYPE}
    `);
    return normalizeCreditNoteRows(rows);
};

const getCreditNoteDetailsByNumbers = async (invoiceNumbers) => {
    if (!Array.isArray(invoiceNumbers) || invoiceNumbers.length === 0) {
        return [];
    }

    const sanitizedInvoiceNumbers = invoiceNumbers
        .filter((value) => value !== null && value !== undefined && value !== "")
        .map((value) => String(value).replace(/'/g, "''"));

    if (sanitizedInvoiceNumbers.length === 0) {
        return [];
    }

    const inClause = sanitizedInvoiceNumbers
        .map((invoiceNumber) => `'${invoiceNumber}'`)
        .join(", ");

    const rows = await db.queryUnsafe(`
        SELECT
            ${INVOICE_DETAIL_FIELDS},
            q.Status,
            q.IsSent,
            q.IsReceived,
            q.IsInvoiced,
            q.IsError,
            q.ErrorMessage,
            q.InvoicedAt,
            q.SentAt,
            q.ReceivedAt,
            q.ErrorAt
        FROM ${INVOICE_TABLE} e
        LEFT JOIN E_InvoiceQueue q ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        WHERE e.invoice_no IN (${inClause})
        AND e.DocType = ${CREDIT_NOTE_DOC_TYPE}
        ORDER BY e.invoice_no ASC, e.ID ASC
    `);
    return normalizeCreditNoteRows(rows);
};

const normalizeSqlDate = (value) => {
    if (typeof value !== "string") return null;
    return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
};

const addDaysToSqlDate = (value, days) => {
    const safeDate = normalizeSqlDate(value);
    if (!safeDate) return null;

    const date = new Date(`${safeDate}T00:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
};

const toSqlDateTimeStart = (value) => {
    const safeDate = normalizeSqlDate(value);
    return safeDate ? `${safeDate} 00:00:00.000` : null;
};

const toSqlNextDateTimeStart = (value) => {
    const safeDate = addDaysToSqlDate(value, 1);
    return safeDate ? `${safeDate} 00:00:00.000` : null;
};

const sqlTimestampLiteral = (value) => `{ts '${value}'}`;

const statusEquals = (alias, statusCode) => `${alias}.Status = '${statusCode}'`;

const buildCreditNoteDateFilter = (fromDate, toDate, alias = "e") => {
    const safeFromDate = toSqlDateTimeStart(fromDate);
    const safeToDate = toSqlNextDateTimeStart(toDate);
    const conditions = [];

    if (safeFromDate) {
        conditions.push(`${alias}.invoice_issue_date >= ${sqlTimestampLiteral(safeFromDate)}`);
    }

    if (safeToDate) {
        conditions.push(`${alias}.invoice_issue_date < ${sqlTimestampLiteral(safeToDate)}`);
    }

    return conditions.length ? ` AND ${conditions.join(" AND ")}` : "";
};

const buildQueueDateFilter = (fromDate, toDate, alias = "q") => {
    const safeFromDate = toSqlDateTimeStart(fromDate);
    const safeToDate = toSqlNextDateTimeStart(toDate);
    const conditions = [];

    if (safeFromDate) {
        conditions.push(`${alias}.InvDate >= ${sqlTimestampLiteral(safeFromDate)}`);
    }

    if (safeToDate) {
        conditions.push(`${alias}.InvDate < ${sqlTimestampLiteral(safeToDate)}`);
    }

    return conditions.length ? ` WHERE ${conditions.join(" AND ")}` : "";
};

const getDashboardCounts = async (fromDate, toDate) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q");
    const result = await db.queryUnsafe(`
        SELECT
            COUNT(DISTINCT q.QueueID) AS total,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 1)} AND COALESCE(q.IsInvoiced, 0) = 1 THEN q.QueueID END) AS pending,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 3)} THEN q.QueueID END) AS success,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 3)} THEN q.QueueID END) AS received,
            COUNT(DISTINCT CASE WHEN COALESCE(q.IsInvoiced, 0) = 1 THEN q.QueueID END) AS invoiced,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 4)} THEN q.QueueID END) AS failed,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 6)} THEN q.QueueID END) AS error
        FROM E_InvoiceQueue q
        WHERE q.DocType = ${CREDIT_NOTE_DOC_TYPE}
        ${dateFilter.replace('WHERE', 'AND')}
    `);
    return result[0] || {};
};

const getPendingAndFailedEntries = async (fromDate, toDate) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");
    const rows = await db.queryUnsafe(`
        SELECT
            q.QueueID,
            MAX(q.AutoIndex) AS AutoIndex,
            MAX(q.DocType) AS DocType,
            MAX(q.InvNumber) AS InvNumber,
            MAX(q.InvDate) AS InvDate,
            MAX(q.CreatedAt) AS CreatedAt,
            MAX(q.Status) AS Status,
            MAX(q.ErrorMessage) AS ErrorMessage,
            MAX(q.RetryCount) AS RetryCount,
            MAX(COALESCE(e.buyer_name, '')) AS Customer,
            MAX(e.inv_total_with_tax) AS Amount
        FROM E_InvoiceQueue q
        LEFT JOIN ${INVOICE_TABLE} e
            ON q.InvNumber = e.invoice_no AND q.DocType = e.DocType
        WHERE q.DocType = ${CREDIT_NOTE_DOC_TYPE}
        AND q.Status IN ('1', '4')
        ${dateFilter}
        GROUP BY q.QueueID
        ORDER BY MAX(q.InvDate) DESC, q.QueueID DESC
    `);

    const pending = rows.filter((row) => String(row.Status) === "1").length;
    const failed = rows.filter((row) => String(row.Status) === "4").length;

    return {
        counts: {
            total: rows.length,
            pending,
            failed,
            success: 0,
            received: 0,
            error: failed
        },
        entries: rows
    };
};


const getCreditNotesByType = async (type, fromDate, toDate) => {
    const dateFilter = buildCreditNoteDateFilter(fromDate, toDate, "e");
    const selectSummary = `
                e.invoice_no AS InvoiceNumber,
                MAX(e.unique_identifier_no) AS AutoIndex,
                MAX(COALESCE(q.QueueID, 0)) AS QueueID,
                MAX(q.instanceIdentifier) AS InstanceIdentifier,
                MAX(e.invoice_issue_date) AS InvoiceIssueDate,
                MAX(q.CreatedAt) AS QueueCreatedAt,
                MAX(q.CreatedAt) AS CreatedAt,
                MAX(COALESCE(e.buyer_name, '')) AS Customer,
                MAX(e.inv_tot_without_tax) AS InvTotExcl,
                MAX(e.inv_tot_tax_amt) AS InvTotTax,
                MAX(e.inv_total_with_tax) AS InvTotIncl,
                MAX(e.vat_cat_taxable_amt) AS TotalInvoiceAmt,
                MAX(e.DocType) AS DocType,
                MAX(COALESCE(q.Status, '')) AS Status,
                ${OUTBOUND_RESPONSE_FIELDS}`;

    if (type === "sent") {
        return db.queryUnsafe(`
            SELECT
                ${selectSummary}
            FROM ${INVOICE_TABLE} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE COALESCE(q.IsSent, 0) = 1
            AND e.DocType = ${CREDIT_NOTE_DOC_TYPE} AND q.DocType = ${CREDIT_NOTE_DOC_TYPE}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(e.invoice_issue_date) DESC
        `);
    }
    if (type === "received") {
        return db.queryUnsafe(`
            SELECT
                ${selectSummary}
            FROM ${INVOICE_TABLE} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE COALESCE(q.IsReceived, 0) = 1
            AND e.DocType = ${CREDIT_NOTE_DOC_TYPE} AND q.DocType = ${CREDIT_NOTE_DOC_TYPE}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(e.invoice_issue_date) DESC
        `);
    }
    if (type === "invoiced") {
        return db.queryUnsafe(`
            SELECT
                ${selectSummary}
            FROM ${INVOICE_TABLE} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE COALESCE(q.IsInvoiced, 0) = 1
            AND e.DocType = ${CREDIT_NOTE_DOC_TYPE} AND q.DocType = ${CREDIT_NOTE_DOC_TYPE}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(e.invoice_issue_date) DESC
        `);
    }
    if (type === "error" || type === "failed") {
        return db.queryUnsafe(`
            SELECT
                ${selectSummary}
            FROM ${INVOICE_TABLE} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE ${statusEquals("q", 4)}
            AND e.DocType = ${CREDIT_NOTE_DOC_TYPE} AND q.DocType = ${CREDIT_NOTE_DOC_TYPE}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(e.invoice_issue_date) DESC
        `);
    }

    if (type === "success" || type === "received") {

        return db.queryUnsafe(`
            SELECT
                ${selectSummary}
            FROM ${INVOICE_TABLE} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE ${statusEquals("q", 3)}
            AND e.DocType = ${CREDIT_NOTE_DOC_TYPE} AND q.DocType = ${CREDIT_NOTE_DOC_TYPE}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(e.invoice_issue_date) DESC
        `);
    }

    if (type === "pending") {
        return db.queryUnsafe(`
            SELECT
                ${selectSummary}
            FROM ${INVOICE_TABLE} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE ${statusEquals("q", 1)}
            AND COALESCE(q.IsInvoiced, 0) = 1
            AND e.DocType = ${CREDIT_NOTE_DOC_TYPE} AND q.DocType = ${CREDIT_NOTE_DOC_TYPE}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(e.invoice_issue_date) DESC
        `);
    }


    return db.queryUnsafe(`
        SELECT
            ${selectSummary}
        FROM ${INVOICE_TABLE} e
        LEFT JOIN E_InvoiceQueue q
            ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        LEFT JOIN E_Get_Out_Trans t
            ON q.instanceIdentifier = t.RootInstance
        WHERE 1 = 1
        AND e.DocType = ${CREDIT_NOTE_DOC_TYPE}
        AND (q.QueueID IS NULL OR q.DocType = ${CREDIT_NOTE_DOC_TYPE})
        AND (q.QueueID IS NULL OR q.Status IS NULL OR q.Status <> '0')
        ${dateFilter}
        GROUP BY e.invoice_no
        ORDER BY MAX(e.invoice_issue_date) DESC
    `);
};

const getCreditNoteDetails = async (invNumber) => {
    const sanitizedInvNumber = String(invNumber).replace(/'/g, "''");
    const result = await db.queryUnsafe(`
        SELECT
            ${INVOICE_DETAIL_FIELDS},
            q.Status,
            q.IsSent,
            q.IsReceived,
            q.IsInvoiced,
            q.IsError,
            q.ErrorMessage,
            q.InvoicedAt,
            q.SentAt,
            q.ReceivedAt,
            q.ErrorAt
        FROM ${INVOICE_TABLE} e
        LEFT JOIN E_InvoiceQueue q ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        WHERE e.invoice_no = '${sanitizedInvNumber}'
        AND e.DocType = ${CREDIT_NOTE_DOC_TYPE} AND (q.QueueID IS NULL OR q.DocType = ${CREDIT_NOTE_DOC_TYPE})
        ORDER BY e.ID ASC
    `);
    return normalizeCreditNoteRows(result);
};


module.exports = {
    getAllCreditNotes,
    getCreditNoteDetailsByNumbers,
    getDashboardCounts,
    getPendingAndFailedEntries,
    getCreditNotesByType,
    getCreditNoteDetails
};
