const db = require("../dbSecondary");
const { getSqlLocalDateTime } = require("../utils/schedulerTime");

const CRON_SETTINGS_TABLE = "E_CronSettings";

const CRON_SETTING_COLUMNS = `
            Id,
            JobName,
            CronExpression,
            RunType,
            RunEverySeconds,
            RunAtTime,
            LastRunTime,
            NextRunTime,
            IsEnabled,
            Manual,
            IsQueue,
            IsProcessing,
            Status,
            CreatedOn,
            UpdatedOn
`;

const getNextCronSettingId = async (client = db) => {
    const rows = await client.queryUnsafe(`
        SELECT MAX(Id) AS MaxId
        FROM ${CRON_SETTINGS_TABLE}
    `);
    const maxId = Number(rows[0]?.MaxId);
    return Number.isFinite(maxId) ? maxId + 1 : 1;
};

const getCronSettings = async () =>
    db.queryUnsafe(`
        SELECT TOP 1000
            ${CRON_SETTING_COLUMNS}
        FROM ${CRON_SETTINGS_TABLE}
        ORDER BY Id
    `);

const getCronSettingById = async (id) => {
    const rows = await db.queryStatement(`
        SELECT TOP 1
            ${CRON_SETTING_COLUMNS}
        FROM ${CRON_SETTINGS_TABLE}
        WHERE Id = @p0
    `, [id]);

    return rows[0] || null;
};

const createCronSetting = async ({
    jobName,
    cronExpression,
    runType,
    runEverySeconds,
    runAtTime,
    lastRunTime,
    nextRunTime,
    isEnabled,
    manual,
    status
}) => {
    const created = await db.withTransaction(async (tx) => {
        const nextId = await getNextCronSettingId(tx);

        await tx.executeStatement(`
            INSERT INTO ${CRON_SETTINGS_TABLE} (
                Id,
                JobName,
                CronExpression,
                RunType,
                RunEverySeconds,
                RunAtTime,
                LastRunTime,
                NextRunTime,
                IsEnabled,
                Manual,
                IsQueue,
                IsProcessing,
                Status,
                CreatedOn,
                UpdatedOn
            )
            VALUES (
                @p0,
                @p1,
                @p2,
                @p3,
                @p4,
                @p5,
                @p6,
                @p7,
                @p8,
                @p9,
                0,
                0,
                @p10,
                NOW(),
                NOW()
            )
        `, [
            nextId,
            jobName,
            cronExpression,
            runType,
            runEverySeconds,
            runAtTime,
            lastRunTime,
            nextRunTime,
            isEnabled,
            manual,
            status
        ]);

        return nextId;
    });

    return created ? getCronSettingById(created) : null;
};

const updateCronSetting = async (id, {
    jobName,
    cronExpression,
    runType,
    runEverySeconds,
    runAtTime,
    lastRunTime,
    nextRunTime,
    isEnabled,
    manual,
    status
}) => {
    await db.executeStatement(`
        UPDATE ${CRON_SETTINGS_TABLE}
        SET JobName = @p0,
            CronExpression = @p1,
            RunType = @p2,
            RunEverySeconds = @p3,
            RunAtTime = @p4,
            NextRunTime = @p5,
            IsEnabled = @p6,
            Manual = @p7,
            Status = @p8,
            IsQueue = 0,
            IsProcessing = 0,
            UpdatedOn = NOW()
        WHERE Id = @p9
    `, [
        jobName,
        cronExpression,
        runType,
        runEverySeconds,
        runAtTime,
        nextRunTime,
        isEnabled,
        manual,
        status,
        id
    ]);

    return getCronSettingById(id);
};

const markCronSettingManualRun = async (id) => {
    const currentLocalTime = getSqlLocalDateTime(new Date());

    await db.executeStatement(`
        UPDATE ${CRON_SETTINGS_TABLE}
        SET Manual = 1,
            NextRunTime = @p0,
            UpdatedOn = NOW()
        WHERE Id = @p1
    `, [currentLocalTime, id]);

    return getCronSettingById(id);
};

module.exports = {
    getCronSettings,
    getCronSettingById,
    createCronSetting,
    updateCronSetting,
    markCronSettingManualRun
};
