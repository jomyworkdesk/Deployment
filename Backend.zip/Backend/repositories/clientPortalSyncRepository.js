const db = require("../dbSecondary");

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") return null;
    return String(value);
};

const getSafeLimit = (limit) => {
    const numericLimit = Number(limit);
    return Number.isFinite(numericLimit) && numericLimit > 0
        ? Math.floor(numericLimit)
        : 10;
};

const getClientPortalConfig = async (client = db) => {
    const rows = await client.query`
        SELECT TOP 1
            id,
            Ref,
            RefCode,
            PeppolId,
            Period,
            Volume
        FROM E_config
        ORDER BY id
    `;

    return rows[0] || null;
};

const getPendingOutboundTransactions = async ({
    limit = 10,
    client = db
} = {}) => {
    const safeLimit = getSafeLimit(limit);

    const configResult = await client.query`
        SELECT TOP 1
            RefCode,
            PeppolId,
            Period,
            Volume
        FROM E_config
        ORDER BY id
    `;

    const config = configResult[0];

    const transactions = await client.query`
        SELECT TOP ${safeLimit}
            q.QueueID,
            q.instanceIdentifier AS InstanceIdentifier,
            q.InvDate AS DocDate,
            q.InvNumber AS Invoiceno,
            q.DocType AS TypeCode,
            'outbound' AS transtype
        FROM E_InvoiceQueue q
        WHERE ISNULL(q.IsReceived, 0) = 1
          AND ISNULL(q.IsPortal, 0) <> 1
        ORDER BY q.QueueID
    `;

    return transactions.map(q => ({
        ...q,
        clientCode: config?.RefCode ?? null,
        Peppolid: config?.PeppolId ?? null,
        Period: config?.Period ?? null,
        lastVolume: config?.Volume ?? null
    }));
};

const getPendingInboundTransactions = async ({
    limit = 10,
    client = db
} = {}) => {
    const safeLimit = getSafeLimit(limit);

    const [config] = await client.query`
        SELECT TOP 1
            RefCode,
            PeppolId,
            Period,
            Volume
        FROM E_config
        ORDER BY id
    `;

    const transactions = await client.query`
        SELECT TOP ${safeLimit}
            q.QueueId,
            q.InstanceIdentifier AS InstanceIdentifier,
            q.TransCreatedAt AS DocDate,
            q.InvoiceNo AS Invoiceno,
            q.InvoiceType AS TypeCode,
            'inbound' AS transtype
        FROM E_PurchaseQueue q
        WHERE ISNULL(q.IsInserted, 0) = 1
          AND ISNULL(q.IsPortal, 0) <> 1
        ORDER BY q.QueueId
    `;

    return transactions.map(transaction => ({
        ...transaction,
        clientCode: config?.RefCode,
        Peppolid: config?.PeppolId,
        Period: config?.Period,
        lastVolume: config?.Volume
    }));
};
const buildIdClause = (ids = []) =>
    ids
        .map((id) => Number(id))
        .filter(Number.isFinite)
        .map((id) => Math.floor(id))
        .join(",");

const markOutboundTransactionsPortalSent = async ({
    queueIds,
    client = db
}) => {
    const idClause = buildIdClause(queueIds);
    if (!idClause) return 0;

    return client.executeUnsafe(`
        UPDATE E_InvoiceQueue
        SET IsPortal = 1
        WHERE QueueID IN (${idClause})
    `);
};

const markInboundTransactionsPortalSent = async ({
    queueIds,
    client = db
}) => {
    const idClause = buildIdClause(queueIds);
    if (!idClause) return 0;

    return client.executeUnsafe(`
        UPDATE E_PurchaseQueue
        SET IsPortal = 1
        WHERE QueueId IN (${idClause})
    `);
};

const updateClientPortalSubscription = async ({
    configId,
    periodId,
    volume,
    ref,
    client = db
}) =>
    client.execute`
        UPDATE E_config
        SET Period = ${periodId},
            Volume = ${volume},
            Ref = ${normalizeText(ref)}
        WHERE id = ${configId}
    `;

module.exports = {
    getClientPortalConfig,
    getPendingOutboundTransactions,
    getPendingInboundTransactions,
    markOutboundTransactionsPortalSent,
    markInboundTransactionsPortalSent,
    updateClientPortalSubscription
};
