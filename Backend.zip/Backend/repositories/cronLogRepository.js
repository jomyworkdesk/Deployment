const db = require("../dbSecondary");

const CRON_LOG_TABLE = "e_invoice_cron_log";

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    return String(value);
};

const normalizeLogDetails = (details) => {
    if (details === null || details === undefined || details === "") {
        return null;
    }

    if (typeof details === "string") {
        return details;
    }

    try {
        return JSON.stringify(details);
    } catch (error) {
        return String(details);
    }
};

const getNextCronLogId = async () => {
    const nextIdRows = await db.queryUnsafe(`
        SELECT MAX(Id) AS MaxId
        FROM ${CRON_LOG_TABLE}
    `);
    const maxId = Number(nextIdRows[0]?.MaxId);
    return Number.isFinite(maxId) ? maxId + 1 : 1;
};

const ensureCronLogTable = async () => true;

const saveCronLog = async ({ type, logDetails }) => {
    await ensureCronLogTable();
    const nextId = await getNextCronLogId();

    await db.executeStatement(`
        INSERT INTO ${CRON_LOG_TABLE} (
            Id,
            type,
            timestamp,
            logDetails
        )
        VALUES (
            @p0,
            @p1,
            NOW(),
            @p2
        )
    `, [
        nextId,
        normalizeText(type),
        normalizeLogDetails(logDetails)
    ]);
};

module.exports = {
    ensureCronLogTable,
    saveCronLog
};
