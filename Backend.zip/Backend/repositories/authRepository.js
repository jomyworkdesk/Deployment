const db = require("../db");
const dbSecondary = require("../dbSecondary");

const limitString = (value, maxLength) => {
    if (value === null || value === undefined || value === "") return null;
    const text = String(value);
    return text.length > maxLength ? text.slice(0, maxLength) : text;
};

const integerOrNull = (value) => {
    if (value === null || value === undefined || value === "") return null;
    const number = Number(value);
    return Number.isInteger(number) ? number : null;
};

const decimalOrNull = (value) => {
    if (value === null || value === undefined || value === "") return null;
    const number = Number(value);
    return Number.isFinite(number) ? Number(number.toFixed(6)) : null;
};

const getClientRefCode = async () => {
    const result = await dbSecondary.query`
        SELECT TOP 1 RefCode
        FROM E_config
        ORDER BY id
    `;

    return result[0]?.RefCode || null;
};

/**
 * Find an agent by their agent name (legacy authentication)
 */
const findAgentByName = async (cAgentName) => {
    const result = await db.query`
        SELECT idAgents, cAgentName, cPassword
        FROM _rtblAgents
        WHERE cAgentName = ${cAgentName}
    `;
    return result[0] || null;
};

/**
 * Agent records are not available in this deployment.
 */
const getActiveAgentsWithoutWebLogin = async () => {
    return [];
};

/**
 * Check if a web login already exists
 */
const findWebLoginByAgentIdOrUserName = async ({ AgentId, UserName }) => {
    const result = await dbSecondary.query`
        SELECT TOP 1 AutoIndex
        FROM E_WebLogin
        WHERE AgentId = ${AgentId} OR UserName = ${UserName}
    `;
    return result[0] || null;
};

/**
 * Get next unique AgentId for E_WebLogin
 */
const getNextWebLoginAgentId = async () => {
    const result = await dbSecondary.query`
        SELECT ISNULL(MAX(AgentId), 0) + 1 AS NextAgentId
        FROM E_WebLogin
    `;
    return result[0]?.NextAgentId || 1;
};

/**
 * Create a new web login (signup)
 */
const createWebLogin = async ({ AgentId, UserName, hashedPassword }) => {
    const nextAutoIndexRows = await dbSecondary.query`
        SELECT ISNULL(MAX(AutoIndex), 0) + 1 AS NextAutoIndex
        FROM E_WebLogin
    `;
    const nextAutoIndex = nextAutoIndexRows[0]?.NextAutoIndex || 1;

    await dbSecondary.execute`
        INSERT INTO E_WebLogin
        (
            AutoIndex,
            AgentId,
            UserName,
            UserPassword,
            IsActive,
            CreatedDate
        )
        VALUES
        (
            ${nextAutoIndex},
            ${AgentId},
            ${UserName},
            ${hashedPassword},
            1,
            NOW()
        )
    `;
    return { AutoIndex: nextAutoIndex };
};

/**
 * Find an active web login by username
 */
const findActiveWebLoginByUserName = async (UserName) => {
    const result = await dbSecondary.query`
        SELECT
            AgentId,
            UserName,
            UserPassword,
            RoleId,
            IsActive
        FROM E_WebLogin
        WHERE UserName = ${UserName}
          AND IsActive = 1
    `;
    return result[0] || null;
};

/**
 * Get active pages available to a user's role.
 */
const getPagesByRoleId = async ({ RoleId }) => {
    const result = await dbSecondary.query`
        SELECT
            p.PageId,
            p.PageName,
            p.MenuText,
            p.Route,
            p.SortOrder,
            p.IsActive
        FROM E_RolePageAccess rpa
        INNER JOIN E_Page p
            ON p.PageId = rpa.PageId
        WHERE rpa.RoleId = ${RoleId}
          AND rpa.HasAccess = 1
          AND p.IsActive = 1
        ORDER BY p.SortOrder, p.PageId
    `;

    return result;
};

/**
 * Find an agent by exact identity details for password reset
 */
const findAgentByResetDetails = async ({ UserName, FirstName, DisplayName }) => {
    const result = await db.query`
        SELECT TOP 1
            idAgents,
            cAgentName,
            cFirstName,
            cDisplayName
        FROM _rtblAgents
        WHERE LTRIM(RTRIM(cAgentName)) = LTRIM(RTRIM(${UserName}))
          AND LTRIM(RTRIM(cFirstName)) = LTRIM(RTRIM(${FirstName}))
          AND LTRIM(RTRIM(cDisplayName)) = LTRIM(RTRIM(${DisplayName}))
    `;
    return result[0] || null;
};

/**
 * Insert or update a web login password during reset
 */
const upsertWebLoginPassword = async ({ AgentId, UserName, hashedPassword }) => {
    const existing = await dbSecondary.query`
        SELECT TOP 1 AutoIndex
        FROM E_WebLogin
        WHERE AgentId = ${AgentId}
           OR UserName = ${UserName}
        ORDER BY AutoIndex
    `;

    if (existing[0]?.AutoIndex) {
        await dbSecondary.execute`
            UPDATE E_WebLogin
            SET AgentId = ${AgentId},
                UserName = ${UserName},
                UserPassword = ${hashedPassword},
                IsActive = 1,
                ModifiedDate = NOW()
            WHERE AutoIndex = ${existing[0].AutoIndex}
        `;

        return {
            AutoIndex: existing[0].AutoIndex,
            AgentId,
            UserName,
            IsActive: true,
            action: "updated"
        };
    }

    const nextAutoIndexRows = await dbSecondary.query`
        SELECT ISNULL(MAX(AutoIndex), 0) + 1 AS NextAutoIndex
        FROM E_WebLogin
    `;
    const nextAutoIndex = nextAutoIndexRows[0]?.NextAutoIndex || 1;

    await dbSecondary.execute`
        INSERT INTO E_WebLogin
        (
            AutoIndex,
            AgentId,
            UserName,
            UserPassword,
            IsActive,
            CreatedDate,
            ModifiedDate
        )
        VALUES
        (
            ${nextAutoIndex},
            ${AgentId},
            ${UserName},
            ${hashedPassword},
            1,
            NOW(),
            NOW()
        );
    `;

    return {
        AutoIndex: nextAutoIndex,
        AgentId,
        UserName,
        IsActive: true,
        action: "created"
    };
};

/**
 * Insert a login log entry
 */
const insertLoginLog = async (data) => {
    const log = {
        AgentId: integerOrNull(data.AgentId),
        UserName: limitString(data.UserName, 100),
        LoginStatus: limitString(data.LoginStatus, 20),
        IPAddress: limitString(data.IPAddress, 50),
        Browser: limitString(data.Browser, 255),
        Country: limitString(data.Country, 100),
        City: limitString(data.City, 100),
        Latitude: decimalOrNull(data.Latitude),
        Longitude: decimalOrNull(data.Longitude),
        FailureReason: limitString(data.FailureReason, 255),
        SessionId: limitString(data.SessionId, 100)
    };

    const nextLogIdRows = await dbSecondary.query`
        SELECT ISNULL(MAX(LogID), 0) + 1 AS NextLogID
        FROM E_WebLogin_Log
    `;
    const nextLogId = nextLogIdRows[0]?.NextLogID || 1;

    await dbSecondary.execute`
        INSERT INTO E_WebLogin_Log
        (
            LogID,
            AgentId,
            UserName,
            LoginStatus,
            LoginDateTime,
            IPAddress,
            Browser,
            Country,
            City,
            Latitude,
            Longitude,
            FailureReason,
            SessionId
        )
        VALUES
        (
            ${nextLogId},
            ${log.AgentId},
            ${log.UserName},
            ${log.LoginStatus},
            NOW(),
            ${log.IPAddress},
            ${log.Browser},
            ${log.Country},
            ${log.City},
            ${log.Latitude},
            ${log.Longitude},
            ${log.FailureReason},
            ${log.SessionId}
        );
    `;

    return { LogID: nextLogId };
};

/**
 * Update logout time for a login log
 */
const updateLogoutTime = async ({ LogID, SessionId, AgentId }) => {
    if (LogID) {
        const affected = await dbSecondary.execute`
            UPDATE E_WebLogin_Log
            SET LogoutDateTime = NOW()
            WHERE LogID = ${LogID}
        `;
        return affected || 0;
    }
    if (AgentId) {
        const affected = await dbSecondary.execute`
            UPDATE E_WebLogin_Log
            SET LogoutDateTime = NOW()
            WHERE SessionId = ${SessionId}
              AND AgentId = ${AgentId}
        `;
        return affected || 0;
    }
    const affected = await dbSecondary.execute`
        UPDATE E_WebLogin_Log
        SET LogoutDateTime = NOW()
        WHERE SessionId= ${SessionId}
    `;
    return affected || 0;
};

module.exports = {
    getClientRefCode,
    findAgentByName,
    getActiveAgentsWithoutWebLogin,
    findWebLoginByAgentIdOrUserName,
    getNextWebLoginAgentId,
    createWebLogin,
    findActiveWebLoginByUserName,
    getPagesByRoleId,
    findAgentByResetDetails,
    upsertWebLoginPassword,
    insertLoginLog,
    updateLogoutTime
};
