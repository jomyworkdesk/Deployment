const RENAMED_INVOICE_COLUMNS = {
    business_process_type: "business_proc_type",
    invoice_txn_type_code: "inv_txn_typ_cod",
    invoice_currency_code: "inv_currency_code",
    preceding_invoice_ref: "preceding_inv_ref",
    preceding_invoice_date: "preceding_inv_date",
    credit_note_reason_code: "credit_reason_code",
    invoiced_obj_scheme_id: "inv_obj_scheme_id",
    attached_doc_mime_code: "attach_doc_mime_code",
    attached_doc_filename: "attach_doc_filename",
    external_doc_location: "external_doc_loc",
    invoice_obj_identifier: "inv_obj_identifier",
    invoice_doc_type_code: "inv_doc_type_code",
    invocie_doc_description: "inv_doc_description",
    seller_elec_scheme_id: "seller_elec_sche_id",
    seller_country_subdivision: "seller_country_sub",
    seller_tax_scheme_code: "seller_tax_sch_cod",
    seller_legal_scheme_id: "seller_legal_sch_id",
    seller_authority_name: "seller_author_name",
    seller_passport_country_code: "seller_passport_code",
    seller_legal_reg_type: "seller_legal_reg_typ",
    buyer_country_subdivision: "buyer_country_sub",
    buyer_tax_scheme_code: "buyer_tax_sch_cod",
    buyer_legal_scheme_id: "buyer_legal_sch_id",
    buyer_passport_country_code: "buyer_passport_code",
    payee_legal_scheme_id: "payee_legal_sch_id",
    tax_rep_country_subdivision: "tax_rep_subdivision",
    seller_tax_rep_vat_id: "seller_tax_rep_vat",
    tax_rep_tax_scheme_code: "tax_rep_tax_sch_code",
    deliver_to_location_id: "deliver_to_loc_id",
    deliver_to_addr_line1: "deliver_addr_line1",
    deliver_to_addr_line2: "deliver_addr_line2",
    deliver_to_country_subdivision: "deliver_subdivision",
    deliver_to_addr_line3: "deliver_addr_line3",
    deliver_to_country_code: "deliver_country_code",
    deliver_to_party_name: "deliver_party_name",
    payment_instruction_id: "payment_instruc_id",
    payment_means_type_code: "payment_type_code",
    payment_card_holder_name: "payment_card_name",
    payment_account_scheme_id: "payment_acc_scheme",
    payment_service_provider_id: "payment_provider_id",
    syntax_binding_qualifier: "syntax_bind_qualifi",
    doc_allow_reason_code: "doc_allo_rea_code",
    doc_allow_base_amount: "doc_allo_base_amt",
    doc_allow_vat_cat_code: "doc_allow_vat_cat",
    doc_allow_vat_exempt_code: "doc_allow_exem_code",
    doc_allow_vat_exempt_text: "doc_allow_exem_text",
    doc_allow_tax_scheme_code: "doc_allow_sche_code",
    doc_charge_reason_code: "doc_char_reason_code",
    doc_charge_base_amount: "doc_charge_base_amt",
    doc_charge_vat_cat_code: "doc_charge_vat_cat",
    doc_charge_vat_exempt_code: "doc_char_exempt_code",
    doc_charge_vat_exempt_text: "doc_char_exempt_text",
    doc_charge_tax_scheme_code: "doc_char_scheme_code",
    invoice_total_tax_amt: "inv_tot_tax_amt",
    vat_cat_tax_scheme_code: "vat_cat_sche_code",
    invoice_total_vat_tax_currency: "inv_tot_vat_currency",
    invoice_line_net_total: "inv_line_net_total",
    invoice_total_without_tax: "inv_tot_without_tax",
    invoice_total_with_tax: "inv_total_with_tax",
    invoiced_qty_uom_code: "inv_qty_uom_code",
    invoice_line_buyer_acc_ref: "inv_line_buyer_ref",
    invoice_line_period_start: "inv_period_start",
    invoice_line_period_end: "inv_period_end",
    invoice_line_scheme_id: "inv_line_sche_id",
    line_allow_reason_code: "line_allow_reas_code",
    line_allow_base_amount: "line_allow_base_amt",
    line_charge_reason_code: "line_char_reas_code",
    line_charge_base_amount: "line_charge_base_amt",
    service_acc_scheme_id: "serv_acc_sche_id",
    item_classification_id: "item_classifi_id",
    item_classification_scheme_id: "item_classi_sche_id",
    vat_exempt_reason_code: "vat_exempt_rea_code",
    vat_exempt_reason_text: "vat_exempt_rea_text",
    item_price_base_uom_code: "item_price_base_uom"
};

const isBlank = (value) =>
    value === null || value === undefined || (typeof value === "string" && value.trim() === "");

const withLegacyInvoiceColumnAliases = (row = {}) => {
    const normalized = { ...row };

    Object.entries(RENAMED_INVOICE_COLUMNS).forEach(([legacyColumn, currentColumn]) => {
        if (isBlank(normalized[legacyColumn]) && !isBlank(normalized[currentColumn])) {
            normalized[legacyColumn] = normalized[currentColumn];
        }

        if (isBlank(normalized[currentColumn]) && !isBlank(normalized[legacyColumn])) {
            normalized[currentColumn] = normalized[legacyColumn];
        }
    });

    return normalized;
};

const normalizeInvoiceRows = (rows) =>
    Array.isArray(rows) ? rows.map(withLegacyInvoiceColumnAliases) : [];

module.exports = {
    RENAMED_INVOICE_COLUMNS,
    normalizeInvoiceRows,
    withLegacyInvoiceColumnAliases
};
