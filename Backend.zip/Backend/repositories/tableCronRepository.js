const db = require("../dbSecondary");
const {
    resolveIdentifier
} = require("../config/databaseSchema");

let tableCronReady = false;
const tableCronTableName = resolveIdentifier("E_tablecron")
    .split(".")
    .map((part) => part.trim().replace(/^\[|\]$/g, "").replace(/^"|"$/g, ""))
    .filter(Boolean)
    .pop() || "E_tablecron";

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    return String(value);
};

const normalizeBit = (value) => {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    if (value === true || value === 1 || value === "1") {
        return true;
    }

    return String(value).toLowerCase() === "true";
};

const getNextTableCronId = async () => {
    const rows = await db.queryUnsafe(`
        SELECT MAX(Id) AS MaxId
        FROM ${tableCronTableName}
    `);
    const maxId = Number(rows[0]?.MaxId);
    return Number.isFinite(maxId) ? maxId + 1 : 1;
};

const ensureTableCronTable = async () => {
    if (tableCronReady) return;
    tableCronReady = true;
};

const saveTableCronLog = async ({
    setting = {},
    status,
    reason,
    errorMessage,
    startedAt,
    completedAt,
    durationMs,
    nextRunTime
}) => {
    await ensureTableCronTable();
    const nextId = await getNextTableCronId();

    await db.executeStatement(`
        INSERT INTO ${tableCronTableName} (
            Id,
            CronSettingId,
            JobName,
            RunType,
            CronExpression,
            Manual,
            Status,
            Reason,
            ErrorMessage,
            StartedAt,
            CompletedAt,
            DurationMs,
            NextRunTime,
            CreatedOn
        )
        VALUES (
            @p0,
            @p1,
            @p2,
            @p3,
            @p4,
            @p5,
            @p6,
            @p7,
            @p8,
            @p9,
            @p10,
            @p11,
            @p12,
            NOW()
        )
    `, [
        nextId,
        setting.Id ?? null,
        normalizeText(setting.JobName),
        normalizeText(setting.RunType),
        normalizeText(setting.CronExpression),
        normalizeBit(setting.Manual),
        normalizeText(status),
        normalizeText(reason),
        normalizeText(errorMessage),
        startedAt || null,
        completedAt || null,
        durationMs ?? null,
        nextRunTime || null
    ]);
};

module.exports = {
    ensureTableCronTable,
    saveTableCronLog
};
