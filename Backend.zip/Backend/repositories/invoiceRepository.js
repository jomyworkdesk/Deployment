const db = require("../dbSecondary");
const { normalizeInvoiceRows } = require("./invoiceColumnAliases");
const INVOICE_DOC_TYPE = [3];
const PURCHASE_DOC_TYPE = 5;
const INVOICE_TABLE = "E_Invoicing";
const PURCHASE_TABLE = "E_Purchase";
const OUTBOUND_RESPONSE_FIELDS = `
                COALESCE(MAX(CASE
                    WHEN LOWER(LTRIM(RTRIM(t.TransmissionType))) = 'mls_inbound'
                    THEN t.Status
                END), 'Pending') AS C3ResponseStatus,
                COALESCE(MAX(CASE
                    WHEN LOWER(LTRIM(RTRIM(t.TransmissionType))) = 'c2_tdd_mls_inbound'
                    THEN t.Status
                END), 'Pending') AS C5ResponseStatus`;
const INVOICE_DETAIL_FIELDS = `
            e.*,
            e.invoice_no AS InvoiceNumber,
            e.invoice_issue_date AS InvoiceIssueDate,
            e.payment_due_date AS InvoicePaymentDueDate,
            e.inv_currency_code AS InvoiceCurrencyCode,
            e.inv_txn_typ_cod AS TransactionCode,
            e.buyer_name AS BuyerName,
            e.buyer_addr_line1 AS BuyerAddressline1,
            e.buyer_city AS BuyerCity,
            e.buyer_country_sub AS BuyerCountrySubdivision,
            e.buyer_country_code AS BuyerCountry,
            e.payment_type_code AS PaymentType,
            e.vat_cat_code AS VatCategory,
            e.invoice_line_id AS InvoiceLineIdentifier,
            e.invoiced_qty AS InvoicedQuantity,
            e.invoice_line_net_amt AS LineExtensionAmount,
            e.item_name AS ItemName,
            e.item_description AS ItemDescription,
            e.item_vat_cat_code AS ItemVatCategory,
            e.item_vat_rate AS ItemVatPrice,
            e.inv_qty_uom_code AS UOMCode,
            e.item_net_price AS PriceExcl,
            e.seller_name AS SellerName,
            e.seller_addr_line1 AS SellerAddressline1,
            e.seller_city AS SellerCity,
            e.seller_country_sub AS SellerCountrySubdivision,
            e.seller_country_code AS SellerCountryCode,
            e.inv_tot_without_tax AS InvTotExcl,
            e.inv_tot_tax_amt AS InvTotTax,
            e.inv_total_with_tax AS InvTotIncl,
            e.invoice_line_net_amt AS LineNet,
            e.vat_line_amt_aed AS LineTax,
            e.invoice_line_amt_aed AS LineTotal,
            e.vat_cat_taxable_amt AS TotalInvoiceAmt`;

const quoteIdentifier = (identifier) => `"${String(identifier).replace(/"/g, '""')}"`;

const getAllInvoices = async (docType = INVOICE_DOC_TYPE) => {
    const documentTable = getDocumentTable(docType);
    const rows = await db.queryUnsafe(`
        SELECT ${INVOICE_DETAIL_FIELDS}
        FROM ${documentTable} e
        WHERE ${buildDocTypeFilter("e", docType)}
    `);
    return normalizeInvoiceRows(rows);
};

const getInvoiceDetailsByNumbers = async (invoiceNumbers, docType = INVOICE_DOC_TYPE, invoiceTypeCode = null) => {
    if (!Array.isArray(invoiceNumbers) || invoiceNumbers.length === 0) {
        return [];
    }

    const sanitizedInvoiceNumbers = invoiceNumbers
        .filter((value) => value !== null && value !== undefined && value !== "")
        .map((value) => String(value).replace(/'/g, "''"));

    if (sanitizedInvoiceNumbers.length === 0) {
        return [];
    }

    const inClause = sanitizedInvoiceNumbers
        .map((invoiceNumber) => `'${invoiceNumber}'`)
        .join(", ");
    const documentTable = getDocumentTable(docType);
    const invoiceTypeFilter = buildInvoiceTypeCodeFilter("e", invoiceTypeCode);

    const rows = await db.queryUnsafe(`
        SELECT
            ${INVOICE_DETAIL_FIELDS},
            q.Status,
            q.IsSent,
            q.IsReceived,
            q.IsInvoiced,
            q.IsError,
            q.ErrorMessage,
            q.InvoicedAt,
            q.SentAt,
            q.ReceivedAt,
            q.ErrorAt
        FROM ${documentTable} e
        LEFT JOIN E_InvoiceQueue q ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        WHERE e.invoice_no IN (${inClause})
        AND ${buildDocTypeFilter("e", docType)}
        ${invoiceTypeFilter}
        ORDER BY e.invoice_no ASC, e.ID ASC
    `);
    return normalizeInvoiceRows(rows);
};

const normalizeSqlDate = (value) => {
    if (typeof value !== "string") return null;
    return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
};

const addDaysToSqlDate = (value, days) => {
    const safeDate = normalizeSqlDate(value);
    if (!safeDate) return null;

    const date = new Date(`${safeDate}T00:00:00.000Z`);
    date.setUTCDate(date.getUTCDate() + days);
    return date.toISOString().slice(0, 10);
};

const toSqlDateTimeStart = (value) => {
    const safeDate = normalizeSqlDate(value);
    return safeDate ? `${safeDate} 00:00:00.000` : null;
};

const toSqlNextDateTimeStart = (value) => {
    const safeDate = addDaysToSqlDate(value, 1);
    return safeDate ? `${safeDate} 00:00:00.000` : null;
};

const sqlTimestampLiteral = (value) => `{ts '${value}'}`;

const statusEquals = (alias, statusCode) => `${alias}.Status = '${statusCode}'`;

const normalizeDocTypes = (docType) => {
    const docTypes = Array.isArray(docType) ? docType : [docType];
    return docTypes
        .map((value) => Number(value))
        .filter((value) => Number.isFinite(value));
};

const getDocumentTable = (docType) => {
    const docTypes = normalizeDocTypes(docType);
    return docTypes.length === 1 && docTypes[0] === PURCHASE_DOC_TYPE
        ? PURCHASE_TABLE
        : INVOICE_TABLE;
};

const normalizeInvoiceTypeCode = (value) => {
    const code = String(value || "").trim();
    return /^(380|381)$/.test(code) ? code : null;
};

const buildDocTypeFilter = (alias, docType) => {
    const docTypes = normalizeDocTypes(docType);

    if (docTypes.length === 0) {
        return "1 = 0";
    }

    return docTypes.length === 1
        ? `${alias}.DocType = ${docTypes[0]}`
        : `${alias}.DocType IN (${docTypes.join(", ")})`;
};

const buildInvoiceTypeCodeFilter = (alias, invoiceTypeCode) => {
    const safeInvoiceTypeCode = normalizeInvoiceTypeCode(invoiceTypeCode);
    return safeInvoiceTypeCode ? ` AND ${alias}.invoice_type_code = '${safeInvoiceTypeCode}'` : "";
};

const buildQueueInvoiceTypeCodeFilter = (alias, invoiceTypeCode, documentTable = INVOICE_TABLE) => {
    const safeInvoiceTypeCode = normalizeInvoiceTypeCode(invoiceTypeCode);
    if (!safeInvoiceTypeCode) return "";

    return ` AND EXISTS (
        SELECT 1
        FROM ${documentTable} e
        WHERE e.invoice_no = ${alias}.InvNumber
          AND e.DocType = ${alias}.DocType
          AND e.invoice_type_code = '${safeInvoiceTypeCode}'
    )`;
};

const buildInvoiceDateFilter = (fromDate, toDate, alias = "e") => {
    const safeFromDate = toSqlDateTimeStart(fromDate);
    const safeToDate = toSqlNextDateTimeStart(toDate);
    const conditions = [];

    if (safeFromDate) {
        conditions.push(`${alias}.invoice_issue_date >= ${sqlTimestampLiteral(safeFromDate)}`);
    }

    if (safeToDate) {
        conditions.push(`${alias}.invoice_issue_date < ${sqlTimestampLiteral(safeToDate)}`);
    }

    return conditions.length ? ` AND ${conditions.join(" AND ")}` : "";
};

const buildQueueDateFilter = (fromDate, toDate, alias = "q") => {
    const safeFromDate = toSqlDateTimeStart(fromDate);
    const safeToDate = toSqlNextDateTimeStart(toDate);
    const conditions = [];

    if (safeFromDate) {
        conditions.push(`${alias}.InvDate >= ${sqlTimestampLiteral(safeFromDate)}`);
    }

    if (safeToDate) {
        conditions.push(`${alias}.InvDate < ${sqlTimestampLiteral(safeToDate)}`);
    }

    return conditions.length ? ` WHERE ${conditions.join(" AND ")}` : "";
};

const getDashboardCounts = async (fromDate, toDate, docType = INVOICE_DOC_TYPE, invoiceTypeCode = null) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q");
    const documentTable = getDocumentTable(docType);
    const invoiceTypeFilter = buildQueueInvoiceTypeCodeFilter("q", invoiceTypeCode, documentTable);
    const result = await db.queryUnsafe(`
        SELECT
            COUNT(DISTINCT q.QueueID) AS total,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 1)} AND COALESCE(q.IsInvoiced, 0) = 1 THEN q.QueueID END) AS pending,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 2)} THEN q.QueueID END) AS sent,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 3)} THEN q.QueueID END) AS success,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 3)} THEN q.QueueID END) AS received,
            COUNT(DISTINCT CASE WHEN COALESCE(q.IsInvoiced, 0) = 1 THEN q.QueueID END) AS invoiced,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 4)} THEN q.QueueID END) AS failed,
            COUNT(DISTINCT CASE WHEN ${statusEquals("q", 6)} THEN q.QueueID END) AS error
        FROM E_InvoiceQueue q
        WHERE ${buildDocTypeFilter("q", docType)}
        ${invoiceTypeFilter}
        ${dateFilter.replace('WHERE', 'AND')}
    `);
    return result[0] || {};
};

const getPendingAndFailedEntries = async (fromDate, toDate, docType = INVOICE_DOC_TYPE) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");
    const documentTable = getDocumentTable(docType);
    const rows = await db.queryUnsafe(`
        SELECT
            q.QueueID,
            MAX(q.AutoIndex) AS AutoIndex,
            MAX(q.DocType) AS DocType,
            MAX(q.InvNumber) AS InvNumber,
            MAX(q.InvDate) AS InvDate,
            MAX(q.CreatedAt) AS CreatedAt,
            MAX(q.Status) AS Status,
            MAX(q.ErrorMessage) AS ErrorMessage,
            MAX(q.RetryCount) AS RetryCount,
            MAX(COALESCE(e.buyer_name, '')) AS Customer,
            MAX(e.inv_total_with_tax) AS Amount
        FROM E_InvoiceQueue q
        LEFT JOIN ${documentTable} e
            ON q.InvNumber = e.invoice_no AND q.DocType = e.DocType
        WHERE ${buildDocTypeFilter("q", docType)}
        AND q.Status IN ('1', '4')
        ${dateFilter}
        GROUP BY q.QueueID
        ORDER BY MAX(q.InvDate) DESC, q.QueueID DESC
    `);

    const pending = rows.filter((row) => String(row.Status) === "1").length;
    const failed = rows.filter((row) => String(row.Status) === "4").length;

    return {
        counts: {
            total: rows.length,
            pending,
            failed,
            success: 0,
            received: 0,
            error: failed
        },
        entries: rows
    };
};

const getInvoicesByType = async (type, fromDate, toDate, docType = INVOICE_DOC_TYPE, invoiceTypeCode = null) => {
    const dateFilter = buildInvoiceDateFilter(fromDate, toDate, "e");
    const invoiceTypeFilter = buildInvoiceTypeCodeFilter("e", invoiceTypeCode);
    const documentTable = getDocumentTable(docType);

    if (type === "pending" || type === "sent" || type === "success" || type === "received" || type === "error" || type === "failed") {
        const statusCodeMap = {
            pending: 1,
            sent: 2,
            success: 3,
            received: 3,
            error: 6,
            failed: 4
        };
        const statusCode = statusCodeMap[type];

        return db.queryUnsafe(`
            SELECT
                e.invoice_no AS InvoiceNumber,
                MAX(e.unique_identifier_no) AS AutoIndex,
                MAX(COALESCE(q.QueueID, 0)) AS QueueID,
                MAX(q.instanceIdentifier) AS InstanceIdentifier,
                MAX(q.CreatedAt) AS QueueCreatedAt,
                MAX(q.CreatedAt) AS CreatedAt,
                MAX(e.invoice_issue_date) AS InvoiceIssueDate,
                MAX(COALESCE(e.buyer_name, '')) AS Customer,
                MAX(e.inv_tot_without_tax) AS InvTotExcl,
                MAX(e.inv_tot_tax_amt) AS InvTotTax,
                MAX(e.inv_total_with_tax) AS InvTotIncl,
                MAX(e.vat_cat_taxable_amt) AS TotalInvoiceAmt,
                MAX(e.DocType) AS DocType,
                MAX(COALESCE(q.Status, '')) AS Status,
                ${OUTBOUND_RESPONSE_FIELDS}
            FROM ${documentTable} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE ${statusEquals("q", statusCode)}
            ${statusCode === 1 ? "AND COALESCE(q.IsInvoiced, 0) = 1" : ""}
            AND ${buildDocTypeFilter("e", docType)} AND ${buildDocTypeFilter("q", docType)}
            ${invoiceTypeFilter}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(COALESCE(q.QueueID, 0)) DESC
        `);
    }
    if (type === "invoiced") {
        return db.queryUnsafe(`
            SELECT
                e.invoice_no AS InvoiceNumber,
                MAX(e.unique_identifier_no) AS AutoIndex,
                MAX(COALESCE(q.QueueID, 0)) AS QueueID,
                MAX(q.instanceIdentifier) AS InstanceIdentifier,
                MAX(q.CreatedAt) AS QueueCreatedAt,
                MAX(q.CreatedAt) AS CreatedAt,
                MAX(e.invoice_issue_date) AS InvoiceIssueDate,
                MAX(COALESCE(e.buyer_name, '')) AS Customer,
                MAX(e.inv_tot_without_tax) AS InvTotExcl,
                MAX(e.inv_tot_tax_amt) AS InvTotTax,
                MAX(e.inv_total_with_tax) AS InvTotIncl,
                MAX(e.vat_cat_taxable_amt) AS TotalInvoiceAmt,
                MAX(e.DocType) AS DocType,
                MAX(COALESCE(q.Status, '')) AS Status,
                ${OUTBOUND_RESPONSE_FIELDS}
            FROM ${documentTable} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            LEFT JOIN E_Get_Out_Trans t
                ON q.instanceIdentifier = t.RootInstance
            WHERE COALESCE(q.IsInvoiced, 0) = 1
            AND ${buildDocTypeFilter("e", docType)} AND ${buildDocTypeFilter("q", docType)}
            ${invoiceTypeFilter}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(COALESCE(q.QueueID, 0)) DESC
        `);
    }
    if (type === "error" || type === "failed") {
        // Only return queue status = 4 (Failed)
        // Also project fields required by the Errors screen.
        return db.queryUnsafe(`
            SELECT
                MAX(e.inv_txn_typ_cod) AS EINVOICETYPE,
                e.invoice_no AS InvNumber,
                MAX(e.unique_identifier_no) AS AutoIndex,
                MAX(e.invoice_issue_date) AS InvDate,
                MAX(COALESCE(e.buyer_name, '')) AS BUYER_NAME,
                MAX(e.inv_total_with_tax) AS inv_total_with_tax,
                MAX(e.DocType) AS DocType,
                MAX(COALESCE(q.Status, '')) AS Status,
                MAX(COALESCE(q.QueueID, 0)) AS QueueID,
                MAX(q.CreatedAt) AS QueueCreatedAt,
                MAX(q.CreatedAt) AS CreatedAt,
                MAX(q.ErrorMessage) AS ErrorMessage
            FROM ${documentTable} e
            INNER JOIN E_InvoiceQueue q
                ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
            WHERE ${statusEquals("q", 4)}
            AND ${buildDocTypeFilter("e", docType)} AND ${buildDocTypeFilter("q", docType)}
            ${invoiceTypeFilter}
            ${dateFilter}
            GROUP BY e.invoice_no
            ORDER BY MAX(COALESCE(q.QueueID, 0)) DESC
        `);
    }
    return db.queryUnsafe(`
        SELECT
            e.invoice_no AS InvoiceNumber,
            MAX(e.unique_identifier_no) AS AutoIndex,
            MAX(COALESCE(q.QueueID, 0)) AS QueueID,
            MAX(q.instanceIdentifier) AS InstanceIdentifier,
            MAX(q.CreatedAt) AS QueueCreatedAt,
            MAX(q.CreatedAt) AS CreatedAt,
            MAX(e.invoice_issue_date) AS InvoiceIssueDate,
            MAX(COALESCE(e.buyer_name, '')) AS Customer,
            MAX(e.inv_tot_without_tax) AS InvTotExcl,
            MAX(e.inv_tot_tax_amt) AS InvTotTax,
            MAX(e.inv_total_with_tax) AS InvTotIncl,
            MAX(e.vat_cat_taxable_amt) AS TotalInvoiceAmt,
            MAX(e.DocType) AS DocType,
            MAX(COALESCE(q.Status, '')) AS Status,
            ${OUTBOUND_RESPONSE_FIELDS}
        FROM ${documentTable} e
        LEFT JOIN E_InvoiceQueue q
            ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        LEFT JOIN E_Get_Out_Trans t
            ON q.instanceIdentifier = t.RootInstance
        WHERE 1 = 1
        AND ${buildDocTypeFilter("e", docType)}
        ${invoiceTypeFilter}
        AND (q.QueueID IS NULL OR ${buildDocTypeFilter("q", docType)})
        AND (q.QueueID IS NULL OR q.Status IS NULL OR q.Status <> '0')
        ${dateFilter}
        GROUP BY e.invoice_no
        ORDER BY MAX(COALESCE(q.QueueID, 0)) DESC
    `);
};

const getPurchaseExportRows = async (fromDate, toDate, invoiceTypeCode = null, search = "") => {
    const dateFilter = buildInvoiceDateFilter(fromDate, toDate, "e");
    const invoiceTypeFilter = buildInvoiceTypeCodeFilter("e", invoiceTypeCode);
    const safeSearch = String(search || "").trim().replace(/'/g, "''");
    const searchFilter = safeSearch
        ? ` AND (
            e.invoice_no LIKE '%${safeSearch}%'
            OR e.seller_name LIKE '%${safeSearch}%'
            OR e.buyer_name LIKE '%${safeSearch}%'
        )`
        : "";

    return db.queryUnsafe(`
        SELECT e.*
        FROM ${PURCHASE_TABLE} e
        WHERE ${buildDocTypeFilter("e", PURCHASE_DOC_TYPE)}
        ${invoiceTypeFilter}
        ${dateFilter}
        ${searchFilter}
        ORDER BY e.invoice_issue_date DESC, e.ID DESC
    `);
};

const getPurchaseExportColumns = async () => {
    const connection = await db.getConnection();
    const result = await connection.query(`SELECT * FROM ${quoteIdentifier(PURCHASE_TABLE)} WHERE 1=0`);
    return Array.isArray(result?.columns)
        ? result.columns.map((column) => column.name).filter(Boolean)
        : [];
};

const getPurchaseTypeCounts = async (fromDate, toDate) => {
    const dateFilter = buildInvoiceDateFilter(fromDate, toDate, "e");
    const rows = await db.queryUnsafe(`
        SELECT
            COUNT(CASE WHEN e.invoice_type_code = '380' THEN 1 END) AS purchaseCount,
            COUNT(CASE WHEN e.invoice_type_code = '380' THEN NULL ELSE 1 END) AS purchaseReturnCount
        FROM ${PURCHASE_TABLE} e
        WHERE ${buildDocTypeFilter("e", PURCHASE_DOC_TYPE)}
        ${dateFilter}
    `);

    return rows[0] || {};
};

const getFailedInvoiceErrors = async (fromDate, toDate) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");

    return db.queryUnsafe(`
        SELECT
            q.InvNumber,
            MAX(q.InvDate) AS InvDate,
            MAX(ld.DocumentName) AS EInvoiceType,
            MAX(COALESCE(IE.Customer, E.buyer_name, '')) AS buyer_name,
            MAX(COALESCE(IE.InvoiceAmt, E.inv_total_with_tax)) AS AMOUNT
        FROM E_InvoiceQueue q
        INNER JOIN E_InvoiceError IE
            ON q.InvNumber = IE.InvNumber
        LEFT JOIN E_Invoicing E
            ON q.InvNumber = E.invoice_no
        LEFT JOIN E_lastDocument ld
            ON E.DocType = ld.DocumentType
        WHERE q.Status = 4
        ${dateFilter}
        GROUP BY q.InvNumber
        ORDER BY MAX(q.InvDate) DESC, q.InvNumber DESC
    `);
};

const getArtaxInvoiceErrors = async (fromDate, toDate) => {
    const dateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");

    return db.queryUnsafe(`
        SELECT
            q.InvNumber,
            MAX(q.InvDate) AS InvDate,
            MAX(E.unique_identifier_no) AS AutoIndex,
            MAX(E.DocType) AS DocType,
            MAX(q.Status) AS Status,
            1 AS IsArtaxError,
            MAX(IE.ErrorAt) AS IsArtaxErrorAt,
            MAX(ld.DocumentName) AS EInvoiceType,
            MAX(COALESCE(IE.Customer, E.buyer_name, '')) AS buyer_name,
            MAX(COALESCE(IE.InvoiceAmt, E.inv_total_with_tax)) AS AMOUNT
        FROM E_InvoiceQueue q
        INNER JOIN E_InvoiceError IE
            ON q.InvNumber = IE.InvNumber
        LEFT JOIN E_Invoicing E
            ON q.InvNumber = E.invoice_no
        LEFT JOIN E_lastDocument ld
            ON E.DocType = ld.DocumentType
        WHERE q.Status = 6
        ${dateFilter}
        GROUP BY q.InvNumber
        ORDER BY MAX(q.InvDate) DESC, q.InvNumber DESC
    `);
};

const getFilterDebugStats = async (fromDate, toDate, docType = INVOICE_DOC_TYPE) => {
    const invoiceDateFilter = buildInvoiceDateFilter(fromDate, toDate, "e");
    const queueDateFilter = buildQueueDateFilter(fromDate, toDate, "q").replace("WHERE", "AND");
    const documentTable = getDocumentTable(docType);

    const invoiceByDocType = await db.queryUnsafe(`
        SELECT
            DocType,
            COUNT(*) AS RowCount,
            MIN(invoice_issue_date) AS MinInvoiceIssueDate,
            MAX(invoice_issue_date) AS MaxInvoiceIssueDate
        FROM ${documentTable}
        GROUP BY DocType
        ORDER BY DocType
    `);
    const queueByDocType = await db.queryUnsafe(`
        SELECT
            DocType,
            COUNT(*) AS RowCount,
            MIN(InvDate) AS MinInvDate,
            MAX(InvDate) AS MaxInvDate
        FROM E_InvoiceQueue
        GROUP BY DocType
        ORDER BY DocType
    `);
    const queueByDocTypeAndStatus = await db.queryUnsafe(`
        SELECT
            DocType,
            Status,
            COUNT(*) AS RowCount,
            MIN(InvDate) AS MinInvDate,
            MAX(InvDate) AS MaxInvDate
        FROM E_InvoiceQueue
        GROUP BY DocType, Status
        ORDER BY DocType, Status
    `);
    const invoiceExpectedDocType = await db.queryUnsafe(`
        SELECT COUNT(*) AS RowCount
        FROM ${documentTable} e
        WHERE ${buildDocTypeFilter("e", docType)}
    `);
    const invoiceExpectedDocTypeInRange = await db.queryUnsafe(`
        SELECT COUNT(*) AS RowCount
        FROM ${documentTable} e
        WHERE ${buildDocTypeFilter("e", docType)}
        ${invoiceDateFilter}
    `);
    const queueExpectedDocType = await db.queryUnsafe(`
        SELECT COUNT(*) AS RowCount
        FROM E_InvoiceQueue q
        WHERE ${buildDocTypeFilter("q", docType)}
    `);
    const queueExpectedDocTypeInRange = await db.queryUnsafe(`
        SELECT COUNT(*) AS RowCount
        FROM E_InvoiceQueue q
        WHERE ${buildDocTypeFilter("q", docType)}
        ${queueDateFilter}
    `);

    return {
        expectedDocType: docType,
        fromDate,
        toDate,
        filters: {
            invoiceDateFilter: invoiceDateFilter.trim(),
            queueDateFilter: queueDateFilter.trim()
        },
        invoiceTable: {
            byDocType: invoiceByDocType,
            expectedDocTypeRows: invoiceExpectedDocType[0]?.RowCount || 0,
            expectedDocTypeRowsInRange: invoiceExpectedDocTypeInRange[0]?.RowCount || 0
        },
        queueTable: {
            byDocType: queueByDocType,
            byDocTypeAndStatus: queueByDocTypeAndStatus,
            expectedDocTypeRows: queueExpectedDocType[0]?.RowCount || 0,
            expectedDocTypeRowsInRange: queueExpectedDocTypeInRange[0]?.RowCount || 0
        }
    };
};

const getInvoiceResponseLogs = async (invNumber) => {
    const sanitizedInvNumber = String(invNumber || "").replace(/'/g, "''");

    if (!sanitizedInvNumber) {
        return [];
    }

    return db.queryUnsafe(`
        SELECT
            "Id",
            "InvNumber",
            "Status" AS status,
            "ErrorAt",
            "Error" AS responseMessage
        FROM "E_InvoiceError"
        WHERE "InvNumber" = '${sanitizedInvNumber}'
        AND "Status" = 'VALIDATION_ERROR'
        ORDER BY "Id" DESC
    `);
};

const getArtaxErrorsResponse = async (invNumber) => {
    const sanitizedInvNumber = String(invNumber || "").replace(/'/g, "''");

    if (!sanitizedInvNumber) {
        return [];
    }

    return db.queryUnsafe(`
        SELECT
            "Id",
            "InvNumber",
            "Status" AS status,
            "ErrorAt",
            "Error" AS responseMessage
        FROM "E_InvoiceError"
        WHERE "InvNumber" = '${sanitizedInvNumber}'
        AND "Status" = 'ARTAX_ERROR'
        ORDER BY "Id" DESC
    `);
};

const getInvoiceDetails = async (invNumber, docType = INVOICE_DOC_TYPE, invoiceTypeCode = null) => {
    const sanitizedInvNumber = String(invNumber).replace(/'/g, "''");
    const invoiceTypeFilter = buildInvoiceTypeCodeFilter("e", invoiceTypeCode);
    const documentTable = getDocumentTable(docType);
    const result = await db.queryUnsafe(`
        SELECT
            ${INVOICE_DETAIL_FIELDS},
            q.Status,
            q.IsSent,
            q.IsReceived,
            q.IsInvoiced,
            q.IsError,
            q.ErrorMessage,
            q.InvoicedAt,
            q.SentAt,
            q.ReceivedAt,
            q.ErrorAt
        FROM ${documentTable} e
        LEFT JOIN E_InvoiceQueue q ON e.invoice_no = q.InvNumber AND e.DocType = q.DocType
        WHERE e.invoice_no = '${sanitizedInvNumber}'
        ${invoiceTypeFilter}
        ORDER BY e.ID ASC
    `);
    return normalizeInvoiceRows(result);
};

const getOutboundTransactions = async (instanceIdentifier) => {
    const safeInstanceIdentifier = String(instanceIdentifier || "").trim();

    if (!safeInstanceIdentifier) return [];

    return db.queryStatement(
        `SELECT
            RootInstance,
            RootTransType,
            TransactionId,
            TransmissionType,
            Status,
            SenderParticipantId,
            ReceiverPartiId,
            InstanceIdentifier,
            RefInstance,
            ErrorDetails,
            C5DispatchStatus,
            CreatedDate,
            LastModifiedDate,
            HasFile,
            InsertedOn
         FROM E_Get_Out_Trans
         WHERE RootInstance = @p0
         ORDER BY
            CASE LOWER(LTRIM(RTRIM(TransmissionType)))
                WHEN 'outbound' THEN 1
                WHEN 'c2_tdd_outbound' THEN 2
                WHEN 'mls_inbound' THEN 3
                WHEN 'c2_tdd_mls_inbound' THEN 4
                ELSE 5
            END,
            CreatedDate DESC,
            InsertedOn DESC`,
        [safeInstanceIdentifier]
    );
};


module.exports = {
    INVOICE_DOC_TYPE,
    PURCHASE_DOC_TYPE,
    getAllInvoices,
    getInvoiceDetailsByNumbers,
    getDashboardCounts,
    getPendingAndFailedEntries,
    getInvoicesByType,
    getPurchaseExportRows,
    getPurchaseExportColumns,
    getPurchaseTypeCounts,
    getFailedInvoiceErrors,
    getArtaxInvoiceErrors,
    getFilterDebugStats,
    getInvoiceResponseLogs,
    getArtaxErrorsResponse,
    getInvoiceDetails,
    getOutboundTransactions
};
