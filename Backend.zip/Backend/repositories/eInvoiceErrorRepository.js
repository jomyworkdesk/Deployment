const db = require("../dbSecondary");

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    return String(value);
};

const normalizeNumber = (value) => {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    const number = Number(value);
    return Number.isFinite(number) ? number : null;
};

const getNextErrorId = async () => {
    const rows = await db.queryUnsafe(`
        SELECT MAX("Id") AS MaxId
        FROM "E_InvoiceError"
    `);
    const maxId = Number(rows[0]?.MaxId);
    return Number.isFinite(maxId) ? maxId + 1 : 1;
};

const insertValidationError = async ({
    instanceIdentifier,
    invNumber,
    errorAt,
    error,
    customer,
    status,
    invoiceAmt,
    invDate,
    useDubaiNowForErrorAt = false
}) => {
    const id = await getNextErrorId();

    await db.execute`
        INSERT INTO E_InvoiceError (
            Id,
            InstanceIdentifier,
            InvNumber,
            ErrorAt,
            Error,
            Customer,
            Status,
            InvoiceAmt,
            InvDate,
            IsMail,
            IsError,
            RetryCount,
            CreatedAt
        )
        VALUES (
            ${id},
            ${normalizeText(instanceIdentifier)},
            ${normalizeText(invNumber)},
            CASE
                WHEN ${useDubaiNowForErrorAt ? 1 : 0} = 1
                THEN NOW()
                ELSE ${errorAt || null}
            END,
            ${normalizeText(error)},
            ${normalizeText(customer)},
            ${normalizeText(status)},
            ${normalizeNumber(invoiceAmt)},
            ${invDate || null},
            0,
            0,
            0,
            NOW()
        )
    `;

    return id;
};

const getMailRecipients = async () => {
    const rows = await db.query`
        SELECT TOP 1
            tomail,
            ccmail
        FROM E_config
        ORDER BY id
    `;

    return rows[0] || {};
};

const markMailSuccess = async ({ id, toMail, providerMessageId }) => {
    if (!id) return;

    await db.execute`
        UPDATE E_InvoiceError
        SET
            IsMail = 1,
            IsMailId = ${normalizeText(toMail)},
            ProviderMessageId = ${normalizeText(providerMessageId)},
            IsMailAt = NOW(),
            IsError = 0
        WHERE Id = ${id}
    `;
};

const markMailFailure = async ({ id, providerMessageId }) => {
    if (!id) return;

    await db.execute`
        UPDATE E_InvoiceError
        SET
            ProviderMessageId = ${normalizeText(providerMessageId)},
            IsError = 1,
            RetryCount = 1
        WHERE Id = ${id}
    `;
};

module.exports = {
    insertValidationError,
    getMailRecipients,
    markMailSuccess,
    markMailFailure
};
