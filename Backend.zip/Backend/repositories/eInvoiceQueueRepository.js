const dbSecondary = require("../dbSecondary");

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") return null;
    return String(value);
};

const normalizeQueueInstanceIdentifier = (value) => {
    const text = normalizeText(value);
    return text ? text.slice(0, 50) : null;
};

const getSafeBatchSize = (value) => {
    const batchSize = Number(value);
    return Number.isFinite(batchSize) && batchSize > 0 ? Math.floor(batchSize) : 5;
};

const getQueueIdClause = (queueRows = []) =>
    queueRows
        .map((row) => Number(row.QueueID))
        .filter(Number.isFinite)
        .join(",");

const markSentByInvoiceNumber = async ({ invNumber, instanceIdentifier }) => {
    if (!invNumber) return 0;
    const queueInstanceIdentifier = normalizeQueueInstanceIdentifier(instanceIdentifier);

    try {
        const affected = await dbSecondary.execute`
            UPDATE "E_InvoiceQueue"
            SET "instanceIdentifier" = ${queueInstanceIdentifier},
                "IsSent" = 1,
                "Status" = 2,
                "SentAt" = NOW()
            WHERE "InvNumber" = ${normalizeText(invNumber)}
        `;

        return affected || 0;
    } catch (error) {
        error.message = `mark E_InvoiceQueue sent failed for InvNumber=${invNumber}: ${error.message}`;
        throw error;
    }
};

const markArtaxErrorByInvoiceNumber = async ({ invNumber, errorMessage }) => {
    if (!invNumber) return 0;

    try {
        const affected = await dbSecondary.execute`
            UPDATE "E_InvoiceQueue"
            SET "IsArtaxError" = 1,
                "IsArtaxErrorAt" = NOW(),
                "IsProcessing" = 0,
                "Status" = 6,
                "ErrorMessage" = ${normalizeText(errorMessage)}
            WHERE "InvNumber" = ${normalizeText(invNumber)}
        `;

        return affected || 0;
    } catch (error) {
        error.message = `mark E_InvoiceQueue Artax error failed for InvNumber=${invNumber}: ${error.message}`;
        throw error;
    }
};

const markArtaxErrorsByInvoiceNumbers = async ({ invoiceNumbers, errorMessage }) => {
    if (!Array.isArray(invoiceNumbers) || invoiceNumbers.length === 0) return 0;

    let affected = 0;
    for (const invNumber of invoiceNumbers) {
        affected += await markArtaxErrorByInvoiceNumber({
            invNumber,
            errorMessage
        });
    }

    return affected;
};



const releaseQueueEntries = async (client = dbSecondary, queueRows = []) => {
    if (!queueRows.length) return 0;

    const queueClause = getQueueIdClause(queueRows);

    if (!queueClause) return 0;

    return client.executeUnsafe(`
        UPDATE E_InvoiceQueue
        SET IsProcessing = 0
        WHERE QueueID IN (${queueClause})
    `);
};

const markResponseByInstanceIdentifier = async ({ instanceIdentifier, isSuccess }) => {
    if (!instanceIdentifier) return 0;
    const queueInstanceIdentifier = normalizeQueueInstanceIdentifier(instanceIdentifier);

    try {
        if (isSuccess) {
            const affected = await dbSecondary.execute`
                UPDATE "E_InvoiceQueue"
                SET "IsReceived" = 1,
                    "IsError" = 0,
                    "IsProcessing" = 0,
                    "Status" = 3,
                    "ReceivedAt" = NOW()
                WHERE "instanceIdentifier" = ${queueInstanceIdentifier}
            `;

            return affected || 0;
        }

        const affected = await dbSecondary.execute`
            UPDATE "E_InvoiceQueue"
            SET "IsReceived" = 0,
                "IsError" = 1,
                "IsProcessing" = 0,
                "Status" = 4,
                "ErrorAt" = NOW()
            WHERE "instanceIdentifier" = ${queueInstanceIdentifier}
        `;

        return affected || 0;
    } catch (error) {
        error.message = `mark E_InvoiceQueue response failed for instanceIdentifier=${queueInstanceIdentifier}, success=${isSuccess}: ${error.message}`;
        throw error;
    }
};

module.exports = {

    releaseQueueEntries,
    markSentByInvoiceNumber,
    markArtaxErrorByInvoiceNumber,
    markArtaxErrorsByInvoiceNumbers,
    markResponseByInstanceIdentifier
};
