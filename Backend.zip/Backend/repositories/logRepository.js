const db = require("../dbSecondary");

const getResponseLogs = async () =>
    db.queryUnsafe(`
        SELECT TOP 1000
            l."Id",
            l."response_id",
            l."messageId",
            l."instanceIdentifier",
            l."InvNumber",
            l."senderParticipantID",
            l."ReceiverPartiId",
            l."documentTypeID",
            l."processID",
            l."transmissionType",
            l."status",
            l."serviceProviderId",
            l."responseCreatedDate",
            l."responseMessage",
            l."errorDetails",
            COALESCE(w.UserName, l."createdby") AS createdby,
            l."createdAt"
        FROM "e_invoice_resp_log" l
        LEFT JOIN E_WebLogin w
            ON CAST(w.AgentId AS VARCHAR(100)) = l."createdby"
        ORDER BY l."Id" DESC
    `);

const getTokenLogs = async () =>
    db.queryUnsafe(`
        SELECT TOP 1000
            l.Id,
            l.access_token,
            l.expires_in,
            l.refresh_token,
            l.token_type,
            COALESCE(w.UserName, l.createdby) AS createdby,
            l.createdAt
        FROM e_invoicetokenlog l
        LEFT JOIN E_WebLogin w
            ON CAST(w.AgentId AS VARCHAR(100)) = l.createdby
        ORDER BY l.Id DESC
    `);

const getAppLogs = async () =>
    db.queryUnsafe(`
        SELECT
            w.LogID,
            w.AgentId,
            w.UserName,
            w.LoginStatus,
            w.LoginDateTime,
            w.LogoutDateTime,
            w.IPAddress,
            w.Browser,
            w.Country,
            w.City,
            w.Latitude,
            w.Longitude,
            w.FailureReason,
            w.SessionId
        FROM E_WebLogin_Log w
        ORDER BY w.LogID DESC
    `);

const getAppLoggerBySessionId = async (sessionId) => {
    if (!sessionId) return [];

    const safeSessionId = String(sessionId).replace(/'/g, "''");
    return db.queryUnsafe(`
        SELECT
            LogID,
            LogDateTime,
            Level,
            Message,
            Method,
            Url,
            StatusCode,
            SessionId
        FROM E_AppLogger
        WHERE SessionId = '${safeSessionId}'
        ORDER BY LogID DESC
    `);
};

module.exports = {
    getResponseLogs,
    getTokenLogs,
    getAppLogs,
    getAppLoggerBySessionId
};
