const db = require("../dbSecondary");

let tokenLogTableReady = false;
const tokenLogTableName = "e_invoicetokenlog";

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    return String(value);
};

const ensureTokenLogTable = async () => {
    if (tokenLogTableReady) return;

    // This table is managed in Pervasive. Avoid SQL Server-only DDL here.
    tokenLogTableReady = true;
};

const getNextTokenLogId = async () => {
    const rows = await db.queryUnsafe(`
        SELECT MAX("Id") AS MaxId
        FROM "${tokenLogTableName}"
    `);
    const maxId = Number(rows[0]?.MaxId);
    return Number.isFinite(maxId) ? maxId + 1 : 1;
};

const saveTokenLog = async ({
    accessToken,
    expiresIn,
    refreshToken,
    tokenType,
    createdBy
}) => {
    await ensureTokenLogTable();
    const nextId = await getNextTokenLogId();

    await db.execute`
        INSERT INTO "e_invoicetokenlog" (
            "Id",
            "access_token",
            "expires_in",
            "refresh_token",
            "token_type",
            "createdby",
            "createdAt"
        )
        VALUES (
            ${nextId},
            ${normalizeText(accessToken)},
            ${normalizeText(expiresIn)},
            ${normalizeText(refreshToken)},
            ${normalizeText(tokenType)},
            ${normalizeText(createdBy)},
            NOW()
        )
    `;
};

module.exports = {
    saveTokenLog
};
