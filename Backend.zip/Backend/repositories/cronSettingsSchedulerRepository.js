const db = require("../dbSecondary");
const { getSqlLocalDateTime } = require("../utils/schedulerTime");

const CRON_SETTINGS_TABLE = "E_CronSettings";

const selectSettingColumns = `
    Id,
    JobName,
    CronExpression,
    RunType,
    RunEverySeconds,
    RunAtTime,
    Manual,
    LastRunTime,
    NextRunTime,
    IsEnabled,
    Status,
    IsQueue,
    IsProcessing
`;

const resetAutomationJobNameCondition = "UPPER(LTRIM(RTRIM(COALESCE(JobName, '')))) = 'RESET AUTOMATION'";
const allowedConfigRef = "J12";
const configRefSkipReasons = {
    A12: "Expired",
    D12: "Document count exceeded"
};

const getCronExecutionStatus = async () => {
    const rows = await db.query`
        SELECT TOP 1 Ref
        FROM E_config
        ORDER BY id
    `;

    const ref = String(rows[0]?.Ref || "").trim().toUpperCase();

    return {
        allowed: ref === allowedConfigRef,
        ref,
        reason: configRefSkipReasons[ref] || "E_config.Ref is not J12"
    };
};

const isCronExecutionAllowed = async () =>
    (await getCronExecutionStatus()).allowed;

const queueDueActiveSettings = async () => {
    const currentLocalTime = getSqlLocalDateTime(new Date());

    return db.executeStatement(`
        UPDATE ${CRON_SETTINGS_TABLE}
        SET IsQueue = 1,
            UpdatedOn = NOW()
        WHERE UPPER(COALESCE(Status, '')) = 'ACTIVE'
            AND (COALESCE(IsEnabled, 1) = 1 OR COALESCE(Manual, 0) = 1)
            AND (
                ${resetAutomationJobNameCondition}
                OR COALESCE(IsProcessing, 0) = 0
            )
            AND COALESCE(IsQueue, 0) = 0
            AND NextRunTime IS NOT NULL
            AND NextRunTime <= @p0
    `, [currentLocalTime]);
};

const claimNextQueuedSetting = async () =>
    db.withTransaction(async (tx) => {
        const getResetAutomationRows = () => tx.queryUnsafe(`
            SELECT TOP 1
                ${selectSettingColumns}
            FROM ${CRON_SETTINGS_TABLE}
            WHERE UPPER(COALESCE(Status, '')) = 'ACTIVE'
                AND (COALESCE(IsEnabled, 1) = 1 OR COALESCE(Manual, 0) = 1)
                AND COALESCE(IsQueue, 0) = 1
                AND ${resetAutomationJobNameCondition}
            ORDER BY NextRunTime, Id
        `);

        const getRegularJobRows = () => tx.queryUnsafe(`
            SELECT TOP 1
                ${selectSettingColumns}
            FROM ${CRON_SETTINGS_TABLE}
            WHERE UPPER(COALESCE(Status, '')) = 'ACTIVE'
                AND (COALESCE(IsEnabled, 1) = 1 OR COALESCE(Manual, 0) = 1)
                AND COALESCE(IsQueue, 0) = 1
                AND COALESCE(IsProcessing, 0) = 0
                AND NOT (${resetAutomationJobNameCondition})
            ORDER BY NextRunTime, Id
        `);

        const rows = await getResetAutomationRows();
        let setting = rows[0] || null;

        if (!setting) {
            const processingRows = await tx.queryUnsafe(`
                SELECT TOP 1 Id
                FROM ${CRON_SETTINGS_TABLE}
                WHERE COALESCE(IsProcessing, 0) = 1
            `);

            if (processingRows.length === 0) {
                setting = (await getRegularJobRows())[0] || null;
            }
        }

        if (!setting) return null;

        await tx.executeStatement(`
            UPDATE ${CRON_SETTINGS_TABLE}
            SET IsProcessing = 1,
                UpdatedOn = NOW()
            WHERE Id = @p0
        `, [setting.Id]);

        return {
            ...setting,
            IsProcessing: 1
        };
    });

const completeCronSettingRun = async ({ id, lastRunTime, nextRunTime, manual }) =>
    db.executeStatement(`
        UPDATE ${CRON_SETTINGS_TABLE}
        SET LastRunTime = @p0,
            NextRunTime = @p1,
            Manual = @p2,
            IsProcessing = 0,
            IsQueue = 0,
            UpdatedOn = NOW()
        WHERE Id = @p3
    `, [lastRunTime, nextRunTime, manual, id]);

const skipCronSettingRun = async ({ id, nextRunTime, manual }) =>
    db.executeStatement(`
        UPDATE ${CRON_SETTINGS_TABLE}
        SET NextRunTime = @p0,
            Manual = @p1,
            IsProcessing = 0,
            IsQueue = 0,
            UpdatedOn = NOW()
        WHERE Id = @p2
    `, [nextRunTime, manual, id]);

const releaseCronSettingRun = async (id) =>
    db.executeStatement(`
        UPDATE ${CRON_SETTINGS_TABLE}
        SET IsProcessing = 0,
            IsQueue = 0,
            UpdatedOn = NOW()
        WHERE Id = @p0
    `, [id]);

const resetAutomationSettings = async () =>
    db.executeUnsafe(`
        UPDATE ${CRON_SETTINGS_TABLE}
        SET IsQueue = 0,
            IsProcessing = 0,
            UpdatedOn = NOW()
    `);

const recoverSchedulerStateOnStartup = async () =>
    db.executeUnsafe(`
        UPDATE ${CRON_SETTINGS_TABLE}
        SET IsQueue = 0,
            IsProcessing = 0,
            UpdatedOn = NOW()
        WHERE COALESCE(IsProcessing, 0) = 1
            OR COALESCE(IsQueue, 0) = 1
    `);

module.exports = {
    getCronExecutionStatus,
    isCronExecutionAllowed,
    queueDueActiveSettings,
    claimNextQueuedSetting,
    completeCronSettingRun,
    skipCronSettingRun,
    releaseCronSettingRun,
    resetAutomationSettings,
    recoverSchedulerStateOnStartup
};
