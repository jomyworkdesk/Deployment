const db = require("../dbSecondary");

const getClient = () => db;

const getRowValue = (row, ...names) => {
    if (!row) return null;

    const key = Object.keys(row).find((rowKey) =>
        names.some((name) => rowKey.toLowerCase() === String(name).toLowerCase())
    );

    return key ? row[key] : null;
};

const normalizeFlag = (value) => {
    if (value === null || value === undefined || value === "") return value;
    if (value === true) return 1;
    if (value === false) return 0;
    if (typeof value === "number") return value === 0 ? 0 : 1;

    const text = String(value).trim().toLowerCase();
    if (["1", "true", "yes", "y"].includes(text)) return 1;
    if (["0", "false", "no", "n"].includes(text)) return 0;

    return value;
};

const normalizePageRow = (row) => {
    if (!row) return null;

    return {
        ...row,
        PageId: getRowValue(row, "PageId"),
        PageName: getRowValue(row, "PageName"),
        MenuText: getRowValue(row, "MenuText"),
        Route: getRowValue(row, "Route"),
        SortOrder: getRowValue(row, "SortOrder"),
        IsActive: normalizeFlag(getRowValue(row, "IsActive"))
    };
};

const normalizeRolePageAccessRow = (row) => {
    if (!row) return null;

    return {
        ...row,
        RoleId: getRowValue(row, "RoleId"),
        PageId: getRowValue(row, "PageId"),
        HasAccess: normalizeFlag(getRowValue(row, "HasAccess"))
    };
};

const normalizeUserRoleRow = (row) => {
    if (!row) return null;

    return {
        ...row,
        RoleId: getRowValue(row, "RoleId"),
        RoleName: getRowValue(row, "RoleName"),
        Description: getRowValue(row, "Description"),
        IsActive: normalizeFlag(getRowValue(row, "IsActive"))
    };
};

const normalizeWebLoginRow = (row) => {
    if (!row) return null;

    return {
        ...row,
        AutoIndex: getRowValue(row, "AutoIndex"),
        UserName: getRowValue(row, "UserName"),
        RoleId: getRowValue(row, "RoleId"),
        RoleName: getRowValue(row, "RoleName"),
        IsActive: normalizeFlag(getRowValue(row, "IsActive")),
        CreatedDate: getRowValue(row, "CreatedDate"),
        ModifiedDate: getRowValue(row, "ModifiedDate"),
        Password:
            row.Password ||
            row.password ||
            row.PASSWORD ||
            row.UserPassword ||
            row.userPassword ||
            row.USERPASSWORD ||
            null
    };
};

const getNextPageId = async () => {
    const rows = await db.query`
        SELECT MAX(PageId) AS MaxPageId
        FROM E_Page
    `;
    return (Number(getRowValue(rows[0], "MaxPageId")) || 0) + 1;
};

const getNextRoleId = async () => {
    const rows = await db.query`
        SELECT MAX(RoleId) AS MaxRoleId
        FROM E_UserRole
    `;
    return (Number(getRowValue(rows[0], "MaxRoleId")) || 0) + 1;
};

const getNextWebLoginAutoIndex = async () => {
    const rows = await db.query`
        SELECT MAX(AutoIndex) AS MaxAutoIndex
        FROM E_WebLogin
    `;
    return (Number(getRowValue(rows[0], "MaxAutoIndex")) || 0) + 1;
};

const listPages = async (databaseName) => {
    const rows = await getClient(databaseName).query`
        SELECT TOP 1000
            PageId,
            PageName,
            MenuText,
            Route,
            SortOrder,
            IsActive
        FROM E_Page
        ORDER BY SortOrder, PageId
    `;

    return rows.map(normalizePageRow);
};

const getPage = async (databaseName, pageId) => {
    const rows = await getClient(databaseName).query`
        SELECT TOP 1
            PageId,
            PageName,
            MenuText,
            Route,
            SortOrder,
            IsActive
        FROM E_Page
        WHERE PageId = ${pageId}
    `;
    return normalizePageRow(rows[0]);
};

const createPage = async ({ databaseName, PageName, MenuText, Route, SortOrder, IsActive }) => {
    const pageId = await getNextPageId();

    await getClient(databaseName).execute`
        INSERT INTO E_Page
        (
            PageId,
            PageName,
            MenuText,
            Route,
            SortOrder,
            IsActive
        )
        VALUES
        (
            ${pageId},
            ${PageName},
            ${MenuText},
            ${Route},
            ${SortOrder},
            ${IsActive}
        )
    `;

    return getPage(databaseName, pageId);
};

const updatePage = async (databaseName, pageId, payload) => {
    await getClient(databaseName).execute`
        UPDATE E_Page
        SET PageName = ${payload.PageName},
            MenuText = ${payload.MenuText},
            Route = ${payload.Route},
            SortOrder = ${payload.SortOrder},
            IsActive = ${payload.IsActive}
        WHERE PageId = ${pageId}
    `;
    return getPage(databaseName, pageId);
};

const listRolePageAccess = async (databaseName) => {
    const rows = await getClient(databaseName).query`
        SELECT TOP 1000
            RoleId,
            PageId,
            HasAccess
        FROM E_RolePageAccess
        ORDER BY RoleId, PageId
    `;

    return rows.map(normalizeRolePageAccessRow);
};

const getRolePageAccess = async (databaseName, roleId, pageId) => {
    const rows = await getClient(databaseName).query`
        SELECT TOP 1
            RoleId,
            PageId,
            HasAccess
        FROM E_RolePageAccess
        WHERE RoleId = ${roleId}
          AND PageId = ${pageId}
    `;
    return normalizeRolePageAccessRow(rows[0]);
};

const createRolePageAccess = async ({ databaseName, RoleId, PageId, HasAccess }) => {
    const existing = await getRolePageAccess(databaseName, RoleId, PageId);

    if (existing) {
        await getClient(databaseName).execute`
            UPDATE E_RolePageAccess
            SET HasAccess = ${HasAccess}
            WHERE RoleId = ${RoleId}
              AND PageId = ${PageId}
        `;

        return getRolePageAccess(databaseName, RoleId, PageId);
    }

    await getClient(databaseName).execute`
        INSERT INTO E_RolePageAccess
        (
            RoleId,
            PageId,
            HasAccess
        )
        VALUES
        (
            ${RoleId},
            ${PageId},
            ${HasAccess}
        )
    `;

    return getRolePageAccess(databaseName, RoleId, PageId);
};

const updateRolePageAccess = async (databaseName, roleId, pageId, payload) => {
    const existing = await getRolePageAccess(databaseName, roleId, pageId);

    if (!existing) {
        return createRolePageAccess({
            databaseName,
            RoleId: roleId,
            PageId: pageId,
            HasAccess: payload.HasAccess
        });
    }

    await getClient(databaseName).execute`
        UPDATE E_RolePageAccess
        SET HasAccess = ${payload.HasAccess}
        WHERE RoleId = ${roleId}
          AND PageId = ${pageId}
    `;
    return getRolePageAccess(databaseName, roleId, pageId);
};

const listUserRoles = async (databaseName) => {
    const rows = await getClient(databaseName).query`
        SELECT TOP 1000
            RoleId,
            RoleName,
            Description,
            IsActive
        FROM E_UserRole
        ORDER BY RoleId
    `;

    return rows.map(normalizeUserRoleRow);
};

const getUserRole = async (databaseName, roleId) => {
    const rows = await getClient(databaseName).query`
        SELECT TOP 1
            RoleId,
            RoleName,
            Description,
            IsActive
        FROM E_UserRole
        WHERE RoleId = ${roleId}
    `;
    return normalizeUserRoleRow(rows[0]);
};

const createUserRole = async ({ databaseName, RoleName, Description, IsActive }) => {
    const roleId = await getNextRoleId();

    await getClient(databaseName).execute`
        INSERT INTO E_UserRole
        (
            RoleId,
            RoleName,
            Description,
            IsActive
        )
        VALUES
        (
            ${roleId},
            ${RoleName},
            ${Description},
            ${IsActive}
        )
    `;

    return getUserRole(databaseName, roleId);
};

const updateUserRole = async (databaseName, roleId, payload) => {
    await getClient(databaseName).execute`
        UPDATE E_UserRole
        SET RoleName = ${payload.RoleName},
            Description = ${payload.Description},
            IsActive = ${payload.IsActive}
        WHERE RoleId = ${roleId}
    `;
    return getUserRole(databaseName, roleId);
};

const listWebLogins = async (databaseName) => {
    const rows = await getClient(databaseName).query`
        SELECT TOP 1000
            wl.AutoIndex,
            wl.UserName,
            wl.UserPassword,
            wl.RoleId,
            ur.RoleName,
            wl.IsActive,
            wl.CreatedDate,
            wl.ModifiedDate
        FROM E_WebLogin wl
        LEFT JOIN E_UserRole ur
            ON ur.RoleId = wl.RoleId
        ORDER BY wl.AutoIndex
    `;

    return rows.map(normalizeWebLoginRow);
};

const getWebLogin = async (databaseName, autoIndex) => {
    const rows = await getClient(databaseName).query`
        SELECT TOP 1
            wl.AutoIndex,
            wl.UserName,
            wl.UserPassword,
            wl.RoleId,
            ur.RoleName,
            wl.IsActive,
            wl.CreatedDate,
            wl.ModifiedDate
        FROM E_WebLogin wl
        LEFT JOIN E_UserRole ur
            ON ur.RoleId = wl.RoleId
        WHERE wl.AutoIndex = ${autoIndex}
    `;
    return normalizeWebLoginRow(rows[0]);
};

const createWebLogin = async ({ databaseName, UserName, Password, RoleId, IsActive }) => {
    const autoIndex = await getNextWebLoginAutoIndex();

    await getClient(databaseName).execute`
        INSERT INTO E_WebLogin
        (
            AutoIndex,
            UserName,
            UserPassword,
            RoleId,
            IsActive,
            CreatedDate,
            ModifiedDate
        )
        VALUES
        (
            ${autoIndex},
            ${UserName},
            ${Password},
            ${RoleId},
            ${IsActive},
            NOW(),
            NOW()
        )
    `;

    return getWebLogin(databaseName, autoIndex);
};

const updateWebLogin = async (databaseName, autoIndex, payload) => {
    await getClient(databaseName).execute`
        UPDATE E_WebLogin
        SET UserName = ${payload.UserName},
            UserPassword = ${payload.Password},
            RoleId = ${payload.RoleId},
            IsActive = ${payload.IsActive},
            ModifiedDate = NOW()
        WHERE AutoIndex = ${autoIndex}
    `;
    return getWebLogin(databaseName, autoIndex);
};

module.exports = {
    listPages,
    getPage,
    createPage,
    updatePage,
    listRolePageAccess,
    getRolePageAccess,
    createRolePageAccess,
    updateRolePageAccess,
    listUserRoles,
    getUserRole,
    createUserRole,
    updateUserRole,
    listWebLogins,
    getWebLogin,
    createWebLogin,
    updateWebLogin
};
