const db = require("../dbSecondary");

const PURCHASE_TABLE = "E_Purchase";
const IN_DOCUMENT_TABLE = "E_InvoiceinDocument";
const IN_DOCUMENT_COLUMNS = [
    "invoiced_obj_id",
    "inv_obj_scheme_id",
    "document_type_code",
    "support_doc_ref",
    "support_doc_desc",
    "attached_document",
    "attach_doc_mime_code",
    "attach_doc_filename",
    "external_doc_loc"
];
const IN_DOCUMENT_COLUMN_SET = new Set(IN_DOCUMENT_COLUMNS.map((column) => column.toLowerCase()));

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") return null;
    return String(value);
};

const normalizeTextMax = (value, maxLength) => {
    const text = normalizeText(value);
    return text && maxLength ? text.slice(0, maxLength) : text;
};

const quoteIdentifier = (identifier) => `"${String(identifier).replace(/"/g, '""')}"`;

const createColumn = (name) => ({
    name,
    dataType: "",
    maxLength: null
});

const getSafeLimit = (limit, fallback) => {
    const numericLimit = Number(limit);
    return Number.isFinite(numericLimit) && numericLimit > 0
        ? Math.floor(numericLimit)
        : fallback;
};

const getLastIdentity = async (client = db) => {
    const rows = await client.queryUnsafe("SELECT @@IDENTITY AS ID");
    return rows[0]?.ID || rows[0]?.Id || rows[0]?.id || null;
};

const normalizeTimestamp = (value) => {
    if (!value) {
        return null;
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        throw new Error(`Invalid timestamp: ${value}`);
    }

    return date
        .toISOString()
        .slice(0, 19)
        .replace("T", " ");
};

const getCharacterLimit = (column) => {
    if (!column || column.maxLength === null || column.maxLength === undefined) return null;
    const maxLength = Number(column.maxLength);
    if (!Number.isFinite(maxLength) || maxLength < 0) return null;
    if (["nchar", "nvarchar"].includes(column.dataType)) return Math.floor(maxLength);
    if (["char", "varchar"].includes(column.dataType)) return maxLength;
    return null;
};

const prepareTableValue = (tableName, column, value) => {
    if (value === null || value === undefined) return null;

    if (["binary", "varbinary", "image"].includes(column.dataType)) {
        if (Buffer.isBuffer(value)) return value;
        return Buffer.from(String(value), "base64");
    }

    const limit = getCharacterLimit(column);
    if (limit && typeof value === "string" && value.length > limit) {
        throw new Error(
            `${tableName}.${column.name} length ${value.length} exceeds max ${limit}`
        );
    }

    return value;
};

const preparePurchaseValue = (column, value) => prepareTableValue(PURCHASE_TABLE, column, value);
const prepareInDocumentValue = (column, value) => prepareTableValue(IN_DOCUMENT_TABLE, column, value);

const isServerTimestampColumn = (column) =>
    ["created_at", "updated_at"].includes(String(column?.name || "").toLowerCase());

const hasActivePurchaseProcess = async (client = db) => {
    const rows = await client.query`
        SELECT TOP 1 QueueId
        FROM E_PurchaseQueue
        WHERE ISNULL(IsProcessing, 0) = 1
          AND ProcessEndedAt IS NULL
    `;

    return rows.length > 0;
};

const getQueuedInstancesByCorrelationId = async ({ correlationId, client = db }) =>
    client.query`
        SELECT
            QueueId,
            InstanceIdentifier,
            CorrelationId
        FROM E_PurchaseQueue
        WHERE CorrelationId = ${normalizeText(correlationId)}
          AND ISNULL(IsProcessing, 0) = 1
          AND ISNULL(IsTrans, 0) = 0
        ORDER BY QueueId
    `;

const getIncompleteTransactionQueueRows = async ({ limit = 100, client = db } = {}) =>
    client.query`
        SELECT TOP ${getSafeLimit(limit, 100)}
            QueueId,
            InstanceIdentifier,
            TransactionId,
            TransCount
        FROM E_PurchaseQueue
        WHERE InstanceIdentifier IS NOT NULL
          AND COALESCE(TransCount, 0) <> 4
        ORDER BY QueueId
    `;

const getQueuedTransactionsByCorrelationId = async ({ correlationId, client = db }) =>
    client.query`
        SELECT
            QueueId,
            InstanceIdentifier,
            CorrelationId,
            TransactionId
        FROM E_PurchaseQueue
        WHERE CorrelationId = ${normalizeText(correlationId)}
          AND ISNULL(IsProcessing, 0) = 1
          AND ISNULL(IsTrans, 0) = 1
          AND ISNULL(IsInserted, 0) = 0
          AND TransactionId IS NOT NULL
        ORDER BY QueueId
    `;

const getQueuedInsertedInvoicesByCorrelationId = async ({ correlationId, client = db }) =>
    client.query`
        SELECT
            QueueId,
            InstanceIdentifier,
            CorrelationId,
            TransactionId,
            InvoiceNo,
            InvoiceType
        FROM E_PurchaseQueue
        WHERE CorrelationId = ${normalizeText(correlationId)}
          AND ISNULL(IsProcessing, 0) = 1
          AND ISNULL(IsInserted, 0) = 1
          AND ISNULL(IsMail, 0) = 0
        ORDER BY QueueId
    `;

const getMailConfig = async (client = db) => {
    const rows = await client.query`
        SELECT TOP 1
            tomail,
            ccmail
        FROM E_config
        ORDER BY id
    `;

    return rows[0] || null;
};

const getPurchaseRowsByInstanceIdentifier = async ({ instanceIdentifier, client = db }) =>
    client.query`
        SELECT *
        FROM E_Purchase
        WHERE InstanceIdentifier = ${normalizeText(instanceIdentifier)}
        ORDER BY ID
    `;

const insertEmailLog = async ({
    queueId,
    receiverId,
    instanceIdentifier,
    invoiceType,
    toMail,
    ccMail,
    subject,
    status,
    providerMessageId,
    errorMessage,
    sentAt = null,
    client = db
}) =>
    client.execute`
        INSERT INTO E_EmailLog (
            QueueId,
            ReceiverId,
            InstanceIdentifier,
            InvoiceType,
            ToMail,
            CcMail,
            Subject,
            Status,
            ProviderMessageId,
            ErrorMessage,
            SentAt,
            EventAt,
            CreatedAt
        )
        VALUES (
            ${queueId},
            ${normalizeText(receiverId)},
            ${normalizeText(instanceIdentifier)},
            ${normalizeText(invoiceType)},
            ${normalizeText(toMail)},
            ${normalizeText(ccMail)},
            ${normalizeText(subject)},
            ${normalizeText(status)},
            ${normalizeText(providerMessageId)},
            ${normalizeTextMax(errorMessage, 3900)},
            ${sentAt},
            NOW(),
            NOW()
        )
    `;

const insertInstanceIdentifiers = async ({
    identifiers,
    correlationId,
    startDate,
    endDate,
    client = db
}) => {
    let insertedInstances = 0;
    let insertedQueue = 0;
    let skipped = 0;

    for (const item of identifiers) {
        const instanceIdentifier = normalizeText(item?.instanceIdentifier);

        if (!instanceIdentifier) {
            skipped += 1;
            continue;
        }

        // ---------------------------------------------------------
        // Check whether InstanceIdentifier already exists
        // ---------------------------------------------------------
        const rows = await client.query`
            SELECT TOP 1 InstanceIdentifier
            FROM E_Get_InstanIdentifi
            WHERE InstanceIdentifier = ${instanceIdentifier}
        `;

        const exists = rows.length > 0;

        // ---------------------------------------------------------
        // Insert into E_Get_InstanIdentifi if it doesn't exist
        // ---------------------------------------------------------
        if (!exists) {
            const idRows = await client.query`
                SELECT COALESCE(MAX(Id), 0) + 1 AS nextId
                FROM E_Get_InstanIdentifi
            `;

            const nextId = Number(idRows[0]?.nextId || 1);

            insertedInstances += await client.execute`
                INSERT INTO E_Get_InstanIdentifi (
                    Id,
                    InstanceIdentifier,
                    TransmissionType,
                    Status,
                    StartDate,
                    EndDate,
                    IsProcessed,
                    CreatedAt
                )
                VALUES (
                    ${nextId},
                    ${instanceIdentifier},
                    ${normalizeText(item?.transmissionType)},
                    ${normalizeText(item?.status)},
                    ${startDate},
                    ${endDate},
                    0,
                    NOW()
                )
            `;
        }

        // ---------------------------------------------------------
        // Check whether InstanceIdentifier already exists in queue
        // ---------------------------------------------------------
        const queueRows = await client.query`
            SELECT TOP 1 QueueId
            FROM E_PurchaseQueue
            WHERE InstanceIdentifier = ${instanceIdentifier}
        `;

        if (queueRows.length > 0) {
            skipped += 1;
            continue;
        }

        // ---------------------------------------------------------
        // Generate QueueId because QueueId is NOT NULL and
        // E_PurchaseQueue does not define an auto-generated value
        // ---------------------------------------------------------
        const queueIdRows = await client.query`
            SELECT COALESCE(MAX(QueueId), 0) + 1 AS nextQueueId
            FROM E_PurchaseQueue
        `;

        const nextQueueId = Number(queueIdRows[0]?.nextQueueId || 1);

        // ---------------------------------------------------------
        // Insert into E_PurchaseQueue
        // ---------------------------------------------------------
        insertedQueue += await client.execute`
            INSERT INTO E_PurchaseQueue (
                QueueId,
                InstanceIdentifier,
                CorrelationId,
                TransmissionType,
                ApiStatus,
                IsInstance,
                InstanceAt,
                IsProcessing,
                Status,
                ProcessingStatus,
                ProcessStartedAt,
                ProcessEndedAt,
                CreatedAt,
                UpdatedAt
            )
            VALUES (
                ${nextQueueId},
                ${instanceIdentifier},
                ${normalizeText(correlationId)},
                ${normalizeText(item?.transmissionType)},
                ${normalizeText(item?.status)},
                1,
                NOW(),
                1,
                2,
                ${normalizeText("InstanceIdentifier Received")},
                NOW(),
                NULL,
                NOW(),
                NOW()
            )
        `;
    }

    return {
        insertedInstances,
        insertedQueue,
        skipped
    };
};

const toBit = (value) => {
    if (value === true || value === 1) return 1;
    if (typeof value === "string" && value.toLowerCase() === "true") return 1;
    return 0;
};

const getNextTransactionId = async (client = db) => {
    const rows = await client.query`
        SELECT COALESCE(MAX(Id), 0) + 1 AS NextId
        FROM E_Get_Transaction
    `;

    const row = Array.isArray(rows) ? rows[0] : rows?.rows?.[0] || rows;
    const nextId = Number(
        row?.NextId ??
        row?.nextId ??
        row?.nextid ??
        row?.NextID ??
        row?.NEXTID
    );

    return Number.isFinite(nextId) && nextId > 0 ? nextId : 1;
};

const getNextPurchaseId = async (client = db) => {
    const rows = await client.query`
        SELECT COALESCE(MAX(ID), 0) + 1 AS NextId
        FROM E_Purchase
    `;

    const row = Array.isArray(rows) ? rows[0] : rows?.rows?.[0] || rows;
    const nextId = Number(
        row?.NextId ??
        row?.nextId ??
        row?.nextid ??
        row?.NextID ??
        row?.NEXTID
    );

    return Number.isFinite(nextId) && nextId > 0 ? nextId : 1;
};

const insertTransactionDetails = async ({
    RootInstance,
    RootTransType,
    details,
    client = db
}) => {
    let insertedTransactions = 0;
    let nextId = await getNextTransactionId(client);

    for (const detail of details) {
        insertedTransactions += await client.execute`
            INSERT INTO E_Get_Transaction (
                    Id,

                RootInstance,
                RootTransType,
                TransactionId,
                TransmissionType,
                Status,
                SenderParticipantId,
                ReceiverPartiId,
                InstanceIdentifier,
                RefInstance,
                ErrorDetails,
                C5DispatchStatus,
                CreatedDate,
                LastModifiedDate,
                HasFile,
                InsertedOn
            )
            VALUES (
                    ${nextId},

                ${normalizeText(RootInstance)},
                ${normalizeText(RootTransType)},
                ${normalizeText(detail?.transactionId)},
                ${normalizeText(detail?.transmissionType)},
                ${normalizeText(detail?.status)},
                ${normalizeText(detail?.senderParticipantId)},
                ${normalizeText(detail?.ReceiverPartiId)},
                ${normalizeText(detail?.instanceIdentifier)},
                ${normalizeText(detail?.RefInstance)},
                ${normalizeText(detail?.errorDetails)},
                ${normalizeText(detail?.c5DispatchStatus)},
                ${normalizeTimestamp(detail?.createdDate)},
                ${normalizeTimestamp(detail?.lastModifiedDate)},
                ${toBit(detail?.hasFile)},
                NOW()
            )
        `;
        nextId += 1;
    }

    return insertedTransactions;
};

const upsertTransactionDetails = async ({
    RootInstance,
    RootTransType,
    details,
    client = db
}) => {
    let insertedTransactions = 0;
    let updatedTransactions = 0;
    let skippedTransactions = 0;

    for (const detail of details) {
        const transactionId = normalizeText(detail?.transactionId);

        if (!transactionId) {
            skippedTransactions += 1;
            continue;
        }

        const updated = await client.execute`
            UPDATE E_Get_Transaction
            SET RootTransType = ${normalizeText(RootTransType)},
                TransmissionType = ${normalizeText(detail?.transmissionType)},
                Status = ${normalizeText(detail?.status)},
                SenderParticipantId = ${normalizeText(detail?.senderParticipantId)},
                ReceiverPartiId = ${normalizeText(detail?.ReceiverPartiId)},
                InstanceIdentifier = ${normalizeText(detail?.instanceIdentifier)},
                RefInstance = ${normalizeText(detail?.RefInstance)},
                ErrorDetails = ${normalizeText(detail?.errorDetails)},
                C5DispatchStatus = ${normalizeText(detail?.c5DispatchStatus)},
                CreatedDate = ${normalizeTimestamp(detail?.createdDate)},
                LastModifiedDate = ${normalizeTimestamp(detail?.lastModifiedDate)},
                HasFile = ${toBit(detail?.hasFile)}
            WHERE RootInstance = ${normalizeText(RootInstance)}
              AND TransactionId = ${transactionId}
        `;

        if (updated > 0) {
            updatedTransactions += 1;
            continue;
        }

        const nextId = await getNextTransactionId(client);

        insertedTransactions += await client.execute`
            INSERT INTO E_Get_Transaction (
                Id,
                RootInstance,
                RootTransType,
                TransactionId,
                TransmissionType,
                Status,
                SenderParticipantId,
                ReceiverPartiId,
                InstanceIdentifier,
                RefInstance,
                ErrorDetails,
                C5DispatchStatus,
                CreatedDate,
                LastModifiedDate,
                HasFile,
                InsertedOn
            )
                
            VALUES (
                ${nextId},
                ${normalizeText(RootInstance)},
                ${normalizeText(RootTransType)},
                ${transactionId},
                ${normalizeText(detail?.transmissionType)},
                ${normalizeText(detail?.status)},
                ${normalizeText(detail?.senderParticipantId)},
                ${normalizeText(detail?.ReceiverPartiId)},
                ${normalizeText(detail?.instanceIdentifier)},
                ${normalizeText(detail?.RefInstance)},
                ${normalizeText(detail?.errorDetails)},
                ${normalizeText(detail?.c5DispatchStatus)},
                ${normalizeTimestamp(detail?.createdDate)},
                ${normalizeTimestamp(detail?.lastModifiedDate)},
                ${toBit(detail?.hasFile)},
                NOW()
            )
        `;
    }

    return {
        insertedTransactions,
        updatedTransactions,
        skippedTransactions
    };
};

const updateQueueTransaction = async ({
    queueId,
    transactionId,
    transCreatedAt,
    transCount,
    client = db
}) =>
    client.execute`
        UPDATE E_PurchaseQueue
        SET TransactionId = ${normalizeText(transactionId)},
            TransCount = ${Number.isFinite(Number(transCount)) ? Number(transCount) : 0},
            IsTrans = 1,
            TransAt = NOW(),
            TransCreatedAt = ${normalizeTimestamp(transCreatedAt)},
            Status = 3,
            ProcessingStatus = ${normalizeText("Transactions Received")},
            UpdatedAt = NOW()
        WHERE QueueId = ${queueId}
    `;

const getFirstValue = (rows, key) =>
    rows.find((row) => row[key] !== undefined && row[key] !== null && row[key] !== "")?.[key] || null;

const hasInDocumentValue = (row) =>
    IN_DOCUMENT_COLUMNS.some((column) => {
        const value = row?.[column];
        return value !== null && value !== undefined && value !== "";
    });

const buildInDocumentData = (rows, purchaseIds) => {
    const sourceRow = rows.find(hasInDocumentValue);
    const purchaseId = purchaseIds[0];

    if (!sourceRow || !purchaseId) return null;

    return {
        EinvoiceID: purchaseId,
        invoice_no: getFirstValue(rows, "invoice_no"),
        ...Object.fromEntries(IN_DOCUMENT_COLUMNS.map((column) => [column, sourceRow[column]]))
    };
};

const insertInDocument = async ({ row, client = db }) => {
    if (!row) return null;

    const rowValues = new Map(
        Object.entries(row).map(([key, value]) => [String(key).toLowerCase(), value])
    );
    const entries = ["EinvoiceID", "invoice_no", ...IN_DOCUMENT_COLUMNS]
        .map(createColumn);

    if (!entries.length) return null;

    const columnSql = entries.map((column) => quoteIdentifier(column.name)).join(", ");
    const valueSql = entries.map((_, index) => `@p${index}`).join(", ");
    const values = entries.map((column) =>
        prepareInDocumentValue(column, rowValues.get(String(column.name).toLowerCase()))
    );
    await client.executeStatement(
        `INSERT INTO ${IN_DOCUMENT_TABLE} (${columnSql})
         VALUES (${valueSql})`,
        values
    );

    return getLastIdentity(client);
};

const updatePurchaseInDocument = async ({ purchaseIds, inDocumentId, client = db }) => {
    if (!inDocumentId || !Array.isArray(purchaseIds) || !purchaseIds.length) return 0;

    const idSql = purchaseIds.map((_, index) => `@p${index + 1}`).join(", ");

    return client.executeStatement(
        `UPDATE ${PURCHASE_TABLE}
         SET inDocument = @p0
         WHERE ID IN (${idSql})`,
        [inDocumentId, ...purchaseIds]
    );
};

const insertPurchaseRows = async ({ rows, client = db }) => {
    if (!Array.isArray(rows) || !rows.length) return 0;

    const insertRows = async (activeClient) => {
        let inserted = 0;
        const purchaseIds = [];
        let nextPurchaseId = await getNextPurchaseId(activeClient);

        for (const row of rows) {
            const purchaseId = nextPurchaseId;
            const entries = [
                ["ID", purchaseId],
                ...Object.entries(row)
                    .filter(([key]) => {
                        const columnName = String(key).toLowerCase();
                        return columnName !== "id" && !IN_DOCUMENT_COLUMN_SET.has(columnName);
                    })
            ]
                .map(([key, value]) => [createColumn(key), value]);

            if (!entries.length) continue;

            const values = [];
            const valueSql = entries.map(([column, value]) => {
                if (isServerTimestampColumn(column)) return "NOW()";

                values.push(preparePurchaseValue(column, value));
                return `@p${values.length - 1}`;
            }).join(", ");
            const columnSql = entries.map(([column]) => quoteIdentifier(column.name)).join(", ");
            await activeClient.executeStatement(
                `INSERT INTO ${quoteIdentifier(PURCHASE_TABLE)} (${columnSql})
                 VALUES (${valueSql})`,
                values
            );

            purchaseIds.push(purchaseId);
            nextPurchaseId += 1;
            inserted += 1;
        }

        const inDocumentData = buildInDocumentData(rows, purchaseIds);

        if (inDocumentData) {
            const inDocumentId = await insertInDocument({
                row: inDocumentData,
                client: activeClient
            });

            if (!inDocumentId) {
                throw new Error("Failed to insert purchase supporting document");
            }

            await updatePurchaseInDocument({
                purchaseIds,
                inDocumentId,
                client: activeClient
            });
        }

        return inserted;
    };

    if (client !== db) {
        return insertRows(client);
    }

    return db.withTransaction(insertRows);
};

const updateQueueInvoiceInserted = async ({
    queueId,
    senderId,
    invoiceNo,
    invoiceType,
    client = db
}) =>
    client.execute`
        UPDATE E_PurchaseQueue
        SET SenderId = ${normalizeText(senderId)},
            InvoiceNo = ${normalizeText(invoiceNo)},
            InvoiceType = ${normalizeText(invoiceType)},
            IsInserted = 1,
            IsInsertedAt = NOW(),
            Status = 4,
            ProcessingStatus = ${normalizeText("Invoice Received")},
            UpdatedAt = NOW()
        WHERE QueueId = ${queueId}
    `;

const updateQueueMailSent = async ({
    queueId,
    toMail,
    client = db
}) =>
    client.execute`
        UPDATE E_PurchaseQueue
        SET IsMail = 1,
            MailId = ${normalizeText(toMail)},
            IsMailAt = NOW(),
            ProcessingStatus = ${normalizeText("Mail sent")},
            Status = 5,
            IsProcessing = 0,
            ProcessEndedAt = NOW(),
            UpdatedAt = NOW()
        WHERE QueueId = ${queueId}
    `;

const updateQueueError = async ({
    queueId,
    error,
    client = db
}) =>
    client.execute`
        UPDATE E_PurchaseQueue
        SET ErrorCode = 1,
            ErrorMessage = ${normalizeTextMax(error?.message || error || "Purchase download failed", 3900)},
            IsProcessing = 0,
            ProcessEndedAt = NOW(),
            UpdatedAt = NOW()
        WHERE QueueId = ${queueId}
    `;

module.exports = {
    getIncompleteTransactionQueueRows,
    getQueuedInstancesByCorrelationId,
    getQueuedInsertedInvoicesByCorrelationId,
    getQueuedTransactionsByCorrelationId,
    getMailConfig,
    getPurchaseRowsByInstanceIdentifier,
    hasActivePurchaseProcess,
    insertEmailLog,
    insertInstanceIdentifiers,
    insertTransactionDetails,
    upsertTransactionDetails,
    insertPurchaseRows,
    updateQueueInvoiceInserted,
    updateQueueError,
    updateQueueMailSent,
    updateQueueTransaction
};
