const db = require("../db");
const dbSecondary = require("../dbSecondary");

const getMasterMetadata = (type) => {
    const displayNameMap = {
        "State Master": "StateMaster",
        "Country Master": "CountryMaster",
        "Payment Master": "PaymentMaster",
        "General Ledger Type Master": "GeneralLedgerTypeMaster",
        "Account Receivable Type Master": "AccountReceivableTypeMaster",
        "Account Payable Type Master": "AccountPayableTypeMaster",
        "Other Invoice Type Master": "OtherInvoiceTypeMaster",
        "Invoice Transaction Master": "InvoiceTransactionMaster",
        "Currency Master": "CurrencyMaster",
        "Unit Master": "UnitMaster",
        "Vat Master": "VatMaster",
        "Credit Note Reason Master": "CreditNoteReasonMaster",
        "Electronic Address Scheme Master": "ElectronicAddressSchemeMaster",
        "Object Identifier Master": "ObjectIdentifierMaster",
        "Rcm Type Master": "RcmTypeMaster",
        "Exempt Reason Master": "ExemptReasonMaster",
        "Charges Master": "ChargesMaster",
        "TDD Scope Master": "TDDScopeMaster"
    };

    return {
        displayName: displayNameMap[type] || type?.replace(/\s+/g, "")
    };
};

const runInTransaction = async (callback) => dbSecondary.withTransaction(callback);

const MASTER_TOGGLE_IDENTIFIER_SETS = [
    {
        tableName: '"EM_Masters"',
        autoIndexColumn: '"AutoIndex"',
        displayNameColumn: '"DisplayName"',
        isActiveColumn: '"IsActive"'
    },
    {
        tableName: "[EM_Masters]",
        autoIndexColumn: "[AutoIndex]",
        displayNameColumn: "[DisplayName]",
        isActiveColumn: "[IsActive]"
    }
];

const readMasterToggleValue = (row, key) => {
    const actualKey = Object.keys(row || {}).find((rowKey) => rowKey.toLowerCase() === key.toLowerCase());
    return actualKey ? row[actualKey] : undefined;
};

const getMasterToggleWithIdentifiers = async (displayName, identifiers) => {
    const { tableName, autoIndexColumn, displayNameColumn, isActiveColumn } = identifiers;
    const rows = await dbSecondary.queryStatement(
        `SELECT ${autoIndexColumn}, ${displayNameColumn}, ${isActiveColumn}
         FROM ${tableName}
         WHERE ${displayNameColumn} = @p0
         ORDER BY ${autoIndexColumn}`,
        [displayName]
    );

    return rows[0] || null;
};

const getMasterToggle = async (value) => {
    const metadata = getMasterMetadata(value);
    let lastError;

    for (const identifiers of MASTER_TOGGLE_IDENTIFIER_SETS) {
        try {
            return await getMasterToggleWithIdentifiers(metadata.displayName, identifiers);
        } catch (error) {
            lastError = error;
        }
    }

    throw lastError;
};

const updateMasterToggleWithIdentifiers = async (metadata, bitValue, identifiers) => {
    const { tableName, autoIndexColumn, displayNameColumn, isActiveColumn } = identifiers;
    const existing = await getMasterToggleWithIdentifiers(metadata.displayName, identifiers);

    if (existing) {
        await dbSecondary.executeStatement(
            `UPDATE ${tableName}
             SET ${displayNameColumn} = @p0,
                 ${isActiveColumn} = @p1
             WHERE ${autoIndexColumn} = @p2`,
            [metadata.displayName, bitValue, readMasterToggleValue(existing, "AutoIndex")]
        );
    } else {
        await dbSecondary.executeStatement(
            `INSERT INTO ${tableName} (${displayNameColumn}, ${isActiveColumn})
             VALUES (@p0, @p1)`,
            [metadata.displayName, bitValue]
        );
    }

    return getMasterToggleWithIdentifiers(metadata.displayName, identifiers);
};

const updateMasterToggle = async (value, isActive) => {
    const metadata = getMasterMetadata(value);
    const bitValue = isActive ? 1 : 0;
    let lastError;

    for (const identifiers of MASTER_TOGGLE_IDENTIFIER_SETS) {
        try {
            return await updateMasterToggleWithIdentifiers(metadata, bitValue, identifiers);
        } catch (error) {
            lastError = error;
        }
    }

    throw lastError;
};

const getAutoSendConfig = async () => {
    const rows = await dbSecondary.query`
        SELECT TOP 1 autosend
        FROM E_config
        ORDER BY id
    `;

    return rows[0] || null;
};

const getSendValidationConfig = async () => {
    const rows = await dbSecondary.query`
        SELECT TOP 1 Ref
        FROM E_config
        ORDER BY id
    `;

    return rows[0] || null;
};

const updateAutoSendConfig = async (autosend) => {
    await dbSecondary.execute`
        UPDATE E_config
        SET autosend = ${autosend}
    `;

    return getAutoSendConfig();
};




const SELLER_SELECT_COLUMNS = `
    OrgID,
    CONAME,
    ADDR01,
    ADDR02,
    ADDR03,
    CITY,
    POSTAL,
    PHONE,
    CONTACT,
    TAXNBR,
    LEGALNAME,
    ElectronicAddress,
    ElectronicSchemeID,
    SellerIdentifier,
    SchemeID,
    LegalRegistrationID,
    LegalSchemeID,
    VATSchemeCode,
    CountrySubdivision,
    CountryCode,
    LegalRegistType,
    TradeLicense,
    EmiratesID,
    PassportNo,
    CabinetDecision,
    AuthorityName,
    PassportIssuCountry,
    ContactEmail
`;

const getSellerDetails = async () => {
    const rows = await dbSecondary.queryUnsafe(`
        SELECT TOP 1
            ${SELLER_SELECT_COLUMNS}
        FROM E_Seller
        ORDER BY OrgID
    `);

    return rows[0] || null;
};

const getSellerDetailsByOrgId = async (orgId) => {
    const rows = await dbSecondary.query`
        SELECT TOP 1
            OrgID,
            CONAME,
            ADDR01,
            ADDR02,
            ADDR03,
            CITY,
            POSTAL,
            PHONE,
            CONTACT,
            TAXNBR,
            LEGALNAME,
            ElectronicAddress,
            ElectronicSchemeID,
            SellerIdentifier,
            SchemeID,
            LegalRegistrationID,
            LegalSchemeID,
            VATSchemeCode,
            CountrySubdivision,
            CountryCode,
            LegalRegistType,
            TradeLicense,
            EmiratesID,
            PassportNo,
            CabinetDecision,
            AuthorityName,
            PassportIssuCountry,
            ContactEmail
        FROM E_Seller
        WHERE OrgID = ${orgId}
    `;

    return rows[0] || null;
};

const getNextSellerOrgId = async () => {
    const rows = await dbSecondary.query`
        SELECT ISNULL(MAX(OrgID), 0) + 1 AS NextOrgID
        FROM E_Seller
    `;

    return rows[0]?.NextOrgID || 1;
};

const saveSellerDetails = async ({
    orgId,
    sellerName,
    tradingName,
    addressLine1,
    addressLine2,
    addressLine3,
    city,
    postCode,
    contactNumber,
    contactPoint,
    contactEmail,
    vatIdentifier,
    electronicAddress,
    electronicSchemeIdentifier,
    sellerIdentifier,
    schemeIdentifier,
    legalRegistrationIdentifier,
    legalSchemeIdentifier,
    vatSchemeCode,
    countrySubdivision,
    countryCode,
    legalRegistrationType,
    commercialTradeLicense,
    emiratesId,
    passport,
    cabinetDecision,
    authorityName,
    passportIssuingCountryCode
}) => {
    let existing = null;

    if (orgId !== undefined && orgId !== null && orgId !== "") {
        existing = await getSellerDetailsByOrgId(orgId);
    }

    if (!existing) {
        existing = await getSellerDetails();
    }

    if (existing) {
        await dbSecondary.execute`
            UPDATE E_Seller
            SET CONAME = ${sellerName},
                ADDR01 = ${addressLine1},
                ADDR02 = ${addressLine2},
                ADDR03 = ${addressLine3},
                CITY = ${city},
                POSTAL = ${postCode},
                PHONE = ${contactNumber},
                CONTACT = ${contactPoint},
                ContactEmail = ${contactEmail},
                TAXNBR = ${vatIdentifier},
                LEGALNAME = ${tradingName},
                ElectronicAddress = ${electronicAddress},
                ElectronicSchemeID = ${electronicSchemeIdentifier},
                SellerIdentifier = ${sellerIdentifier},
                SchemeID = ${schemeIdentifier},
                LegalRegistrationID = ${legalRegistrationIdentifier},
                LegalSchemeID = ${legalSchemeIdentifier},
                VATSchemeCode = ${vatSchemeCode},
                CountrySubdivision = ${countrySubdivision},
                CountryCode = ${countryCode},
                LegalRegistType = ${legalRegistrationType},
                TradeLicense = ${commercialTradeLicense},
                EmiratesID = ${emiratesId},
                PassportNo = ${passport},
                CabinetDecision = ${cabinetDecision},
                AuthorityName = ${authorityName},
                PassportIssuCountry = ${passportIssuingCountryCode}
            WHERE OrgID = ${existing.OrgID}
        `;

        return getSellerDetailsByOrgId(existing.OrgID);
    }

    const nextOrgId = orgId ?? await getNextSellerOrgId();

    await dbSecondary.execute`
        INSERT INTO E_Seller (
            OrgID,
            CONAME,
            ADDR01,
            ADDR02,
            ADDR03,
            CITY,
            POSTAL,
            PHONE,
            CONTACT,
            ContactEmail,
            TAXNBR,
            LEGALNAME,
            ElectronicAddress,
            ElectronicSchemeID,
            SellerIdentifier,
            SchemeID,
            LegalRegistrationID,
            LegalSchemeID,
            VATSchemeCode,
            CountrySubdivision,
            CountryCode,
            LegalRegistType,
            TradeLicense,
            EmiratesID,
            PassportNo,
            CabinetDecision,
            AuthorityName,
            PassportIssuCountry
        )
        VALUES (
            ${nextOrgId},
            ${sellerName},
            ${addressLine1},
            ${addressLine2},
            ${addressLine3},
            ${city},
            ${postCode},
            ${contactNumber},
            ${contactPoint},
            ${contactEmail},
            ${vatIdentifier},
            ${tradingName},
            ${electronicAddress},
            ${electronicSchemeIdentifier},
            ${sellerIdentifier},
            ${schemeIdentifier},
            ${legalRegistrationIdentifier},
            ${legalSchemeIdentifier},
            ${vatSchemeCode},
            ${countrySubdivision},
            ${countryCode},
            ${legalRegistrationType},
            ${commercialTradeLicense},
            ${emiratesId},
            ${passport},
            ${cabinetDecision},
            ${authorityName},
            ${passportIssuingCountryCode}
        )
    `;

    return getSellerDetailsByOrgId(nextOrgId);
};

const sellerMasterTables = {
    countrySubdivisions: "EM_State",
    countryCodes: "EM_CountryCode",
    legalRegistrationTypes: "EM_SellerLegalReg",
    passportIssuingCountryCodes: "EM_CountryCode"
};

const getSellerMasterOptions = async (tableName) =>
    dbSecondary.queryUnsafe(`
        SELECT Value, DisplayName
        FROM ${tableName}
        WHERE Value IS NOT NULL
        ORDER BY DisplayName
    `);

const getSellerDropdownOptions = async () => {
    const entries = await Promise.all(
        Object.entries(sellerMasterTables).map(async ([key, tableName]) => [
            key,
            await getSellerMasterOptions(tableName)
        ])
    );

    const schemeIdentifierOptions = await getSchemeIdentifierOptions();

    return {
        ...Object.fromEntries(entries),
        electronicSchemeIdentifiers: schemeIdentifierOptions,
        schemeIdentifiers: schemeIdentifierOptions,
        legalSchemeIdentifiers: schemeIdentifierOptions
    };
};

const STATIC_SCHEME_IDENTIFIER_OPTIONS = [
    { Value: "0235", DisplayName: "0235 - UAE Tax Identifier (TRN)" },
    { Value: "0088", DisplayName: "0088 - EAN Location Code" },
    { Value: "0060", DisplayName: "0060 - DUNS" },
    { Value: "0199", DisplayName: "0199 - Legal Entity Identifier (LEI)" },
    { Value: "9907", DisplayName: "9907 - UAE Emirates ID" },
    { Value: "9908", DisplayName: "9908 - UAE Passport Number" },
    { Value: "9909", DisplayName: "9909 - UAE Trade License" }
];

const getUserDictLookupOptions = async (fieldDescription) => {
    try {
        const rows = await db.queryUnsafe(`
            SELECT TOP 1 cLookupOptions
            FROM _rtblUserDict
            WHERE cFieldDescription = '${String(fieldDescription).replace(/'/g, "''")}'
        `);

        const options = (rows[0]?.cLookupOptions || "")
            .split(";")
            .map((value) => value.trim())
            .filter(Boolean)
            .map((value) => ({
                Value: value,
                DisplayName: value
            }));

        if (options.length) {
            return options;
        }
    } catch {
        // Sage lookup tables may not be available through Pervasive ODBC.
    }

    return [];
};

const getSchemeIdentifierOptions = async () => {
    const options = await getUserDictLookupOptions("SchemeIdentifier");
    return options.length ? options : STATIC_SCHEME_IDENTIFIER_OPTIONS;
};

const getBuyerDropdownOptions = async () => getSellerDropdownOptions();

const getCountrySubdivisionLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'CountrySubdivision'
    `;

const getEMStates = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [DisplayName], [Mapping], [ModifiedDate]
        FROM [EM_State]
    `;

const updateEMStateMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_State]
                SET [Mapping] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapping] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_State]
                SET [Mapping] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const getUnits = async () => {
    try {
        return await db.query`
            SELECT DISTINCT [UnitSize] AS idUnits, [UnitSize] AS cUnitDescription
            FROM [Inventory]
            WHERE [UnitSize] IS NOT NULL
              AND [UnitSize] <> ''
        `;
    } catch (error) {
        return db.query`
            SELECT DISTINCT "UnitSize" AS idUnits, "UnitSize" AS cUnitDescription
            FROM "Inventory"
            WHERE "UnitSize" IS NOT NULL
              AND "UnitSize" <> ''
        `;
    }
};

const getEMUnits = async () => {
    try {
        return await dbSecondary.query`
            SELECT "AutoIndex", "Mapped", "Value", "DisplayName", "IsActive", "CreatedDate"
            FROM "EM_UnitOfMeasure"
        `;
    } catch (error) {
        return dbSecondary.query`
            SELECT [AutoIndex], [Mapped], [Value], [DisplayName], [IsActive], [CreatedDate]
            FROM [EM_UnitOfMeasure]
        `;
    }
};

const updateEMUnitMapping = async (mappings) => {
    const validMappings = mappings.filter((mapping) =>
        mapping.Mapped !== null && mapping.Mapped !== undefined && String(mapping.Mapped).trim() !== ""
    );

    return runInTransaction(async (tx) => {
        for (const mapping of validMappings) {
            await tx.execute`
                UPDATE "EM_UnitOfMeasure"
                SET "Mapped" = '',
                    "ModifiedDate" = NOW()
                WHERE "Mapped" = ${mapping.Mapped}
            `;
        }

        for (const mapping of validMappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE "EM_UnitOfMeasure"
                SET "Mapped" = ${mapping.Mapped},
                    "ModifiedDate" = NOW()
                WHERE "AutoIndex" = ${mapping.AutoIndex}
            `;
        }

        return true;
    });
};

const getCurrencies = async () =>
    db.query`
        SELECT [CurrencyLink], [Description]
        FROM [Currency]
    `;

const getEMCurrencyCodes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [DisplayName], [ModifiedDate]
        FROM [EM_CurrencyCode_ISO4217]
    `;

const updateEMCurrencyMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_CurrencyCode_ISO4217]
                SET [Mapped] = 0,
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapped}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_CurrencyCode_ISO4217]
                SET [Mapped] = ${mapping.Mapped},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const getCountryCodeLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'CountryCode'
    `;

const getEMCountryCodes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [DisplayName], [IsActive], [ModifiedDate]
        FROM [EM_CountryCode]
    `;

const updateEMCountryMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_CountryCode]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_CountryCode]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const getPaymentTypes = async () =>
    db.query`
        SELECT DISTINCT ulIDSOrdPaymentmode as ExistingMaster
        FROM InvNum
        WHERE ulIDSOrdPaymentmode IS NOT NULL AND ulIDSOrdPaymentmode != ''
    `;

const getEMPaymentTypeCodes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [DisplayName], [IsActive], [ModifiedDate]
        FROM [EM_PaymentTypeCode]
    `;

const updateEMPaymentMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_PaymentTypeCode]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_PaymentTypeCode]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const getInvoiceTypeLookup = async () =>
    db.query`
        SELECT [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'InvoiceType'
    `;

const getSchemeIdentifierLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'SchemeIdentifier'
    `;

const getStandardSchemeLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'StandardScheme'
    `;

const getEMElectronicAddressSchemes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [DisplayName], [ModifiedDate]
        FROM [EM_ElectronicAddressScheme_Ces]
    `;

const getEMObjectIdentifiers = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [Value], [DisplayName], [ModifiedDate]
        FROM [EM_ObjectIdentifier]
    `;

const updateEMElectronicAddressSchemeMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_ElectronicAddressScheme_Ces]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_ElectronicAddressScheme_Ces]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const updateEMObjectIdentifierMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_ObjectIdentifier]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_ObjectIdentifier]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });


const getInvoiceTransactionTypeLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'InvoiceTransactionType'
    `;


const getEMInvoiceTransactionTypeCodes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [DisplayName], [IsActive], [ModifiedDate]
        FROM [EM_InvoiceTransactionType]
    `;

const updateEMInvoiceTransactionMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_InvoiceTransactionType]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_InvoiceTransactionType]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const getCreditNoteReasonLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'CreditNoteReason'
    `;

const getRcmTypeLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'RcmType'
    `;

const getExemptReasonLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'ExemptReason'
    `;

const getChargesReasonLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'ChargesReason'
    `;

const getTddScopeLookup = async () =>
    db.query`
        SELECT TOP 1 [cLookupOptions]
        FROM [_rtblUserDict]
        WHERE [cFieldDescription] = 'TDDScope'
    `;

const getEMCreditNoteReasons = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [Value], [DisplayName], [Modifieddate]
        FROM [EM_CreditNoteReason]
    `;

const getEMChargeCodes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [Value], [DisplayName], [ModifiedDate]
        FROM [EM_ChargeCode]
    `;

const getEMTddScopes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [Value], [DisplayName], [ModifiedDate]
        FROM [EM_TddScope]
    `;

const getEMGoodsServiceTypes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [DisplayName], [ModifiedDate]
        FROM [EM_GoodsServiceType]
    `;

const getEMVATExemptionReasons = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapped], [DisplayName], [ModifiedDate]
        FROM [EM_VATExemptionReason]
    `;

const updateEMCreditNoteReasonMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_CreditNoteReason]
                SET [Mapped] = '',
                    [Modifieddate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_CreditNoteReason]
                SET [Mapped] = ${mapping.Mapping},
                    [Modifieddate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const updateEMChargeCodeMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_ChargeCode]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_ChargeCode]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const updateEMTddScopeMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_TddScope]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_TddScope]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const updateEMGoodsServiceTypeMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_GoodsServiceType]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_GoodsServiceType]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const updateEMVATExemptionReasonMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_VATExemptionReason]
                SET [Mapped] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapped] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_VATExemptionReason]
                SET [Mapped] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const getTrCodes = async () =>
    db.query`
        SELECT [idTrCodes], [Description], [iModule]
        FROM [TrCodes]
    `;

const getEMInvoiceTypeCodes = async () =>
    dbSecondary.query`
        SELECT [AutoIndex], [Mapping], [DisplayName], [IsActive], [ModifiedDate]
        FROM [EM_InvoiceTypeCode]
        where IsActive = 1
    `;

const updateEMInvoiceTypeMapping = async (mappings) =>
    runInTransaction(async (tx) => {
        for (const mapping of mappings) {
            await tx.execute`
                UPDATE [EM_InvoiceTypeCode]
                SET [Mapping] = '',
                    [ModifiedDate] = NOW()
                WHERE [Mapping] = ${mapping.Mapping}
            `;
        }

        for (const mapping of mappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.execute`
                UPDATE [EM_InvoiceTypeCode]
                SET [Mapping] = ${mapping.Mapping},
                    [ModifiedDate] = NOW()
                WHERE [AutoIndex] = ${mapping.AutoIndex}
            `;
        }

        return true;
    });

const getVat = async () => {
    const queries = [
        `
            SELECT *
            FROM TaxDescription
        `,
        `
            SELECT *
            FROM "TaxDescription"
        `,
        `
            SELECT *
            FROM [TaxDescription]
        `
    ];
    let emptyRows = [];
    let hasSuccessfulQuery = false;
    let lastError;

    for (const query of queries) {
        try {
            const rows = await db.queryUnsafe(query);
            hasSuccessfulQuery = true;
            if (rows.length) return rows;
            emptyRows = rows;
        } catch (error) {
            lastError = error;
        }
    }

    if (!hasSuccessfulQuery && lastError) throw lastError;
    return emptyRows;
};

const getEMVat = async () => {
    try {
        return await dbSecondary.query`
            SELECT *
            FROM "EM_VATCategory"
        `;
    } catch (error) {
        return dbSecondary.query`
            SELECT *
            FROM [EM_VATCategory]
        `;
    }
};

const updateEMVatMappingWithIdentifiers = (validMappings, tableName, autoIndexColumn, mappedColumn) =>
    runInTransaction(async (tx) => {
        for (const mapping of validMappings) {
            await tx.executeStatement(
                `UPDATE ${tableName}
                 SET ${mappedColumn} = 0
                 WHERE ${mappedColumn} = @p0`,
                [mapping.Mapped]
            );
        }

        for (const mapping of validMappings.filter((item) => item.AutoIndex !== 0)) {
            await tx.executeStatement(
                `UPDATE ${tableName}
                 SET ${mappedColumn} = @p0
                 WHERE ${autoIndexColumn} = @p1`,
                [mapping.Mapped, mapping.AutoIndex]
            );
        }

        return true;
    });

const updateEMVatMapping = async (mappings) => {
    const validMappings = mappings.filter((mapping) =>
        Number.isInteger(mapping.Mapped)
    );

    try {
        return await updateEMVatMappingWithIdentifiers(
            validMappings,
            '"EM_VATCategory"',
            '"AutoIndex"',
            '"Mapped"'
        );
    } catch (error) {
        return updateEMVatMappingWithIdentifiers(
            validMappings,
            "[EM_VATCategory]",
            "[AutoIndex]",
            "[Mapped]"
        );
    }
};

const partyFieldColumnCandidates = {
    idCust: ["idCust", "DCLink", "CustomerId", "BuyerId", "id", "AutoIndex", "IDCUST"],
    account: ["Account", "Account"],
    buyerName: ["buyerName", "BuyerName", "Name", "Name", "Name", "buyer_name", "TEXTSNAM"],
    sellerName: ["sellerName", "SellerName", "Name", "seller_name"],
    tradingName: ["tradingName", "TradingName", "NAMECUST"],
    name: ["Name", "DisplayName", "BuyerName", "SellerName", "Name", "buyer_name", "seller_name", "TEXTSNAM"],
    addressLine1: ["AddressLine1", "AddrLine1", "Address1", "Physical1", "Physical1", "BuyerAddressline1", "SellerAddressline1", "buyer_addr_line1", "seller_addr_line1", "TEXTSTRE1"],
    addressLine2: ["AddressLine2", "AddrLine2", "Address2", "Physical2", "Physical2", "buyer_addr_line2", "seller_addr_line2", "TEXTSTRE2"],
    addressLine3: ["AddressLine3", "AddrLine3", "Address3", "Physical3", "Physical3", "buyer_addr_line3", "seller_addr_line3", "TEXTSTRE3"],
    city: ["City", "BuyerCity", "SellerCity", "Physical4", "Physical4", "Physical4", "buyer_city", "seller_city", "NAMECITY"],
    postCode: ["PostCode", "PostalCode", "ZipCode", "PhysicalPC", "PhysicalPC", "CODEPSTL"],
    countrySubdivision: ["CountrySubdivision", "State", "ulARCountrySubdivision", "BuyerCountrySubdivision", "SellerCountrySubdivision", "buyer_country_sub", "seller_country_sub"],
    countryCode: ["CountryCode", "ulARCountryCode", "BuyerCountry", "SellerCountryCode", "buyer_country_code", "seller_country_code"],
    vatIdentifier: ["vatIdentifier", "VatIdentifier", "VatId", "VATId", "VatNumber", "TaxIdentifier", "ucARVATIdentifier", "buyer_vat_id", "seller_vat_id", "VATIdentifier"],
    vatId: ["VatId", "VATId", "VatNumber", "TaxIdentifier", "buyer_vat_id", "seller_vat_id", "VATIdentifier"],
    buyerIdentifier: ["buyerIdentifier", "BuyerIdentifier", "BuyerId", "ucARBuyerIdentifier"],
    schemeIdentifier: ["schemeIdentifier", "SchemeIdentifier", "SchemeID"],
    electronicSchemeIdentifier: ["electronicSchemeIdentifier", "ElectronicSchemeIdentifier", "EndpointSchemeId", "ElectronicAddressID"],
    registrationId: ["RegistrationId", "LegalRegistrationId", "LegalRegId", "buyer_legal_reg_id", "seller_legal_reg_id", "LegalRegistrationID"],
    legalRegistrationIdentifier: ["legalRegistrationIdentifier", "LegalRegistrationIdentifier", "LegalRegistrationId", "LegalRegId", "ucARLegalRegistrationID", "buyer_legal_reg_id", "seller_legal_reg_id", "LegalRegistrationID"],
    legalSchemeIdentifier: ["legalSchemeIdentifier", "LegalSchemeIdentifier", "ulARSchemeIdentifier", "LegalSchemeID"],
    legalRegistrationType: ["legalRegistrationType", "LegalRegistrationType", "ucARLegalRegistrationType"],
    electronicAddress: ["ElectronicAddress", "EndpointId", "ucARElectronicAddress", "buyer_endpoint_id", "seller_endpoint_id"],
    phone: ["Phone", "Telephone", "Mobile", "Telephone", "TEXTPHON1"],
    email: ["Email", "EmailAddress", "EMail", "EMAIL1"],
    contactPoint: ["contactPoint", "ContactPoint", "Contact_Person", "Contact_Person", "NAMECTAC"],
    contactNumber: ["contactNumber", "ContactNumber", "Telephone", "Telephone", "Phone", "Telephone", "TEXTPHON1"],
    contactEmail: ["contactEmail", "ContactEmail", "EMail", "Email", "EMAIL1"],
    commercialTradeLicense: ["commercialTradeLicense", "CommercialTradeLicense", "ucARTradeLicense", "TradeLicense"],
    authorityName: ["authorityName", "AuthorityName", "ucARAuthorityName"],
    emiratesId: ["emiratesId", "EmiratesId", "ucAREmiratesID"],
    passport: ["passport", "Passport", "ucARPassportNo", "PassportNo"],
    passportIssuingCountryCode: ["passportIssuingCountryCode", "PassportIssuingCountryCode", "ulARPassportIssuingCountry", "PassportIssuingCountry"],
    cabinetDecision: ["cabinetDecision", "CabinetDecision", "ucARCabinetDecision"]
};

const tableColumnCache = new Map();

const usesArtaxTable = (tableName) => /^(?:EM_|E_|e_)/.test(String(tableName || ""));
const getDbForTable = (tableName) => usesArtaxTable(tableName) ? dbSecondary : db;

const getTableColumns = async (tableName) => {
    const physicalTableName = String(tableName || "").split(".").pop().replace(/^\[|\]$/g, "");

    if (tableColumnCache.has(physicalTableName)) {
        return tableColumnCache.get(physicalTableName);
    }

    const columns = await getDbForTable(physicalTableName).query`
        SELECT [COLUMN_NAME]
        FROM [INFORMATION_SCHEMA].[COLUMNS]
        WHERE [TABLE_NAME] = ${physicalTableName}
        ORDER BY [ORDINAL_POSITION]
    `;
    const columnNames = columns.map((column) => column.COLUMN_NAME);
    tableColumnCache.set(physicalTableName, columnNames);
    return columnNames;
};

const resolveColumnName = (availableColumns, fieldName) => {
    const candidates = [fieldName, ...(partyFieldColumnCandidates[fieldName] || [])];
    return candidates.find((candidate) =>
        availableColumns.some((column) => column.toLowerCase() === candidate.toLowerCase())
    );
};

const quoteIdentifier = (identifier) => `[${String(identifier).replace(/]/g, "]]")}]`;

const getResolvedColumn = async (tableName, fieldName) => {
    const availableColumns = await getTableColumns(tableName);
    return resolveColumnName(availableColumns, fieldName);
};

const readColumnValue = (row, fieldName) => {
    const candidates = [fieldName, ...(partyFieldColumnCandidates[fieldName] || [])];
    const key = candidates.find((candidate) =>
        Object.keys(row || {}).some((column) => column.toLowerCase() === candidate.toLowerCase())
    );
    if (!key) return "";
    const actualKey = Object.keys(row).find((column) => column.toLowerCase() === key.toLowerCase());
    const value = row[actualKey] ?? "";
    return typeof value === "string" ? value.trim() : value;
};

const normalizeBuyerRow = (row) => {
    const id = readColumnValue(row, "idCust") || readColumnValue(row, "name");
    return {
        id,
        idCust: id,
        account: readColumnValue(row, "account"),
        Name: readColumnValue(row, "buyerName") || readColumnValue(row, "name"),
        Physical1: readColumnValue(row, "addressLine1"),
        Physical2: readColumnValue(row, "addressLine2"),
        Physical3: readColumnValue(row, "addressLine3"),
        Physical4: readColumnValue(row, "city"),
        Contact_Person: readColumnValue(row, "contactPoint"),
        Telephone: readColumnValue(row, "contactNumber"),
        buyerName: readColumnValue(row, "buyerName") || readColumnValue(row, "name"),
        tradingName: readColumnValue(row, "tradingName") || readColumnValue(row, "buyerName") || readColumnValue(row, "name"),
        addressLine1: readColumnValue(row, "addressLine1"),
        addressLine2: readColumnValue(row, "addressLine2"),
        addressLine3: readColumnValue(row, "addressLine3"),
        city: readColumnValue(row, "city"),
        postCode: readColumnValue(row, "postCode"),
        countrySubdivision: readColumnValue(row, "countrySubdivision"),
        countryCode: readColumnValue(row, "countryCode"),
        electronicAddress: readColumnValue(row, "electronicAddress"),
        electronicSchemeIdentifier: readColumnValue(row, "electronicSchemeIdentifier"),
        buyerIdentifier: readColumnValue(row, "buyerIdentifier"),
        schemeIdentifier: readColumnValue(row, "schemeIdentifier"),
        legalRegistrationIdentifier: readColumnValue(row, "legalRegistrationIdentifier"),
        legalSchemeIdentifier: readColumnValue(row, "legalSchemeIdentifier"),
        legalRegistrationType: readColumnValue(row, "legalRegistrationType"),
        vatIdentifier: readColumnValue(row, "vatIdentifier"),
        commercialTradeLicense: readColumnValue(row, "commercialTradeLicense"),
        authorityName: readColumnValue(row, "authorityName"),
        emiratesId: readColumnValue(row, "emiratesId"),
        passport: readColumnValue(row, "passport"),
        passportIssuingCountryCode: readColumnValue(row, "passportIssuingCountryCode"),
        cabinetDecision: readColumnValue(row, "cabinetDecision"),
        contactPoint: readColumnValue(row, "contactPoint"),
        contactNumber: readColumnValue(row, "contactNumber"),
        contactEmail: readColumnValue(row, "contactEmail")
    };
};

const getConfigureBuyers = async () => {
    const rows = await db.queryUnsafe(`
        SELECT TOP 500
            CM.CustomerCode AS IDCUST,
            CM.CustomerDesc AS TEXTSNAM,
            CM.PostAddress01 AS TEXTSTRE1,
            CM.PostAddress02 AS TEXTSTRE2,
            CM.PostAddress03 AS TEXTSTRE3,
            CM.PostAddress04 AS NAMECITY,
            CM.PostAddress05 AS CODEPSTL,
            DA.Contact AS NAMECTAC,
            DA.Telephone AS TEXTPHON1,
            DA.Email AS EMAIL1
        FROM CustomerMaster CM
        LEFT JOIN DeliveryAddresses DA ON DA.CustomerCode = CM.CustomerCode
        ORDER BY CM.CustomerDesc
    `);

    const buyerRows = await dbSecondary.queryUnsafe(`
        SELECT IDCUST FROM E_Buyer
    `);

    const buyersMap = new Map();
    for (const b of buyerRows) {
        buyersMap.set(String(b.IDCUST), b);
    }

    return rows.map((row) => {
        const b = buyersMap.get(String(row.IDCUST)) || {};
        return normalizeBuyerRow({
            ...row,
            ...b
        });
    });
};

const getConfigureBuyerById = async (idCust) => {
    const rows = await db.queryStatement(
        `SELECT TOP 1
            CM.CustomerCode AS IDCUST,
            CM.CustomerDesc AS TEXTSNAM,
            CM.PostAddress01 AS TEXTSTRE1,
            CM.PostAddress02 AS TEXTSTRE2,
            CM.PostAddress03 AS TEXTSTRE3,
            CM.PostAddress04 AS NAMECITY,
            CM.PostAddress05 AS CODEPSTL,
            DA.Contact AS NAMECTAC,
            DA.Telephone AS TEXTPHON1,
            DA.Email AS EMAIL1
        FROM CustomerMaster CM
        LEFT JOIN DeliveryAddresses DA ON DA.CustomerCode = CM.CustomerCode
        WHERE CM.CustomerCode = @p0`,
        [idCust]
    );

    if (!rows || rows.length === 0) return null;

    const buyerRow = rows[0];

    const eBuyers = await dbSecondary.queryStatement(
        `SELECT TOP 1
            ID,
            IDCUST,
            ElectronicAddress,
            ElectronicAddressID,
            BuyerIdentifier,
            SchemeID,
            LegalRegistrationID,
            LegalSchemeID,
            VATIdentifier,
            CountrySubdivision,
            CountryCode,
            LegalRegisType as LegalRegistrationType,
            TradeLicense,
            EmiratesID,
            PassportNo,
            CabinetDecision,
            AuthorityName,
            PassportIssuCountry as PassportIssuingCountry
        FROM E_Buyer
        WHERE IDCUST = @p0`,
        [idCust]
    );

    const eBuyer = eBuyers && eBuyers.length > 0 ? eBuyers[0] : {};

    return normalizeBuyerRow({
        ...buyerRow,
        ...eBuyer
    });
};

const updateConfigureBuyer = async (payload) => {
    if (!payload?.idCust) {
        throw new Error("Buyer customer id is required");
    }

    const existing = await dbSecondary.queryStatement(
        `SELECT TOP 1 IDCUST FROM E_Buyer WHERE IDCUST = @p0`,
        [payload.idCust]
    );

    if (existing && existing.length > 0) {
        await dbSecondary.execute`
            UPDATE E_Buyer
            SET ElectronicAddress = ${payload.electronicAddress},
                ElectronicAddressID = ${payload.electronicSchemeIdentifier},
                BuyerIdentifier = ${payload.buyerIdentifier},
                SchemeID = ${payload.schemeIdentifier},
                LegalRegistrationID = ${payload.legalRegistrationIdentifier},
                LegalSchemeID = ${payload.legalSchemeIdentifier},
                VATIdentifier = ${payload.vatIdentifier},
                CountrySubdivision = ${payload.countrySubdivision},
                CountryCode = ${payload.countryCode},
                LegalRegisType = ${payload.legalRegistrationType},
                TradeLicense = ${payload.commercialTradeLicense},
                EmiratesID = ${payload.emiratesId},
                PassportNo = ${payload.passport},
                CabinetDecision = ${payload.cabinetDecision},
                AuthorityName = ${payload.authorityName},
                PassportIssuCountry = ${payload.passportIssuingCountryCode}
            WHERE IDCUST = ${payload.idCust}
        `;
    } else {
        await dbSecondary.execute`
            INSERT INTO E_Buyer (
                ID,
                IDCUST,
                ElectronicAddress,
                ElectronicAddressID,
                BuyerIdentifier,
                SchemeID,
                LegalRegistrationID,
                LegalSchemeID,
                VATIdentifier,
                CountrySubdivision,
                CountryCode,
                LegalRegisType,
                TradeLicense,
                EmiratesID,
                PassportNo,
                CabinetDecision,
                AuthorityName,
                PassportIssuCountry
            )
            VALUES (
                ${payload.idCust},
                ${payload.idCust},
                ${payload.electronicAddress},
                ${payload.electronicSchemeIdentifier},
                ${payload.buyerIdentifier},
                ${payload.schemeIdentifier},
                ${payload.legalRegistrationIdentifier},
                ${payload.legalSchemeIdentifier},
                ${payload.vatIdentifier},
                ${payload.countrySubdivision},
                ${payload.countryCode},
                ${payload.legalRegistrationType},
                ${payload.commercialTradeLicense},
                ${payload.emiratesId},
                ${payload.passport},
                ${payload.cabinetDecision},
                ${payload.authorityName},
                ${payload.passportIssuingCountryCode}
            )
        `;
    }

    return getConfigureBuyerById(payload.idCust);
};

const insertConfigureParty = async (tableName, payload) => {
    const allowedTables = new Set(["E_Buyer", "E_Seller"]);
    if (!allowedTables.has(tableName)) {
        throw new Error("Invalid configure party table");
    }

    const availableColumns = await getTableColumns(tableName);
    const valuesByColumn = {};

    for (const [fieldName, value] of Object.entries(payload || {})) {
        const columnName = resolveColumnName(availableColumns, fieldName);
        if (columnName && value !== undefined) {
            valuesByColumn[columnName] = value === "" ? null : value;
        }
    }

    const createdDateColumn = availableColumns.find((column) =>
        ["CreatedDate", "CreatedAt", "createdAt"].some((candidate) => candidate.toLowerCase() === column.toLowerCase())
    );

    if (createdDateColumn && !Object.prototype.hasOwnProperty.call(valuesByColumn, createdDateColumn)) {
        valuesByColumn[createdDateColumn] = new Date();
    }

    const insertColumns = Object.keys(valuesByColumn);
    if (insertColumns.length === 0) {
        throw new Error(`No matching columns found for ${tableName}`);
    }

    const columnSql = insertColumns.map(quoteIdentifier).join(", ");
    const valueSql = insertColumns.map((_, index) => `@p${index}`).join(", ");
    const values = insertColumns.map((column) => valuesByColumn[column]);

    await getDbForTable(tableName).executeStatement(
        `INSERT INTO ${quoteIdentifier(tableName)} (${columnSql}) VALUES (${valueSql})`,
        values
    );

    return valuesByColumn;
};

module.exports = {
    getMasterToggle,
    updateMasterToggle,
    getAutoSendConfig,
    getSendValidationConfig,
    updateAutoSendConfig,

    getSellerDetails,
    getSellerDetailsByOrgId,
    getSellerDropdownOptions,
    getBuyerDropdownOptions,
    saveSellerDetails,
    getCountrySubdivisionLookup,
    getEMStates,
    updateEMStateMapping,
    getVat,
    getEMVat,
    updateEMVatMapping,
    getUnits,
    getEMUnits,
    updateEMUnitMapping,
    getCurrencies,
    getEMCurrencyCodes,
    updateEMCurrencyMapping,
    getCountryCodeLookup,
    getEMCountryCodes,
    updateEMCountryMapping,
    getPaymentTypes,
    getEMPaymentTypeCodes,
    updateEMPaymentMapping,
    getInvoiceTypeLookup,
    getSchemeIdentifierLookup,
    getStandardSchemeLookup,
    getEMElectronicAddressSchemes,
    updateEMElectronicAddressSchemeMapping,
    getEMObjectIdentifiers,
    updateEMObjectIdentifierMapping,
    getInvoiceTransactionTypeLookup,
    getEMInvoiceTransactionTypeCodes,
    updateEMInvoiceTransactionMapping,
    getCreditNoteReasonLookup,
    getEMCreditNoteReasons,
    updateEMCreditNoteReasonMapping,
    getChargesReasonLookup,
    getEMChargeCodes,
    updateEMChargeCodeMapping,
    getTddScopeLookup,
    getEMTddScopes,
    updateEMTddScopeMapping,
    getRcmTypeLookup,
    getEMGoodsServiceTypes,
    updateEMGoodsServiceTypeMapping,
    getExemptReasonLookup,
    getEMVATExemptionReasons,
    updateEMVATExemptionReasonMapping,
    getTrCodes,
    getEMInvoiceTypeCodes,
    updateEMInvoiceTypeMapping,
    insertConfigureParty,
    getConfigureBuyers,
    getConfigureBuyerById,
    updateConfigureBuyer
};
