const db = require("../dbSecondary");

let responseLogTableReady = false;
const responseLogTableName = "e_invoice_resp_log";

const normalizeText = (value) => {
    if (value === null || value === undefined || value === "") {
        return null;
    }

    return String(value);
};

const readRowValue = (row, ...keys) => {
    if (!row || typeof row !== "object") return null;

    for (const key of keys) {
        if (Object.prototype.hasOwnProperty.call(row, key)) {
            return row[key];
        }

        const actualKey = Object.keys(row).find(
            (rowKey) => rowKey.toLowerCase() === String(key).toLowerCase()
        );

        if (actualKey) return row[actualKey];
    }

    return null;
};

const formatReceiverId = (schemeId, electronicAddress) => {
    const scheme = String(schemeId || "").trim();
    const address = String(electronicAddress || "").trim();

    if (!scheme && !address) return null;
    if (!scheme) return address;
    if (!address) return scheme;

    return `${scheme}:${address}`;
};

const escapeSqlString = (value) => String(value).replace(/'/g, "''");

const ensureResponseLogTable = async () => {
    if (responseLogTableReady) return;

    // This table is managed in Pervasive. Avoid SQL Server-only DDL here.
    responseLogTableReady = true;
};

const getNextResponseLogId = async () => {
    const rows = await db.queryUnsafe(`
        SELECT MAX("Id") AS MaxId
        FROM "${responseLogTableName}"
    `);
    const maxId = Number(rows[0]?.MaxId);
    return Number.isFinite(maxId) ? maxId + 1 : 1;
};

const findByInstanceIdentifier = async (instanceIdentifier) => {
    if (!instanceIdentifier) return null;

    const rows = await db.query`
        SELECT TOP 1 "Id"
        FROM "e_invoice_resp_log"
        WHERE "instanceIdentifier" = ${normalizeText(instanceIdentifier)}
    `;
    return rows[0] || null;
};

const saveResponseLog = async ({
    responseId,
    messageId,
    instanceIdentifier,
    invNumber,
    senderParticipantID,
    receiverPartiId,
    ReceiverPartiId,
    documentTypeID,
    processID,
    transmissionType,
    status,
    serviceProviderId,
    responseCreatedDate,
    responseMessage,
    errorDetails,
    createdBy
}) => {
    await ensureResponseLogTable();
    const existing = await findByInstanceIdentifier(instanceIdentifier);

    // instanceIdentifier is a unique key; update first, then insert as fallback
    if (existing) {
        await db.execute`
        UPDATE "e_invoice_resp_log"
        SET
            "response_id" = ${responseId || null},
            "messageId" = ${normalizeText(messageId)},
            "InvNumber" = COALESCE(${normalizeText(invNumber)}, "InvNumber"),
            "senderParticipantID" = COALESCE(${normalizeText(senderParticipantID)}, "senderParticipantID"),
            "ReceiverPartiId" = COALESCE(${normalizeText(receiverPartiId ?? ReceiverPartiId)}, "ReceiverPartiId"),
            "documentTypeID" = ${normalizeText(documentTypeID)},
            "processID" = ${normalizeText(processID)},
            "transmissionType" = ${normalizeText(transmissionType)},
            "status" = ${normalizeText(status)},
            "serviceProviderId" = ${serviceProviderId || null},
            "responseCreatedDate" = ${responseCreatedDate || null},
            "responseMessage" = ${normalizeText(responseMessage)},
            "errorDetails" = ${normalizeText(errorDetails)},
            "createdby" = ${normalizeText(createdBy)}
        WHERE "Id" = ${existing.Id}
    `;
        return;
    }

    const nextId = await getNextResponseLogId();
    await db.execute`
        INSERT INTO "e_invoice_resp_log" (
            "Id",
            "response_id",
            "messageId",
            "instanceIdentifier",
            "InvNumber",
            "senderParticipantID",
            "ReceiverPartiId",
            "documentTypeID",
            "processID",
            "transmissionType",
            "status",
            "serviceProviderId",
            "responseCreatedDate",
            "responseMessage",
            "errorDetails",
            "createdby",
            "createdAt"
        )
        VALUES (
            ${nextId},
            ${responseId || null},
            ${normalizeText(messageId)},
            ${normalizeText(instanceIdentifier)},
            ${normalizeText(invNumber)},
            ${normalizeText(senderParticipantID)},
            ${normalizeText(receiverPartiId ?? ReceiverPartiId)},
            ${normalizeText(documentTypeID)},
            ${normalizeText(processID)},
            ${normalizeText(transmissionType)},
            ${normalizeText(status)},
            ${serviceProviderId || null},
            ${responseCreatedDate || null},
            ${normalizeText(responseMessage)},
            ${normalizeText(errorDetails)},
            ${normalizeText(createdBy)},
            NOW()
        )
    `;
};

const upsertSendLogByInstanceIdentifier = async ({
    messageId,
    instanceIdentifier,
    invNumber,
    senderParticipantID,
    receiverPartiId,
    ReceiverPartiId,
    createdBy
}) => {
    await ensureResponseLogTable();
    const existing = await findByInstanceIdentifier(instanceIdentifier);

    if (existing) {
        await db.execute`
        UPDATE "e_invoice_resp_log"
        SET
            "messageId" = ${normalizeText(messageId)},
            "createdby" = ${normalizeText(createdBy)},
            "InvNumber" = COALESCE(${normalizeText(invNumber)}, "InvNumber"),
            "senderParticipantID" = COALESCE(${normalizeText(senderParticipantID)}, "senderParticipantID"),
            "ReceiverPartiId" = COALESCE(${normalizeText(receiverPartiId ?? ReceiverPartiId)}, "ReceiverPartiId"),
            "createdAt" = NOW()
        WHERE "Id" = ${existing.Id}
    `;
        return;
    }

    const nextId = await getNextResponseLogId();
    await db.execute`
        INSERT INTO "e_invoice_resp_log" (
            "Id",
            "messageId",
            "instanceIdentifier",
            "InvNumber",
            "senderParticipantID",
            "ReceiverPartiId",
            "createdby",
            "createdAt"
        )
        VALUES (
            ${nextId},
            ${normalizeText(messageId)},
            ${normalizeText(instanceIdentifier)},
            ${normalizeText(invNumber)},
            ${normalizeText(senderParticipantID)},
            ${normalizeText(receiverPartiId ?? ReceiverPartiId)},
            ${normalizeText(createdBy)},
            NOW()
        )
    `;
};

const getValidationErrorNotificationDetails = async ({
    instanceIdentifier,
    invNumber
}) => {
    await ensureResponseLogTable();

    let responseRows = [];

    if (instanceIdentifier) {
        responseRows = await db.queryUnsafe(`
            SELECT TOP 1
                Id,
                instanceIdentifier,
                InvNumber,
                CreatedAt,
                status,
                responseMessage,
                errorDetails
            FROM ${responseLogTableName}
            WHERE instanceIdentifier = '${escapeSqlString(normalizeText(instanceIdentifier))}'
            ORDER BY Id DESC
        `);
    }

    if (!responseRows.length && invNumber) {
        responseRows = await db.queryUnsafe(`
            SELECT TOP 1
                Id,
                instanceIdentifier,
                InvNumber,
                CreatedAt,
                status,
                responseMessage,
                errorDetails
            FROM ${responseLogTableName}
            WHERE InvNumber = '${escapeSqlString(normalizeText(invNumber))}'
            ORDER BY Id DESC
        `);
    }

    const responseRow = responseRows[0] || {};
    const invoiceNumber = readRowValue(responseRow, "InvNumber") || invNumber;
    if (!invoiceNumber) return null;

    const invoiceRows = await db.queryUnsafe(`
            SELECT TOP 1
                seller_elec_sche_id AS SellElectrSchemeId,
                seller_elec_address AS SellElectAddress,
                buyer_trade_name AS Customer,
                inv_total_with_tax AS InvoiceAmt,
                invoice_issue_date AS InvDate
            FROM E_Invoicing
            WHERE invoice_no = '${escapeSqlString(normalizeText(invoiceNumber))}'
            ORDER BY ID ASC
        `);

    const row = {
        ...responseRow,
        ...(invoiceRows[0] || {})
    };
    if (!row) return null;

    return {
        ReceiverId: formatReceiverId(
            readRowValue(row, "SellElectrSchemeId"),
            readRowValue(row, "SellElectAddress")
        ),
        InstanceIdentifier: readRowValue(row, "instanceIdentifier", "InstanceIdentifier") || instanceIdentifier,
        InvNumber: readRowValue(row, "InvNumber"),
        ErrorAt: readRowValue(row, "CreatedAt", "createdAt", "ErrorAt"),
        Customer: readRowValue(row, "Customer"),
        Status: readRowValue(row, "status", "Status"),
        Error: readRowValue(row, "errorDetails", "Error") || readRowValue(row, "responseMessage"),
        InvoiceAmt: readRowValue(row, "InvoiceAmt"),
        InvDate: readRowValue(row, "InvDate")
    };
};

module.exports = {
    saveResponseLog,
    upsertSendLogByInstanceIdentifier,
    getValidationErrorNotificationDetails
};
