require("dotenv").config();

const db = require("../db");
const dbSecondary = require("../dbSecondary");

const main = async () => {
    await db.connect();
    await dbSecondary.connect();
    const primaryRows = await db.queryUnsafe("SELECT 1 AS ok");
    const secondaryRows = await dbSecondary.queryUnsafe("SELECT 1 AS ok");
    console.log({
        primary: primaryRows,
        secondary: secondaryRows
    });
    await db.close();
    await dbSecondary.close();
};

main().catch((error) => {
    console.error(error);
    process.exit(1);
});
