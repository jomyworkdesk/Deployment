const express = require("express");
const router = express.Router();
const entryPageController = require("../controllers/entryPageController");

router.get("/metadata", entryPageController.getMetadata);
router.get("/columns", entryPageController.getColumns);
router.get("/transaction-types", entryPageController.getTransactionTypes);
router.get("/invoice-types", entryPageController.getInvoiceTypes);
router.get("/payment-types", entryPageController.getPaymentTypes);
router.get("/credit-note-reasons", entryPageController.getCreditNoteReasons);
router.get("/entries", entryPageController.getEntries);
router.put("/additional-fields", entryPageController.updateAdditionalFields);

module.exports = router;
