@echo off
if exist "C:\node32\node.exe" (
  if exist "C:\node32\node_modules\npm\bin\npm-cli.js" (
    set "PATH=C:\node32;%PATH%"
    "C:\node32\node.exe" "C:\node32\node_modules\npm\bin\npm-cli.js" %*
    exit /b %ERRORLEVEL%
  )
)

npm %*
