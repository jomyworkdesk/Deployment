const appConfig = {
    port: Number(process.env.PORT),
    host: process.env.HOST,
    jwtSecret: process.env.JWT_SECRET,
    nodeEnv: process.env.NODE_ENV,
    portalUrl: process.env.PORTAL_URL,
    secondaryDbName: process.env.SECONDARY_DB_NAME,
    invoiceSyncCron: process.env.INVOICE_SYNC_CRON,
    historyHeaderQueueCron: process.env.HISTORY_HEADER_QUEUE_CRON,
    mail: {
        host: process.env.MAIL_HOST,
        port: Number(process.env.MAIL_PORT),
        secure: String(process.env.MAIL_SECURE).toLowerCase() === "true",
        user: process.env.MAIL_USER,
        pass: process.env.MAIL_PASS,
        from: process.env.MAIL_FROM,
        fromName: process.env.MAIL_FROM_NAME,
        applicationUrl: process.env.MAIL_APPLICATION_URL,
        supportEmail: process.env.MAIL_SUPPORT_EMAIL
    }
};

module.exports = appConfig;
