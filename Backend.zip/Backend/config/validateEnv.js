require("dotenv").config();

const validateEnvironment = () => {
    const requiredEnvVars = [
        "JWT_SECRET",
        "PORT",
        "HOST",
        "SECONDARY_DB_DSN",
        "SECONDARY_DB_NAME"
    ];
    const missingVars = requiredEnvVars.filter(
        (envVar) => !process.env[envVar]
    );

    if (missingVars.length > 0) {
        throw new Error(
            `Missing required environment variables: ${missingVars.join(", ")}. ` +
                "Please check your .env file or create one based on .env.example"
        );
    }

    const hasPrimaryDsn = Boolean(process.env.PRIMARY_DB_DSN);
    const hasPrimaryName = Boolean(process.env.PRIMARY_DB_NAME);

    if (hasPrimaryDsn !== hasPrimaryName) {
        throw new Error(
            "PRIMARY_DB_DSN and PRIMARY_DB_NAME must be configured together, " +
                "or both omitted to reuse the secondary database configuration."
        );
    }

    const port = Number(process.env.PORT);
    if (Number.isNaN(port) || port < 1 || port > 65535) {
        throw new Error(
            `PORT must be a valid number between 1 and 65535. Got: ${process.env.PORT}`
        );
    }

    if (process.env.JWT_SECRET === "art_gateway_secret_key") {
        console.warn(
            "WARNING: Using default JWT_SECRET. Please set a secure JWT_SECRET in production."
        );
    }

    console.log("Environment validation passed");
};

module.exports = validateEnvironment;
