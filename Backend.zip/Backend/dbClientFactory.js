const odbc = require("odbc");

const assertDriverArchitecture = () => {
    // Windows keeps 32- and 64-bit ODBC DSNs/drivers in separate registries.
    if (process.env.PERVASIVE_ODBC_ARCH === "32" && process.arch !== "ia32") {
        throw new Error(
            "PERVASIVE_ODBC_ARCH=32 requires 32-bit Node. Start the backend with node32.cmd (or npm32.cmd start)."
        );
    }
};

const escapeValue = (value) => {
    if (value === null || value === undefined) return "NULL";
    if (value instanceof Date) return `'${value.toISOString().slice(0, 19).replace("T", " ")}'`;
    if (typeof value === "number") return Number.isFinite(value) ? String(value) : "NULL";
    if (typeof value === "boolean") return value ? "1" : "0";
    if (Buffer.isBuffer(value)) return `X'${value.toString("hex")}'`;

    return `'${String(value).replace(/'/g, "''")}'`;
};

const buildStatement = (strings, values) => {
    if (typeof strings === "string") return strings;

    let statement = "";
    for (let index = 0; index < strings.length; index += 1) {
        statement += strings[index];
        if (index < values.length) statement += escapeValue(values[index]);
    }
    return statement;
};

const bindStatementValues = (statement, values = []) =>
    statement.replace(/@p(\d+)\b/gi, (placeholder, index) =>
        Number(index) < values.length ? escapeValue(values[Number(index)]) : placeholder
    );

const getStatementExcerpt = (statement) => {
    const text = String(statement || "").replace(/\s+/g, " ").trim();
    return text ? ` SQL: ${text.slice(0, 4000)}` : "";
};

const databaseError = (error, operation, name, statement) => {
    const driverMessage = error?.message || String(error || "Unknown ODBC error");
    const nativeDetails = Array.isArray(error?.odbcErrors)
        ? error.odbcErrors
            .map((odbcError) => [odbcError.state, odbcError.code, odbcError.message].filter(Boolean).join(" "))
            .filter(Boolean)
            .join("; ")
        : "";
    const detail = nativeDetails ? ` Native ODBC details: ${nativeDetails}` : "";
    const wrapped = new Error(`${name} database ${operation} failed: ${driverMessage}${detail}${getStatementExcerpt(statement)}`);
    wrapped.name = "DatabaseError";
    wrapped.code = error?.code || "DATABASE_ODBC_ERROR";
    wrapped.statusCode = 500;
    wrapped.originalError = error;
    wrapped.statement = statement;
    return wrapped;
};

const normalizeQueryValue = (value) => (typeof value === "bigint" ? Number(value) : value);

const normalizeQueryRow = (row) => {
    if (!row || typeof row !== "object" || Array.isArray(row)) {
        return row;
    }

    return Object.fromEntries(
        Object.entries(row).map(([key, value]) => [key, normalizeQueryValue(value)])
    );
};

const normalizeQueryResult = (result) =>
    Array.isArray(result) ? result.map(normalizeQueryRow) : result;

const createOdbcClient = ({ name, getConnectionString }) => {
    let connection;
    let connectionPromise;

    const initializeConnection = async () => {
        if (connection) return connection;

        if (!connectionPromise) {
            assertDriverArchitecture();
            connectionPromise = odbc.connect(getConnectionString())
                .then((openedConnection) => {
                    connection = openedConnection;
                    return connection;
                })
                .catch((error) => {
                    connectionPromise = null;
                    throw error;
                });
        }

        return connectionPromise;
    };

    const queryWithConnection = async (conn, statement, operation = "query") => {
        try {
            return normalizeQueryResult(await conn.query(statement));
        } catch (error) {
            throw databaseError(error, operation, name, statement);
        }
    };

    const executeWithConnection = async (conn, statement) => {
        try {
            const result = await conn.query(statement);
            return typeof result?.count === "number" && result.count >= 0 ? result.count : 0;
        } catch (error) {
            throw databaseError(error, "execute", name, statement);
        }
    };

    const clientFor = (getConnection) => ({
        query: (strings, ...values) => queryWithConnection(getConnection(), buildStatement(strings, values)),
        execute: (strings, ...values) => executeWithConnection(getConnection(), buildStatement(strings, values)),
        queryUnsafe: (statement) => queryWithConnection(getConnection(), statement),
        executeUnsafe: (statement) => executeWithConnection(getConnection(), statement),
        queryStatement: (statement, values = []) =>
            queryWithConnection(getConnection(), bindStatementValues(statement, values)),
        executeStatement: (statement, values = []) =>
            executeWithConnection(getConnection(), bindStatementValues(statement, values))
    });

    const rootClient = {
        connect: initializeConnection,

        async close() {
            const conn = connection || (connectionPromise ? await connectionPromise : null);
            connection = null;
            connectionPromise = null;
            if (conn) await conn.close();
        },

        async getConnection() {
            return initializeConnection();
        },

        async withTransaction(callback) {
            const conn = await initializeConnection();
            await conn.beginTransaction();

            try {
                const result = await callback(clientFor(() => conn));
                await conn.commit();
                return result;
            } catch (error) {
                try {
                    await conn.rollback();
                } catch (rollbackError) {
                    error.rollbackError = rollbackError;
                }
                throw error;
            }
        }
    };

    for (const method of ["query", "execute", "queryUnsafe", "executeUnsafe", "queryStatement", "executeStatement"]) {
        rootClient[method] = async (...args) => {
            await initializeConnection();
            return clientFor(() => connection)[method](...args);
        };
    }

    return rootClient;
};

module.exports = createOdbcClient;
