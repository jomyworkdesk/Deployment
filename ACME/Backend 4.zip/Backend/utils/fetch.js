module.exports = typeof global.fetch === "function"
    ? global.fetch
    : require("node-fetch");
