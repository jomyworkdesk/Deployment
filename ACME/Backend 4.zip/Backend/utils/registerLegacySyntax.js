const path = require("path");

if (Number(process.versions.node.split(".")[0]) < 14) {
    // Node 12 parses the entry points directly. Transform backend modules as they load.
    require("@babel/register")({
        cwd: path.resolve(__dirname, ".."),
        extensions: [".js"],
        babelrc: false,
        configFile: false,
        cache: false,
        plugins: [
            require.resolve("@babel/plugin-transform-optional-chaining"),
            require.resolve("@babel/plugin-transform-nullish-coalescing-operator")
        ]
    });
}
