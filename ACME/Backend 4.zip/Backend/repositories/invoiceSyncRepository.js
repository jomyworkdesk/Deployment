const db = require("../db");
const dbSecondary = require("../dbSecondary");
const { RENAMED_INVOICE_COLUMNS } = require("./invoiceColumnAliases");
const SYNC_BATCH_SIZE = 2;
const CREDIT_NOTE_DOC_TYPE = 4;
const INVOICE_TABLE = "E_Invoicing";
const DISCOUNT_ALLOW_REASON = "Discount Applied";

const columnCache = new Map();

const quoteIdentifier = (identifier) => `"${String(identifier).replace(/"/g, '""')}"`;

const normalizeColumnKey = (value) =>
    String(value || "")
        .replace(/[_\-\s]/g, "")
        .toLowerCase();

const pervasiveColumnAliases = Object.fromEntries(
    Object.entries(RENAMED_INVOICE_COLUMNS)
        .map(([legacyColumn, currentColumn]) => [currentColumn, legacyColumn])
);

const getTableColumns = async (client = dbSecondary, tableName = INVOICE_TABLE) => {
    if (columnCache.has(tableName)) {
        return columnCache.get(tableName);
    }

    const connection = client === dbSecondary ? await dbSecondary.getConnection() : await client.getConnection();
    const result = await withSyncStep(`Loading ${tableName} columns`, () =>
        connection.query(`SELECT * FROM ${quoteIdentifier(tableName)} WHERE 1=0`)
    );

    const columns = Array.isArray(result?.columns)
        ? result.columns.map((column) => column.name).filter(Boolean)
        : [];
    columnCache.set(tableName, columns);
    return columns;
};

const findColumn = (columns, name) => {
    const normalizedName = normalizeColumnKey(name);
    return columns.find((column) => normalizeColumnKey(column) === normalizedName);
};

const resolveInvoiceColumns = async (client, valuesByColumn) => {
    const tableColumns = await getTableColumns(client, INVOICE_TABLE);
    const resolvedValues = {};

    for (const [appColumn, value] of Object.entries(valuesByColumn)) {
        const legacyColumn = pervasiveColumnAliases[appColumn];
        const actualColumn = findColumn(tableColumns, appColumn) || findColumn(tableColumns, legacyColumn);

        if (actualColumn) {
            resolvedValues[actualColumn] = value;
        }
    }

    return resolvedValues;
};

const escapeSql = (value) => String(value).replace(/'/g, "''");

const normalizeDocumentNumberKey = (value) => {
    if (value === null || value === undefined || value === "") return null;

    return String(value).trim();
};

const normalizeLookupKey = (value) => {
    if (value === null || value === undefined || value === "") return "";

    return String(value).trim().toLowerCase();
};

const isBlankValue = (value) =>
    value === null || value === undefined || (typeof value === "string" && value.trim() === "");

const allowReasonWithFallback = (value, hasAllowance) =>
    hasAllowance && isBlankValue(value) ? DISCOUNT_ALLOW_REASON : value;

const normalizeVatCategoryCode = (value) => String(value || "").trim().toUpperCase();

const getVatRateForCategoryCode = (value) =>
    normalizeVatCategoryCode(value) === "S" ? 5.00 : 0.00;

const isCreditNoteDocType = (value) => Number(value) === CREDIT_NOTE_DOC_TYPE;

const buildSqlStringList = (values) =>
    values
        .filter((value) => value !== null && value !== undefined && value !== "")
        .map((value) => `'${escapeSql(value)}'`)
        .join(",");

const buildSqlValueList = (values) =>
    values
        .filter((value) => value !== null && value !== undefined && value !== "")
        .map((value) => {
            const number = Number(value);
            return Number.isFinite(number) ? String(number) : `'${escapeSql(value)}'`;
        })
        .join(",");

const buildHistoryDocFilter = (documents) =>
    documents
        .map((doc) => {
            const documentNumber = normalizeDocumentNumberKey(doc?.AutoIndex ?? doc?.InvNumber);
            if (!documentNumber) return null;

            return `(LTRIM(RTRIM(HH.DocumentNumber)) = '${escapeSql(documentNumber)}')`;
        })
        .filter(Boolean)
        .join(" OR ");

const normalizeDate = (value) => {
    if (!value) return null;
    if (value instanceof Date) return value.toISOString().slice(0, 10);

    const text = String(value).trim();
    const isoMatch = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
    if (isoMatch) {
        const [, year, month, day] = isoMatch;
        return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    }

    const slashMatch = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if (slashMatch) {
        const [, month, day, year] = slashMatch;
        return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    }

    return text.slice(0, 10);
};

const normalizeTime = (value) => {
    if (!value) return null;
    if (value instanceof Date) return value.toTimeString().slice(0, 8);

    const text = String(value).trim();
    const timeMatch = text.match(/(\d{1,2}:\d{2}:\d{2})/);
    if (!timeMatch) return null;

    return timeMatch[1]
        .split(":")
        .map((part) => part.padStart(2, "0"))
        .join(":");
};

const getMonthStart = (value) => {
    const dateText = normalizeDate(value);
    return dateText ? `${dateText.slice(0, 7)}-01` : null;
};

const getMonthEnd = (value) => {
    const dateText = normalizeDate(value);
    if (!dateText) return null;

    const [year, month] = dateText.split("-").map(Number);
    if (!year || !month) return null;

    const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
    return `${String(year).padStart(4, "0")}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`;
};

const toDecimal = (value, fallback = 0) => {
    if (value === null || value === undefined || value === "") return fallback;
    const normalized = typeof value === "string"
        ? value.replace(/,/g, "").match(/-?\d+(\.\d+)?/)?.[0]
        : value;
    const decimal = Number(normalized);
    return Number.isFinite(decimal) ? decimal : fallback;
};

const roundDecimal = (value, precision = 6) =>
    Number.isFinite(value) ? Number(value.toFixed(precision)) : null;

const buildDocumentDiscountValues = (totalAfterDiscount, discountPercent) => {
    const percent = toDecimal(discountPercent);

    if (percent === 0) {
        return {
            hasDiscount: false,
            percent: null,
            amount: null,
            baseAmount: null
        };
    }

    const total = toDecimal(totalAfterDiscount);
    const remainingFactor = 1 - (percent / 100);

    if (remainingFactor <= 0) {
        return {
            hasDiscount: true,
            percent,
            amount: null,
            baseAmount: null
        };
    }

    const baseAmount = total / remainingFactor;

    return {
        hasDiscount: true,
        percent,
        amount: roundDecimal(baseAmount - total),
        baseAmount: roundDecimal(baseAmount)
    };
};

const readRowValue = (row, ...keys) => {
    if (!row || typeof row !== "object") return null;

    for (const key of keys) {
        if (Object.prototype.hasOwnProperty.call(row, key)) {
            return row[key];
        }

        const actualKey = Object.keys(row).find(
            (rowKey) => rowKey.toLowerCase() === String(key).toLowerCase()
        );

        if (actualKey) return row[actualKey];
    }

    return null;
};

const mapSellerSourceRow = (row = {}) => ({
    SellerElectronicAddress: readRowValue(row, "ElectronicAddress", "ElectronicAdd"),
    SellerElectronicSchemeId: readRowValue(row, "ElectronicSchemeID", "ElectronicSchID"),
    SellerId: readRowValue(row, "SellerIdentifier"),
    SellerSchemeId: readRowValue(row, "SchemeID"),
    SellerTradeName: readRowValue(row, "LEGALNAME", "CONAME"),
    SellerName: readRowValue(row, "CONAME", "LEGALNAME"),
    SellerAddressline1: readRowValue(row, "ADDR01"),
    SellerAddressline2: readRowValue(row, "ADDR02"),
    SellerAddressline3: readRowValue(row, "ADDR03"),
    SellerCity: readRowValue(row, "CITY"),
    SellerPostCode: readRowValue(row, "POSTAL"),
    SellerCountrySubdivision: readRowValue(row, "CountrySubdivision", "CountrySubdiv"),
    SellerCountryCode: readRowValue(row, "CountryCode"),
    SellerVatId: readRowValue(row, "TAXNBR"),
    SellerTaxSchemeCode: readRowValue(row, "VATSchemeCode") || "VAT",
    SellerLegalRegistrationId: readRowValue(row, "LegalRegistrationID", "LegalRegisID"),
    SellerLegalSchemeId: readRowValue(row, "LegalSchemeID"),
    SellerAuthorityName: readRowValue(row, "AuthorityName"),
    SellerPassportCountryCode: readRowValue(row, "PassportIssuCountry", "PassportCountry"),
    SellerLegalRegistrationType: readRowValue(row, "LegalRegistType", "LegalRegType"),
    SellerContactPoint: readRowValue(row, "CONTACT"),
    SellerContactPhone: readRowValue(row, "PHONE"),
    SellerContactEmail: readRowValue(row, "ContactEmail")
});

const mapBuyerSourceRow = (row = {}) => ({
    ...row,
    IDCUST: readRowValue(row, "IDCUST"),
    BuyerElectronicAddress: readRowValue(row, "ElectronicAddress", "ElectronicAdd"),
    BuyerElectronicSchemeId: readRowValue(row, "LegalSchemeID", "LegalSchemeID", "LegalSchemeID"),
    BuyerId: readRowValue(row, "BuyerIdentifier"),
    BuyerSchemeId: readRowValue(row, "LegalSchemeID", "SchemeID"),
    BuyerCountrySubdivision: readRowValue(row, "CountrySubdivision", "CountrySubdiv"),
    BuyerCountry: readRowValue(row, "CountryCode"),
    BuyerVatId: readRowValue(row, "VATIdentifier"),
    BuyerLegalRegistrationId: readRowValue(row, "LegalRegistrationID", "LegalRegisID"),
    BuyerLegalSchemeId: readRowValue(row, "LegalSchemeID"),
    BuyerAuthorityName: readRowValue(row, "AuthorityName"),
    BuyerPassportCountryCode: readRowValue(row, "PassportIssuCountry", "PassportCountry"),
    BuyerLegalRegistrationType: readRowValue(row, "LegalRegisType", "LegalRegistType", "LegalRegType")
});

const withSyncStep = async (step, action) => {
    try {
        return await action();
    } catch (error) {
        error.message = `${step}: ${error.message}`;
        throw error;
    }
};

const buildDecimalValues = (row) => ({
    contract_value: toDecimal(row.ContractValue),
    doc_allow_percent: toDecimal(row.DocAllowPercent, null),
    doc_allow_amount: toDecimal(row.DocAllowAmount, null),
    doc_allo_base_amt: toDecimal(row.DocAllowBaseAmount, null),
    doc_allow_vat_rate: toDecimal(row.DocAllowVatRate, null),
    doc_charge_percent: toDecimal(row.DocChargePercent, null),
    doc_charge_amount: toDecimal(row.DocChargeAmount, null),
    doc_charge_base_amt: toDecimal(row.DocChargeBaseAmount, null),
    doc_charge_vat_rate: toDecimal(row.DocChargeVatRate, null),
    calculation_rate: toDecimal(row.CalculationRate),
    inv_tot_tax_amt: toDecimal(row.InvTotTax),
    vat_cat_taxable_amt: toDecimal(row.InvTotExcl),
    vat_cat_tax_amt: toDecimal(row.InvTotTax),
    vat_cat_rate: toDecimal(row.VatCategoryRate),
    inv_tot_vat_currency: toDecimal(row.InvTotTax),
    inv_line_net_total: toDecimal(row.InvTotExcl),
    inv_tot_without_tax: toDecimal(row.InvTotExcl),
    inv_total_with_tax: toDecimal(row.InvTotIncl),
    total_doc_allowances: toDecimal(row.DocAllowAmount, null),
    total_doc_charges: toDecimal(row.TotalDocCharges),
    paid_amount: toDecimal(row.PaidAmount),
    rounding_amount: toDecimal(row.RoundingAmount),
    amount_due: toDecimal(row.InvTotIncl),
    invoiced_qty: toDecimal(row.InvoicedQuantity),
    invoice_line_net_amt: toDecimal(row.InvoiceLineNetAmount),
    line_allow_percent: toDecimal(row.LineAllowPercent),
    line_allow_amount: toDecimal(row.LineAllowAmount),
    line_allow_base_amt: toDecimal(row.LineAllowBaseAmount),
    line_charge_percent: toDecimal(row.LineChargePercent),
    line_charge_amount: toDecimal(row.LineChargeAmount),
    line_charge_base_amt: toDecimal(row.LineChargeBaseAmount),
    item_vat_rate: toDecimal(row.ItemVatRate),
    item_price_base_qty: toDecimal(row.ItemPriceBaseQty, 1),
    item_price_discount: toDecimal(row.ItemPriceDiscount),
    item_gross_price: toDecimal(row.ItemGrossPrice),
    invoice_line_amt_aed: toDecimal(row.VatLineAmountAed),
    vat_line_amt_aed: toDecimal(row.InvoiceLineAmountAed)
});

const lockPendingQueue = async (client = dbSecondary) => {
    const queueRows = await client.queryUnsafe(`
        SELECT TOP ${SYNC_BATCH_SIZE}
            QueueID,
            AutoIndex,
            InvNumber,
            DocType,
            InvDate,
            CreatedAt
        FROM E_InvoiceQueue
        WHERE (IsInvoiced IS NULL OR IsInvoiced = 0)
          AND (IsProcessing IS NULL OR IsProcessing = 0)
        ORDER BY QueueID ASC
    `);

    for (const row of queueRows) {
        await client.execute`
            UPDATE E_InvoiceQueue
            SET IsProcessing = 1,
                Status = '0'
            WHERE QueueID = ${row.QueueID}
        `;
    }

    return queueRows;
};

const fetchInvoiceSourceRows = async (client = db, documents, secondaryClient = dbSecondary) => {
    if (!documents.length) return [];

    const normalizedDocuments = documents.map((doc) =>
        typeof doc === "object"
            ? doc
            : {
                InvNumber: doc,
                AutoIndex: null,
                DocType: null
            }
    );

    const docFilter = buildHistoryDocFilter(normalizedDocuments);

    if (!docFilter) return [];

    const queueByDocument = new Map(
        normalizedDocuments.map((doc) => [
            normalizeDocumentNumberKey(doc.AutoIndex ?? doc.InvNumber),
            doc
        ])
    );

    const sellerRows = await withSyncStep("Loading seller details from E_Seller", () =>
        secondaryClient.queryUnsafe(`
            SELECT TOP 1 *
            FROM E_Seller
            ORDER BY OrgID
        `)
    );

    const sourceRows = await withSyncStep("Loading invoice source rows from Sage history", () => client.queryUnsafe(`
        SELECT
            HH.DocumentType AS DocType,
            LTRIM(RTRIM(HH.DocumentNumber)) AS ReferenceNumber,
            LTRIM(RTRIM(HH.DocumentNumber)) AS InvoiceNumber,
            HH.CustomerCode AS BuyerAccountRef,
            HH.DocumentDate AS HistoryDocumentDate,
            HH.ClosingDate AS PaymentDueDate,
            HH.Message02 AS InvoiceNote,
            HH.OrderNumber AS SalesOrderRef,
            HH.OrderNumber AS PrecedingInvoiceRef,
            HH.TotalTax AS InvTotTax,
            HH.Total AS InvTotExcl,
            HH.DiscountPercent AS DiscountPercent,
            HUD.UserDef01 AS DocAllowReason,
            BC.CustomerCode AS BuyerCustomerCode,
            BC.CustomerDesc AS BuyerTradeName,
            BC.CustomerDesc AS BuyerName,
            BC.PostAddress01 AS BuyerAddressline1,
            BC.PostAddress02 AS BuyerAddressline2,
            BC.PostAddress03 AS BuyerAddressline3,
            BC.PostAddress04 AS BuyerCity,
            BC.PostAddress05 AS BuyerPostCode,
            BA.Contact AS BuyerContactPoint,
            BA.Telephone AS BuyerContactPhone,
            BA.Email AS BuyerContactEmail,
            HL.Description AS ItemName,
            HL.Description AS ItemDescription,
            HL.UnitPrice AS PriceExcl,
            HL.FCurrUnitPrice AS ItemGrossPrice,
            HL.Qty AS InvoicedQuantity,
            HL.Qty AS ItemPriceBaseQty,
            HL.UnitUsed AS UnitUsed,
            HL.FCDiscountAmount AS InvoiceLineNetAmount,
            HL.DiscountPercentage / 100.0 AS LineAllowPercent,
            (HL.Qty * HL.FCurrUnitPrice) - HL.FCDiscountAmount AS LineAllowAmount,
            HL.Qty * HL.FCurrUnitPrice AS LineAllowBaseAmount,
            HL.FCurrTaxAmount AS InvoiceLineAmountAed,
            HL.FCDiscountAmount + HL.FCurrTaxAmount AS VatLineAmountAed,
            HL.TaxType AS TaxType
        FROM HistoryHeader HH
        INNER JOIN HistoryLines HL ON LTRIM(RTRIM(HH.DocumentNumber)) = LTRIM(RTRIM(HL.DocumentNumber))
        LEFT JOIN HistoryUserDesc HUD ON LTRIM(RTRIM(HUD.DocumentNumber)) = LTRIM(RTRIM(HH.DocumentNumber))
        LEFT JOIN CustomerMaster BC ON HH.CustomerCode = BC.CustomerCode
        LEFT JOIN DeliveryAddresses BA ON BC.CustomerCode = BA.CustomerCode
        WHERE (${docFilter})
        ORDER BY HH.DocumentNumber
    `));

    const buyerCodes = [...new Set(sourceRows.map((row) => row.BuyerCustomerCode).filter(Boolean))];
    const buyerRows = buyerCodes.length
        ? await withSyncStep("Loading buyer details from E_Buyer", () => secondaryClient.queryUnsafe(`
            SELECT
                *
            FROM E_Buyer
            WHERE IDCUST IN (${buildSqlStringList(buyerCodes)})
        `))
        : [];
    const hasUnitUsedValues = sourceRows.some((row) => normalizeLookupKey(row.UnitUsed));
    const unitRows = hasUnitUsedValues
        ? await withSyncStep("Loading unit mappings from EM_UnitOfMeasure", () => secondaryClient.queryUnsafe(`
            SELECT
                "Mapped" AS Mapped,
                "Value" AS Value
            FROM "EM_UnitOfMeasure"
            WHERE "Mapped" IS NOT NULL
              AND "Mapped" <> ''
        `))
        : [];
    const hasTaxTypeValues = sourceRows.some((row) => normalizeLookupKey(row.TaxType));
    const vatCategoryRows = hasTaxTypeValues
        ? await withSyncStep("Loading VAT mappings from EM_VATCategory", () => secondaryClient.queryUnsafe(`
            SELECT
                "Mapped" AS Mapped,
                "Value" AS Value
            FROM "EM_VATCategory"
            WHERE "Mapped" IS NOT NULL
        `))
        : [];
    const documentTypes = [
        ...new Set(
            [
                ...normalizedDocuments.map((doc) => doc.DocType),
                ...sourceRows.map((row) => row.DocType)
            ]
                .filter((docType) => docType !== null && docType !== undefined && docType !== "")
        )
    ];
    const documentTypeClause = buildSqlValueList(documentTypes);
    const lastDocumentRows = documentTypeClause
        ? await withSyncStep("Loading document type names from E_lastDocument", () => secondaryClient.queryUnsafe(`
            SELECT
                DocumentType,
                DocumentName
            FROM E_lastDocument
            WHERE DocumentName IS NOT NULL
              AND DocumentName <> ''
              AND DocumentType IS NOT NULL
              AND DocumentType IN (${documentTypeClause})
        `))
        : [];

    const seller = mapSellerSourceRow(sellerRows[0]);
    const buyerByCode = new Map(
        buyerRows
            .map(mapBuyerSourceRow)
            .map((buyer) => [String(buyer.IDCUST), buyer])
    );
    const unitValueByMapped = new Map(
        unitRows
            .map((unitRow) => [
                normalizeLookupKey(readRowValue(unitRow, "Mapped")),
                String(readRowValue(unitRow, "Value") || "").trim()
            ])
            .filter(([mapped, value]) => mapped && value)
    );
    const vatCategoryValueByMapped = new Map(
        vatCategoryRows
            .map((vatRow) => [
                normalizeLookupKey(readRowValue(vatRow, "Mapped")),
                normalizeVatCategoryCode(readRowValue(vatRow, "Value"))
            ])
            .filter(([mapped, value]) => mapped && value)
    );
    const documentNameByType = new Map();

    lastDocumentRows.forEach((documentRow) => {
        const documentName = String(documentRow.DocumentName || "").trim();
        if (!documentName) return;

        const documentType = documentRow.DocumentType;
        if (documentType === null || documentType === undefined || documentType === "") return;

        documentNameByType.set(String(documentType), documentName);
    });

    const lineCounterByDocument = new Map();

    return sourceRows.map((row) => {
        const documentKey = normalizeDocumentNumberKey(row.ReferenceNumber);
        const lineNumber = (lineCounterByDocument.get(documentKey) || 0) + 1;
        lineCounterByDocument.set(documentKey, lineNumber);

        const queueRow = queueByDocument.get(documentKey) || {};
        const documentTypeKey = queueRow.DocType ?? row.DocType;
        const precedingInvoiceRef = isCreditNoteDocType(documentTypeKey) ? row.PrecedingInvoiceRef : null;
        const buyer = buyerByCode.get(String(row.BuyerCustomerCode)) || {};
        const invoiceIssueDate = normalizeDate(queueRow.InvDate || row.HistoryDocumentDate);
        const invTotExcl = toDecimal(row.InvTotExcl);
        const invTotTax = toDecimal(row.InvTotTax);
        const lineQuantity = toDecimal(row.InvoicedQuantity);
        const lineNet = toDecimal(row.PriceExcl) * lineQuantity;
        const vatCategoryCode = vatCategoryValueByMapped.get(normalizeLookupKey(row.TaxType)) || null;
        const itemVatCategoryCode = vatCategoryCode;
        const itemVatRate = getVatRateForCategoryCode(itemVatCategoryCode);
        const documentDiscount = buildDocumentDiscountValues(row.InvTotExcl, row.DiscountPercent);

        return {
            ...row,
            ...buyer,
            ...seller,
            InvoiceLineIdentifier: lineNumber,
            InvoiceIssueDate: invoiceIssueDate,
            InvoiceIssueTime: normalizeTime(queueRow.CreatedAt),
            InvoicePeriodStart: getMonthStart(invoiceIssueDate),
            InvoicePeriodEnd: getMonthEnd(invoiceIssueDate),
            PaymentDueDate: normalizeDate(row.PaymentDueDate),
            ActualDeliveryDate: null,
            InvoiceCurrencyCode: "AED",
            TaxAccountCurrency: "AED",
            TransactionCode: null,
            CreditNoteReasonCode: null,
            PrecedingInvoiceRef: precedingInvoiceRef,
            PrecedingInvoiceDate: null,
            BuyerTaxSchemeCode: "VAT",
            PaymentType: null,
            VatCategory: vatCategoryCode,
            VatCategoryRate: getVatRateForCategoryCode(vatCategoryCode),
            ItemVatCategory: itemVatCategoryCode,
            ItemVatRate: itemVatRate,
            SyntaxBindingQualifier: null,
            DocAllowReasonCode: null,
            DocAllowReason: documentDiscount.hasDiscount
                ? readRowValue(row, "DocAllowReason", "UserDef01")
                : null,
            DocAllowPercent: documentDiscount.percent,
            DocAllowAmount: documentDiscount.amount,
            DocAllowBaseAmount: documentDiscount.baseAmount,
            DocAllowVatCat: documentDiscount.hasDiscount ? itemVatCategoryCode : null,
            DocAllowVatRate: documentDiscount.hasDiscount ? itemVatRate : null,
            DocAllowExemptCode: null,
            DocAllowExemptText: null,
            DocAllowSchemeCode: documentDiscount.hasDiscount ? "VAT" : null,
            UOMCode: unitValueByMapped.get(normalizeLookupKey(row.UnitUsed)) || null,
            LineExtensionAmount: lineNet,
            InvTotExcl: invTotExcl,
            InvTotTax: invTotTax,
            InvTotIncl: invTotExcl + invTotTax,
            TotalInvoiceAmt: invTotTax,
            EInvoiceType: documentNameByType.get(String(documentTypeKey)) || null,
            InvoiceNote: row.InvoiceNote,
            SalesOrderRef: row.SalesOrderRef,
            BuyerAccountRef: row.BuyerAccountRef
        };
    });
};

const diagnoseInvoiceSourceDocuments = async (client = db, documents = []) => {
    const documentNumbers = documents.map((doc) =>
        normalizeDocumentNumberKey(doc.AutoIndex ?? doc.InvNumber)
    );
    const documentClause = buildSqlStringList([...new Set(documentNumbers.filter(Boolean))]);
    if (!documentClause) return [];

    const headers = await withSyncStep("Diagnosing Sage HistoryHeader matches", () => client.queryUnsafe(`
        SELECT HH.DocumentNumber, HH.DocumentType, COUNT(HL.DocumentNumber) AS JoinedLineCount
        FROM HistoryHeader HH
        LEFT JOIN HistoryLines HL ON LTRIM(RTRIM(HH.DocumentNumber)) = LTRIM(RTRIM(HL.DocumentNumber))
        WHERE LTRIM(RTRIM(HH.DocumentNumber)) IN (${documentClause})
        GROUP BY HH.DocumentNumber, HH.DocumentType
    `));
    const lines = await withSyncStep("Diagnosing Sage HistoryLines matches", () => client.queryUnsafe(`
        SELECT DocumentNumber, COUNT(*) AS LineCount
        FROM HistoryLines
        WHERE LTRIM(RTRIM(DocumentNumber)) IN (${documentClause})
        GROUP BY DocumentNumber
    `));

    return documents.map((document, index) => {
        const lookupDocumentNumber = documentNumbers[index];
        const headerMatches = headers
            .filter((row) => normalizeDocumentNumberKey(readRowValue(row, "DocumentNumber")) === lookupDocumentNumber)
            .map((row) => ({
                documentNumber: readRowValue(row, "DocumentNumber"),
                documentType: readRowValue(row, "DocumentType"),
                joinedLineCount: Number(readRowValue(row, "JoinedLineCount")) || 0
            }));
        const lineMatches = lines
            .filter((row) => normalizeDocumentNumberKey(readRowValue(row, "DocumentNumber")) === lookupDocumentNumber)
            .map((row) => ({
                documentNumber: readRowValue(row, "DocumentNumber"),
                lineCount: Number(readRowValue(row, "LineCount")) || 0
            }));
        const lineCount = lineMatches.reduce((total, row) => total + row.lineCount, 0);
        const joinedLineCount = headerMatches.reduce((total, row) => total + row.joinedLineCount, 0);
        let reason = "Header and joined lines exist during diagnostics, but the source query returned no rows";

        if (headerMatches.length === 0) {
            reason = "No HistoryHeader found by trimmed DocumentNumber in the configured primary DSN";
        } else if (lineCount === 0) {
            reason = "HistoryHeader exists, but no HistoryLines found by trimmed DocumentNumber";
        } else if (joinedLineCount === 0) {
            reason = "Header and lines exist, but their trimmed DocumentNumber values do not join";
        }

        return {
            QueueID: document.QueueID,
            sourceDsn: process.env.PRIMARY_DB_DSN,
            lookupDocumentNumber,
            sourceFilter: buildHistoryDocFilter([document]),
            headers: headerMatches,
            lines: lineMatches,
            lineCount,
            joinedLineCount,
            reason
        };
    });
};

const invoiceColumnValues = (row) => {
    const decimals = buildDecimalValues(row);
    const hasLineAllowance = decimals.line_allow_percent > 0;
    const hasDocumentAllowance = [
        row.DocAllowPercent,
        row.DocAllowAmount,
        row.DocAllowBaseAmount
    ].some((value) => !isBlankValue(value));
    return {
        spec_identifier: row.SpecIdentifier || "urn:peppol:pint:billing-1@ae-1",
        business_proc_type: row.BusinessProcessType || "urn:peppol:bis:billing",
        vat_cat_sche_code: "VAT",
        syntax_bind_qualifi: null,
        doc_allo_rea_code: row.DocAllowReasonCode,
        doc_allow_reason: allowReasonWithFallback(row.DocAllowReason, hasDocumentAllowance),
        doc_allow_percent: decimals.doc_allow_percent,
        doc_allow_amount: decimals.doc_allow_amount,
        doc_allo_base_amt: decimals.doc_allo_base_amt,
        doc_allow_vat_cat: row.DocAllowVatCat,
        doc_allow_vat_rate: decimals.doc_allow_vat_rate,
        doc_allow_exem_code: row.DocAllowExemptCode,
        doc_allow_exem_text: row.DocAllowExemptText,
        doc_allow_sche_code: row.DocAllowSchemeCode,
        doc_char_reason_code: null,
        doc_charge_reason: null,
        doc_charge_percent: decimals.doc_charge_percent,
        doc_charge_amount: decimals.doc_charge_amount,
        doc_charge_base_amt: decimals.doc_charge_base_amt,
        doc_charge_vat_cat: null,
        doc_charge_vat_rate: decimals.doc_charge_vat_rate,
        doc_char_exempt_code: null,
        doc_char_exempt_text: null,
        doc_char_scheme_code: null,
        invoice_no: row.InvoiceNumber,
        unique_identifier_no: row.ReferenceNumber,
        invoice_issue_date: row.InvoiceIssueDate,
        invoice_issue_time: row.InvoiceIssueTime,
        payment_due_date: row.PaymentDueDate,
        invoice_note: row.InvoiceNote,
        vat_tax_point_date: row.InvoiceIssueDate,
        inv_currency_code: row.InvoiceCurrencyCode,
        tax_account_currency: row.TaxAccountCurrency,
        buyer_account_ref: row.BuyerAccountRef,
        invoice_period_start: row.InvoicePeriodStart,
        invoice_period_end: row.InvoicePeriodEnd,
        sales_order_ref: row.SalesOrderRef,
        // credit_reason_code: row.CreditNoteReasonCode,
        preceding_inv_ref: row.PrecedingInvoiceRef,
        preceding_inv_date: row.PrecedingInvoiceDate,
        seller_elec_address: row.SellerElectronicAddress,
        seller_elec_sche_id: row.SellerElectronicSchemeId,
        seller_id: row.SellerId,
        seller_scheme_id: row.SellerSchemeId,
        seller_trade_name: row.SellerTradeName,
        seller_addr_line1: row.SellerAddressline1,
        seller_addr_line2: row.SellerAddressline2,
        seller_city: row.SellerCity,
        seller_post_code: row.SellerPostCode,
        seller_country_sub: row.SellerCountrySubdivision,
        seller_addr_line3: row.SellerAddressline3,
        seller_country_code: row.SellerCountryCode,
        seller_vat_id: row.SellerVatId,
        seller_tax_sch_cod: row.SellerTaxSchemeCode,
        seller_name: row.SellerName,
        seller_legal_reg_id: row.SellerLegalRegistrationId,
        seller_legal_sch_id: row.SellerLegalSchemeId,
        seller_author_name: row.SellerAuthorityName,
        seller_passport_code: row.SellerPassportCountryCode,
        seller_legal_reg_typ: row.SellerLegalRegistrationType,
        seller_contact_point: row.SellerContactPoint,
        seller_contact_phone: row.SellerContactPhone,
        seller_contact_email: row.SellerContactEmail,
        buyer_elec_address: row.BuyerElectronicAddress,
        buyer_elec_scheme_id: row.BuyerElectronicSchemeId,
        buyer_id: row.BuyerId,
        buyer_scheme_id: row.BuyerSchemeId,
        buyer_trade_name: row.BuyerTradeName,
        buyer_addr_line1: row.BuyerAddressline1,
        buyer_addr_line2: row.BuyerAddressline2,
        buyer_city: row.BuyerCity,
        buyer_post_code: row.BuyerPostCode,
        buyer_country_sub: row.BuyerCountrySubdivision,
        buyer_addr_line3: row.BuyerAddressline3,
        buyer_country_code: row.BuyerCountry,
        buyer_vat_id: row.BuyerVatId,
        buyer_tax_sch_cod: row.BuyerTaxSchemeCode,
        buyer_name: row.BuyerName,
        buyer_legal_reg_id: row.BuyerLegalRegistrationId,
        buyer_legal_sch_id: row.BuyerLegalSchemeId,
        buyer_authority_name: row.BuyerAuthorityName,
        buyer_passport_code: row.BuyerPassportCountryCode,
        buyer_legal_reg_type: row.BuyerLegalRegistrationType,
        buyer_contact_point: row.BuyerContactPoint,
        buyer_contact_phone: row.BuyerContactPhone,
        buyer_contact_email: row.BuyerContactEmail,
        actual_delivery_date: row.ActualDeliveryDate,
        inv_tot_tax_amt: decimals.inv_tot_tax_amt,
        vat_cat_taxable_amt: decimals.vat_cat_taxable_amt,
        vat_cat_tax_amt: decimals.vat_cat_tax_amt,
        vat_cat_code: row.VatCategory,
        vat_cat_rate: decimals.vat_cat_rate,
        inv_tot_vat_currency: decimals.inv_tot_vat_currency,
        inv_line_net_total: decimals.inv_line_net_total,
        inv_tot_without_tax: decimals.inv_tot_without_tax,
        inv_total_with_tax: decimals.inv_total_with_tax,
        total_doc_allowances: decimals.total_doc_allowances,
        total_doc_charges: decimals.total_doc_charges,
        paid_amount: decimals.paid_amount,
        rounding_amount: decimals.rounding_amount,
        amount_due: decimals.amount_due,
        invoice_line_id: row.InvoiceLineIdentifier,
        invoiced_qty: decimals.invoiced_qty,
        inv_qty_uom_code: row.UOMCode,
        invoice_line_net_amt: decimals.invoice_line_net_amt,
        ...(hasLineAllowance ? {
            charge_indicator: 0,
            line_allow_reas_code: null,
            line_allow_reason: "line_doc_allow",
            line_allow_percent: decimals.line_allow_percent,
            line_allow_amount: decimals.line_allow_amount,
            line_allow_base_amt: decimals.line_allow_base_amt
        } : {}),
        item_description: row.ItemDescription,
        item_name: row.ItemName,
        item_vat_cat_code: row.ItemVatCategory,
        item_vat_rate: decimals.item_vat_rate,
        item_tax_scheme: "VAT",
        item_net_price: toDecimal(row.PriceExcl),
        item_price_base_qty: decimals.item_price_base_qty,
        item_price_discount: decimals.item_price_discount,
        item_gross_price: decimals.item_gross_price,
        invoice_line_amt_aed: decimals.invoice_line_amt_aed,
        vat_line_amt_aed: decimals.vat_line_amt_aed,
        DocType: row.DocType,
        EInvoiceType: row.EInvoiceType
    };
};

const upsertInvoiceRow = async (client = dbSecondary, row) => {
    const valuesByColumn = await resolveInvoiceColumns(client, invoiceColumnValues(row));
    const columns = Object.keys(valuesByColumn);
    const values = Object.values(valuesByColumn);
    const uniqueIdentifierColumn = findColumn(columns, "unique_identifier_no") || "unique_identifier_no";
    const invoiceLineIdColumn = findColumn(columns, "invoice_line_id") || "invoice_line_id";

    const existingRows = await withSyncStep("Checking existing E_Invoicing row", () => client.queryStatement(
        `
            SELECT TOP 1 ID
            FROM E_Invoicing
            WHERE ${quoteIdentifier(uniqueIdentifierColumn)} = @p0
              AND ${quoteIdentifier(invoiceLineIdColumn)} = @p1
        `,
        [row.ReferenceNumber, row.InvoiceLineIdentifier]
    ));

    if (existingRows.length > 0) {
        const updateColumns = columns.filter(
            (column) => ![uniqueIdentifierColumn, invoiceLineIdColumn].includes(column)
        );
        const isDeletedColumn = findColumn(await getTableColumns(client, INVOICE_TABLE), "Isdeleted");
        const resetDeletedAssignment = isDeletedColumn
            ? `,
                 ${quoteIdentifier(isDeletedColumn)} = NULL`
            : "";
        const updateValues = updateColumns.map((column) => valuesByColumn[column]);
        const assignments = updateColumns
            .map((column, index) => `${quoteIdentifier(column)} = @p${index}`)
            .join(", ");
        const whereIndex = updateValues.length;

        await withSyncStep("Updating E_Invoicing row", () => client.executeStatement(
            `UPDATE E_Invoicing
             SET ${assignments},
                 updated_at = NOW()${resetDeletedAssignment}
              WHERE ${quoteIdentifier(uniqueIdentifierColumn)} = @p${whereIndex}
                AND ${quoteIdentifier(invoiceLineIdColumn)} = @p${whereIndex + 1}`,
            [...updateValues, row.ReferenceNumber, row.InvoiceLineIdentifier]
        ));
        return;
    }

    const nextIdRows = await withSyncStep("Getting next E_Invoicing ID", () =>
        client.queryUnsafe("SELECT MAX(ID) AS MaxID FROM E_Invoicing")
    );
    const nextId = Number(nextIdRows[0]?.MaxID || 0) + 1;

    await withSyncStep("Inserting E_Invoicing row", () => client.executeStatement(
        `INSERT INTO E_Invoicing (
            ID,
            ${columns.map(quoteIdentifier).join(", ")},
            created_at,
            updated_at
        )
        VALUES (
            @p0,
            ${columns.map((_, index) => `@p${index + 1}`).join(", ")},
            NOW(),
            NOW()
        )`,
        [nextId, ...values]
    ));
};

const markQueueInvoiced = async (client = dbSecondary, queueData) => {
    if (!queueData.length) return;
    const queueClause = queueData.map((q) => Number(q.QueueID)).join(",");
    await client.executeUnsafe(`
        UPDATE E_InvoiceQueue
        SET IsInvoiced = 1,
            IsProcessing = 0,
            InvoicedAt = NOW(),
            Status = '1'
        WHERE QueueID IN (${queueClause})
    `);
};

const releaseQueueEntries = async (client = dbSecondary, queueData) => {
    if (!queueData.length) return;
    const queueClause = queueData.map((q) => Number(q.QueueID)).join(",");
    await client.executeUnsafe(`
        UPDATE E_InvoiceQueue
        SET IsProcessing = 0
        WHERE QueueID IN (${queueClause})
    `);
};

const releaseStuckQueue = async (client = dbSecondary) => {
    await client.execute`
        UPDATE E_InvoiceQueue
        SET IsProcessing = 0,
            Status = '0'
        WHERE IsProcessing = 1 AND IsInvoiced = 0
    `;
};

module.exports = {
    lockPendingQueue,
    fetchInvoiceSourceRows,
    diagnoseInvoiceSourceDocuments,
    upsertInvoiceRow,
    markQueueInvoiced,
    releaseQueueEntries,
    releaseStuckQueue
};
