const {
    getLastDocuments,
    getNewHistoryDocuments,
    queueHistoryDocuments
} = require("../repositories/historyHeaderQueueRepository");
const { saveCronLog } = require("../repositories/cronLogRepository");

let isRunning = false;

const writeCronLog = async (logDetails) => {
    const details = {
        cron: "history-header-queue",
        ...logDetails
    };

    try {
        await saveCronLog({
            type: "history-header-queue",
            logDetails: details
        });
    } catch (logError) {
        console.error(
            `[HistoryHeaderQueue ${new Date().toISOString()}] cron log insert failed: ${logError.message || logError}`
        );
    }

    console.log(
        `[HistoryHeaderQueue ${new Date().toISOString()}] ${JSON.stringify(details)}`
    );
};

const flattenDocuments = (documentsByType) =>
    documentsByType.reduce((documents, typeDocuments) => documents.concat(typeDocuments), []);

async function historyHeaderQueueJob() {
    if (isRunning) {
        const skippedResult = {
            skipped: true,
            message: "HistoryHeader queue cron is already running"
        };
        await writeCronLog(skippedResult);
        return skippedResult;
    }

    isRunning = true;

    try {
        const lastDocuments = await getLastDocuments();
        const documentsByType = [];
        const checks = [];

        for (const lastDocument of lastDocuments) {
            const documents = await getNewHistoryDocuments(lastDocument);
            documentsByType.push(documents);
            checks.push({ lastDocument, found: documents.length });
        }

        const newDocuments = flattenDocuments(documentsByType);
        const checkDetails = {
            checkedDocumentTypes: lastDocuments.length,
            sourceDsn: process.env.PRIMARY_DB_DSN,
            checkpointDsn: process.env.SECONDARY_DB_DSN,
            checks
        };

        if (newDocuments.length === 0) {
            const result = {
                ...checkDetails,
                found: 0,
                inserted: 0,
                updatedLastDocuments: 0,
                message: "No new HistoryHeader document exists"
            };
            await writeCronLog(result);
            return result;
        }

        const queueResult = await queueHistoryDocuments(newDocuments);
        const result = {
            ...checkDetails,
            found: newDocuments.length,
            ...queueResult
        };

        await writeCronLog(result);
        return result;
    } catch (error) {
        await writeCronLog({
            status: "error",
            message: error.message || "HistoryHeader queue cron failed"
        });
        throw error;
    } finally {
        isRunning = false;
    }
}

module.exports = historyHeaderQueueJob;
