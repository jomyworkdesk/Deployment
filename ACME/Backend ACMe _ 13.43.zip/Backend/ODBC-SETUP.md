# Run the backend from Command Prompt

Copy the `Backend` folder to the destination computer and open Command Prompt.
Use the folder's actual path in the `cd` command.

```cmd
cd /d "D:\ARTAX-50 ACME\Backend"
where node
node -v
npm -v
node -p "process.arch"
```

The intended versions are Node `v12.22.3` and npm `6.14.13`. With a 32-bit
Pervasive ODBC driver, `process.arch` must be `ia32`. Use
`C:\Windows\SysWOW64\odbcad32.exe` on 64-bit Windows or
`C:\Windows\System32\odbcad32.exe` on 32-bit Windows to verify the 32-bit
System DSNs.

Set the destination computer's values in `Backend\.env`. Use `.env.example`
as a reference for the remaining settings, including `PORT` and `HOST`.

```env
PRIMARY_DB_DSN=<primary DSN>
PRIMARY_DB_NAME=<primary database name>
SECONDARY_DB_DSN=<secondary DSN>
SECONDARY_DB_NAME=<secondary database name>
PERVASIVE_ODBC_ARCH=32
```

The primary connection serves regular Sage tables. The secondary connection
serves tables starting with `EM_`, `E_`, or `e_`. Define both connections.

```cmd
npm ci
node app.js
```

Run `npm ci` for the initial dependency installation and after lockfile changes.
On 32-bit Windows Node, the `odbc` package compiles its native addon during
installation. This requires Python and a Visual C++ x86 toolchain with a Windows
SDK that the Node 12 npm toolchain supports. The package provides a prebuilt
addon for Windows x64. [ODBC 2.4.8 release files](https://github.com/IBM/node-odbc/releases/tag/v2.4.8)

For subsequent launches, run `node app.js` from the `Backend` directory. Keep
Command Prompt open while it runs. Open `http://localhost:1001/health` to check
startup, using the `PORT` from `Backend\.env`. The response should include
`"status":"ok"`. Press **Ctrl+C** to stop the backend.
