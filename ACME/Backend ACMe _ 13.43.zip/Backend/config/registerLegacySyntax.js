const path = require("path");

if (Number(process.versions.node.split(".")[0]) < 14) {
    const fs = require("fs");
    const { transformSync } = require("esbuild");
    const backendDirectory = path.resolve(__dirname, "..") + path.sep;
    const loadJavaScript = require.extensions[".js"];

    // Make backend source syntax readable by Node 12 as modules are loaded.
    require.extensions[".js"] = (module, filename) => {
        if (!filename.startsWith(backendDirectory) || filename.includes(`${path.sep}node_modules${path.sep}`)) {
            return loadJavaScript(module, filename);
        }

        const source = fs.readFileSync(filename, "utf8");
        const { code } = transformSync(source, { target: "node12", sourcefile: filename });
        module._compile(code, filename);
    };
}
