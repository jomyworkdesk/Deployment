@echo off
setlocal
if not defined ARTAX_NODE_HOME set "ARTAX_NODE_HOME=C:\Program Files\nodejs"
set "PATH=%ARTAX_NODE_HOME%;%PATH%"
"%ARTAX_NODE_HOME%\node.exe" "%ARTAX_NODE_HOME%\node_modules\npm\bin\npm-cli.js" %*

