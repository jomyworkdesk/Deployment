# 32-bit ODBC setup

This backend uses the native `odbc` package. When the installed Pervasive ODBC
driver is 32-bit, the driver, System DSN, and Node runtime must all be 32-bit.

Create or verify the DSN with `C:\Windows\SysWOW64\odbcad32.exe`, then set in
`.env`:

```env
PRIMARY_DB_DSN=<primary DSN>
PRIMARY_DB_NAME=<primary database name>
SECONDARY_DB_DSN=<secondary DSN>
SECONDARY_DB_NAME=<secondary database name>
PERVASIVE_ODBC_ARCH=32
```

The primary connection is used for regular Sage tables. The secondary
connection is used by APIs/repositories that work with tables starting with
`EM_`, `E_`, or `e_`. The backend does not provide fallback DSN names; define
both connections in `.env`.

The startup scripts default to `C:\Program Files\nodejs`. Set `ARTAX_NODE_HOME`
to the Node installation directory if your x86 copy is elsewhere. From the
`Backend` directory in Command Prompt, verify the runtime and npm versions.

```cmd
node32.cmd -p "process.version + ' ' + process.arch"
npm32.cmd --version
```

For the Node 12 setup, expect `v12.22.3 ia32` and `6.14.13`. On Windows x86,
the `odbc` install builds a native addon and requires Python and Visual Studio
C++ Build Tools compatible with npm's `node-gyp`.

```cmd
npm32.cmd ci
npm32.cmd start
```

Run `.\npm32.cmd run db:ping` to test the DSN.
