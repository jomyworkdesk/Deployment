module.exports = typeof globalThis.fetch === "function" ? globalThis.fetch : require("node-fetch");
