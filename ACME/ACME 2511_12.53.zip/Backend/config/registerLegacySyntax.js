// Node 12 cannot parse optional chaining or nullish coalescing in the backend sources.
if (Number.parseInt(process.versions.node, 10) < 14) {
    const fs = require("fs");
    const path = require("path");
    const { transformSync } = require("esbuild");
    const backendDirectory = path.resolve(__dirname, "..") + path.sep;
    const dependenciesDirectory = path.join(backendDirectory, "node_modules") + path.sep;
    const loadJavaScript = require.extensions[".js"];

    require.extensions[".js"] = (module, filename) => {
        if (!filename.startsWith(backendDirectory) || filename.startsWith(dependenciesDirectory)) {
            return loadJavaScript(module, filename);
        }

        const source = fs.readFileSync(filename, "utf8");
        const { code } = transformSync(source, {
            target: "node12.22.3",
            sourcefile: filename,
            sourcemap: "inline"
        });
        module._compile(code, filename);
    };
}
