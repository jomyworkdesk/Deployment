@echo off
setlocal

if /i "%~1"=="--run" goto run

powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ^
    "Start-Process -FilePath '%~f0' -ArgumentList '--run' -WorkingDirectory '%~dp0' -WindowStyle Hidden"

if errorlevel 1 (
    echo Failed to start the ARTAX backend.
    exit /b 1
)

echo ARTAX backend started in the background.

exit /b 0

:run
cd /d "%~dp0"

if not exist "logs" mkdir "logs"

call "%~dp0node32.cmd" app.js >> "logs\backend-startup.log" 2>&1

endlocal
