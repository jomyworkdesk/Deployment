@echo off
set "PATH=C:\Program Files (x86)\nodejs;%PATH%"
"C:\Program Files (x86)\nodejs\node.exe" %*

@REM  Greenscapes
