@echo off
set "PATH=C:\Program Files (x86)\nodejs;%PATH%"
"C:\Program Files (x86)\nodejs\node.exe" "C:\Program Files (x86)\nodejs\node_modules\npm\bin\npm-cli.js" %*

@REM  Greenscapes
