# 32-bit ODBC setup

This backend uses the native `odbc` package. When the installed Pervasive ODBC
driver is 32-bit, the driver, System DSN, and Node runtime must all be 32-bit.

Create or verify the DSN with `C:\Windows\SysWOW64\odbcad32.exe`, then set in
`.env`:

```env
PRIMARY_DB_DSN=<primary DSN>
PRIMARY_DB_NAME=<primary database name>
SECONDARY_DB_DSN=<secondary DSN>
SECONDARY_DB_NAME=<secondary database name>
PERVASIVE_ODBC_ARCH=32
```

The primary connection is used for regular Sage tables. The secondary
connection is used by APIs/repositories that work with tables starting with
`EM_`, `E_`, or `e_`. The backend does not provide fallback DSN names; define
both connections in `.env`. Install and run using the bundled 32-bit wrappers:

```powershell
.\npm32.cmd install
npm start
```

Run `.\npm32.cmd run db:ping` to test the DSN.
