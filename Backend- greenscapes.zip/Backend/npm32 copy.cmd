@echo off
set "PATH=C:\node32;%PATH%"
"C:\node32\node.exe" "C:\node32\node_modules\npm\bin\npm-cli.js" %*

@REM  Greenscapes
