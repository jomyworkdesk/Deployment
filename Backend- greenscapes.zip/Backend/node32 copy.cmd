@echo off
set "PATH=C:\node32;%PATH%"
"C:\node32\node.exe" %*

@REM  Greenscapes

